# nettool 3.0 (C++)

A network toolkit rewritten in C++17: a Qt-free **engine**, a **command-line tool**, and a
**Qt 6 "liquid glass" window** (frameless, translucent, animated backdrop, glass panels).

Only test systems and networks you own or have explicit permission to assess.

## Build

**Arch Linux**

```bash
sudo pacman -S --needed base-devel cmake qt6-base iputils curl openssl
cmake -B build -S . && cmake --build build -j
./build/nettool-gui          # the glass window
./build/nettool-cli --help   # the command line
```

**CLI only (no CMake, no Qt)** - also works on Termux (`pkg install clang make`):

```bash
make                         # builds build/nettool-cli
make check                   # self-tests
```

Debian/Ubuntu: `sudo apt install build-essential cmake qt6-base-dev iputils-ping curl openssl`.

## What is native and what shells out

Native C++ (no external program): CIDR calculator, TCP port scan, wait-for-port, banner grab,
DNS (own wire-format client with UDP and TCP fallback: `dns`, `records`, `rdns`), WHOIS (follows
registry referrals), interfaces, sockets, traffic counters, local-port check, ARP table, summary.

Helper programs, started directly (never through a shell): `ping` (netping, sweep, checkhosts, mtu),
`curl` (publicip, headers, httptime, speed, breach checks), `openssl` (ssl), `tracepath`/`traceroute`,
and a terminal emulator for `ssh` in the GUI. Run `nettool-cli doctor` to see what is installed.

| Group | Commands |
|---|---|
| Connectivity | netping, traceroute, mtu, ports, waitfor, banner, sweep, checkhosts |
| DNS & Web | dns, records, rdns, whois, publicip, ssl, headers, httptime, speed |
| This machine | summary, iface, traffic, sockets, localport, arp, cidr |
| Security | breach-email, breach-domain (HaveIBeenPwned; needs `HIBP_API_KEY`) |
| Remote | ssh |

## GUI notes

* **Blur behind the window comes from your compositor**, not from Qt. Without it the window is
  translucent but not frosted: raise the opacity, e.g. `NETTOOL_GLASS_OPACITY=85 ./nettool-gui`
  (25-98, default 66). KDE Plasma: enable the *Blur* desktop effect and add a window rule that
  forces blur for the window class `nettool`. Hyprland blurs translucent windows when blur is
  enabled in `decoration`. The compositor side is not something I could test.
* `NETTOOL_NO_ANIM=1` turns the animated backdrop off.
* Drag the title area to move the window; resize from the bottom-right corner.
* The API-key field is masked. The key is handed to `curl` over stdin, so it never appears in
  the process list. The CLI refuses a key on the command line and reads `HIBP_API_KEY` instead.

## Environment

`NO_COLOR`, `NETTOOL_MAX_PARALLEL_PROBE` (default 50), `NETTOOL_MAX_PARALLEL_SWEEP` (default 40),
`NETTOOL_DNS_SERVERS` (comma-separated, `host` or `host:port`), `HIBP_API_KEY`,
`NETTOOL_GLASS_OPACITY`, `NETTOOL_NO_ANIM`.

## Tests

```bash
make check                   # 43 self-tests (validators, CIDR, JSON, DNS parser incl. fuzzing)
make sanitize                # same under AddressSanitizer + UBSan
make && bash tests/functional.sh   # 82 functional tests against fake servers and stub programs
```

The functional suite starts loopback-only fake TCP, DNS (UDP + TCP) and two-hop WHOIS servers
(`tests/fake_servers.py`) and stubs `ping`, `curl`, `openssl` and `ssh`. It never touches the
real network.

## Not carried over from the bash version

`install`, `uninstall` and `install-deps` (package-manager helpers): use CMake's install target
and your package manager; `doctor` prints the right install command for your platform.
Linux and macOS are the targets; Windows is not supported. Some tools read `/proc` or `/sys`
(Linux/Termux) and fall back to helper programs elsewhere.
