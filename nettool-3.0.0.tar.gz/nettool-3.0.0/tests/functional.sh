#!/usr/bin/env bash
# Functional tests: run every tool against local fake servers and stubbed
# external programs. Nothing here touches the real network.
#   make && bash tests/functional.sh
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CLI="${CLI:-$ROOT/build/nettool-cli}"
TMP="$(mktemp -d)"
FB="$TMP/fakebin"
mkdir -p "$FB"
export NO_COLOR=1

pass=0; fail=0
ok()  { pass=$((pass + 1)); printf 'PASS %s\n' "$1"; }
bad() { fail=$((fail + 1)); printf 'FAIL %s\n' "$1"; [[ -n "${2:-}" ]] && printf '     output: %s\n' "${2:0:500}"; }
# run NAME WANT_RC REGEX cmd...   (REGEX is searched in combined output)
run() {
    local name="$1" want="$2" pat="$3"; shift 3
    local out rc
    out=$("$@" 2>&1); rc=$?
    if [[ "$rc" == "$want" && "$out" =~ $pat ]]; then ok "$name"; else bad "$name (rc=$rc, want $want, pattern '$pat')" "$out"; fi
}
# refute NAME REGEX cmd...   (output must NOT match)
refute() {
    local name="$1" pat="$2"; shift 2
    local out
    out=$("$@" 2>&1)
    if [[ "$out" =~ $pat ]]; then bad "$name" "$out"; else ok "$name"; fi
}

# ------------------------------------------------------------ stub programs ----
cat > "$FB/ping" << 'EOF'
#!/usr/bin/env bash
if [[ "$1" == "-h" ]]; then echo "Usage: ping [options] <destination>"; echo "  -M <pmtud_option>  define path MTU discovery"; exit 2; fi
last="${@: -1}"; size=0; count=1; prev=""
for a in "$@"; do [[ "$prev" == "-s" ]] && size="$a"; [[ "$prev" == "-c" ]] && count="$a"; prev="$a"; done
case "$last" in
  127.0.0.1|192.168.50.1|192.168.50.77) ;;
  192.0.2.1) (( size <= 1400 )) || exit 1 ;;
  *) exit 1 ;;
esac
if (( count > 1 )); then echo "PING $last"; for i in $(seq 1 "$count"); do echo "64 bytes from $last: icmp_seq=$i ttl=64 time=$((i + 1)).$((i * 3)) ms"; done; fi
exit 0
EOF
cat > "$FB/curl" << 'EOF'
#!/usr/bin/env bash
log="${FAKE_LOG:-/dev/null}"
echo "ARGV: $*" >> "$log"
for a in "$@"; do [[ "$a" == "--config" ]] && usecfg=1; done
if [[ -n "${usecfg:-}" ]]; then
  echo "STDIN: $(cat)" >> "$log"
  printf '%s\n%s' "${FAKE_BODY:-}" "${FAKE_STATUS:-200}"; exit 0
fi
url=""; for a in "$@"; do [[ "$a" == http* ]] && url="$a"; done
pick() { [[ "$1" == FAIL ]] && exit 7; printf '%s' "$1"; exit 0; }
case "$url" in
  *ipinfo.io*) pick "${IPINFO:-FAIL}" ;; *ipwho.is*) pick "${IPWHO:-FAIL}" ;;
  *ipapi.co*) pick "${IPAPI:-FAIL}" ;;   *api.ipify.org*) pick "${IPIFY:-FAIL}" ;;
  *) echo "FAKE-CURL $*" ;;
esac
EOF
cat > "$FB/openssl" << 'EOF'
#!/usr/bin/env bash
case "$1" in
  s_client) echo "CONNECTED(00000003)"; echo "-----BEGIN CERTIFICATE-----"; echo "MIIFAKE"; echo "-----END CERTIFICATE-----" ;;
  x509) cat > /dev/null; echo "issuer=CN = Fake CA"; echo "subject=CN = example.test"
        echo "notBefore=Jan  1 00:00:00 2020 GMT"; echo "notAfter=${FAKE_NOTAFTER:-Jan  1 00:00:00 2099 GMT}" ;;
esac
EOF
printf '#!/usr/bin/env bash\necho "FAKE-SSH: $*"\n' > "$FB/ssh"
printf '#!/usr/bin/env bash\necho started\nexec sleep 30\n' > "$FB/tracepath"
chmod +x "$FB"/*

python3 "$ROOT/tests/fake_servers.py" 150 > "$TMP/servers.log" 2>&1 &
SERVERS=$!
trap 'kill "$SERVERS" 2>/dev/null; rm -rf "$TMP"' EXIT
for _ in $(seq 1 50); do grep -q ready "$TMP/servers.log" 2>/dev/null && break; sleep 0.1; done
FAKE="env PATH=$FB:$PATH"
DNS="env NETTOOL_DNS_SERVERS=127.0.0.1:5300"

echo "== basics"
run "help lists tools" 0 "netping <host>.*Ping a host from several threads" "$CLI" --help
run "version" 0 "nettool 3\\." "$CLI" --version
run "unknown command" 2 "Unknown command" "$CLI" nosuchtool
run "too many arguments" 2 "Too many arguments" "$CLI" cidr 10.0.0.1/24 extra
run "bad parallelism env" 2 "must be an integer" env NETTOOL_MAX_PARALLEL_PROBE=0 "$CLI" cidr 10.0.0.1/24
run "doctor" 0 "Dependency check" "$CLI" doctor

echo "== cidr"
run "cidr /24" 0 "Network:    192\\.168\\.1\\.0" "$CLI" cidr 192.168.1.77/24
run "cidr rejects bad prefix" 2 "Invalid address" "$CLI" cidr 10.0.0.1/33

echo "== TCP: ports / waitfor / banner / localport / sockets"
run "port scan finds open ports" 0 "port 45001 is open.*port 45002 is open|port 45002 is open.*port 45001 is open" "$CLI" ports 127.0.0.1 45000 45003
run "port scan summary" 0 "2 open \\(45001, 45002, 45003\\)|3 open \\(45001, 45002, 45003\\)" "$CLI" ports 127.0.0.1 45000 45003
run "port scan rejects reversed range" 2 "Invalid TCP port range" "$CLI" ports 127.0.0.1 100 50
run "port scan rejects injection" 2 "Invalid host" "$CLI" ports 'x;touch /tmp/PWN_NT' 1 10
run "waitfor open port" 0 "is reachable" "$CLI" waitfor 127.0.0.1 45001 5
run "waitfor timeout" 1 "Timed out after 2s" "$CLI" waitfor 127.0.0.1 45999 2
run "waitfor rejects injection" 2 "Invalid host" "$CLI" waitfor 'x;touch /tmp/PWN_NT' 45001 2
run "banner: SSH greeting" 0 "SSH-2\\.0-TestServer_1\\.0" "$CLI" banner 127.0.0.1 45001
run "banner: HEAD probe" 0 "HTTP/1\\.0 200 OK" "$CLI" banner 127.0.0.1 45002
run "banner: closed port" 1 "Could not connect" "$CLI" banner 127.0.0.1 45999
refute "banner strips terminal escapes" $'\x1b' "$CLI" banner 127.0.0.1 45003
run "banner shows sanitized text" 0 "\\.\\[31mEVIL" "$CLI" banner 127.0.0.1 45003
run "localport busy" 1 "BUSY" "$CLI" localport 45001
run "localport free" 0 "FREE" "$CLI" localport 45998
run "localport no substring false positive" 0 "FREE" "$CLI" localport 450
run "sockets lists listeners" 0 "127\\.0\\.0\\.1:45001" "$CLI" sockets

echo "== DNS (fake resolver, UDP + TCP fallback)"
run "records: every type" 0 "203\\.0\\.113\\.9.*2001:db8::9.*10 mail\\.example\\.com.*ns1\\.example\\.com.*v=spf1 -all" $DNS "$CLI" records example.test
run "records: NXDOMAIN" 1 "NXDOMAIN" $DNS "$CLI" records nxdomain.test
run "records: truncated UDP falls back to TCP" 0 "203\\.0\\.113\\.9" $DNS "$CLI" records big.test
run "rdns IPv4" 0 "8\\.8\\.8\\.8 -> host\\.example\\.com" $DNS "$CLI" rdns 8.8.8.8
run "rdns IPv6" 0 "-> host\\.example\\.com" $DNS "$CLI" rdns 2001:db8::1
run "rdns rejects non-IP" 2 "Enter an IPv4 or IPv6" "$CLI" rdns notanip
run "dns compare handles unreachable resolvers" 1 "A-record responses for example\\.test" "$CLI" dns example.test

echo "== WHOIS (native, two-hop referral)"
run "whois follows referral" 0 "Referral path: 127\\.0\\.0\\.1:43043 -> 127\\.0\\.0\\.1:43044.*Registrar: Fake Registrar" env NETTOOL_WHOIS_ROOT=127.0.0.1:43043 "$CLI" whois example.test
run "whois rejects injection" 2 "Enter a domain" "$CLI" whois 'a;b'

echo "== ping-based tools (stubbed ping)"
run "netping RTT/jitter summary" 0 "samples=3 min/avg/max=2\\.30/3\\.60/4\\.90 ms jitter=1\\.30" $FAKE "$CLI" netping 127.0.0.1 3 1
run "netping multi-thread" 0 "\\[Thread 3\\].*samples=3" $FAKE "$CLI" netping 127.0.0.1 3 3
run "netping rejects bad limits" 2 "Limits: count" "$CLI" netping 127.0.0.1 0
run "netping unreachable" 1 "No RTT samples" $FAKE "$CLI" netping 192.0.2.77 2
run "sweep finds hosts" 0 "192\\.168\\.50\\.1.*192\\.168\\.50\\.77|192\\.168\\.50\\.77.*192\\.168\\.50\\.1" $FAKE "$CLI" sweep 192.168.50
run "sweep summary" 0 "2 host\\(s\\) responded" $FAKE "$CLI" sweep 192.168.50
run "sweep rejects bad prefix" 2 "valid 3-octet" "$CLI" sweep 999.1.1
run "checkhosts list" 0 "127\\.0\\.0\\.1 +UP.*192\\.0\\.2\\.9 +DOWN.*bad;host +SKIPPED" $FAKE "$CLI" checkhosts "127.0.0.1, 192.0.2.9, bad;host"
printf '# comment\n127.0.0.1\n\n  192.0.2.9  \n-oops\n' > "$TMP/hosts.txt"
run "checkhosts file" 0 "127\\.0\\.0\\.1 +UP.*192\\.0\\.2\\.9 +DOWN.*-oops +SKIPPED" $FAKE "$CLI" checkhosts "$TMP/hosts.txt"
run "mtu: iputils-style ping (-h exits 2)" 0 "payload: 1400 bytes; estimated IPv4 path MTU: 1428 bytes" $FAKE "$CLI" mtu 192.0.2.1
run "mtu: IPv6 rejected" 2 "IPv4 targets only" "$CLI" mtu ::1

echo "== HTTP/TLS tools (stubbed curl/openssl)"
J1='{"ip": "203.0.113.7", "city": "Amsterdam", "region": "North Holland", "country": "NL", "org": "AS1136 KPN B.V."}'
run "publicip: first provider" 0 "IP:      203\\.0\\.113\\.7.*Amsterdam.*Source:  ipinfo\\.io" $FAKE env IPINFO="$J1" "$CLI" publicip
run "publicip: falls back past a rate limit" 0 "Netherlands.*ASN:     1136.*Source:  ipwho\\.is" $FAKE env IPINFO='{"status":429,"error":{"title":"Rate limit"}}' IPWHO='{"ip":"203.0.113.7","success":true,"country":"Netherlands","region":"NH","city":"Amsterdam","connection":{"asn":1136,"org":"KPN"}}' "$CLI" publicip
run "publicip: error payloads skipped, plain-IP fallback" 0 "203\\.0\\.113\\.7.*address only" $FAKE env IPWHO='{"ip":"203.0.113.7","success":false}' IPAPI='{"error": true, "reason": "RateLimited"}' IPIFY=203.0.113.7 "$CLI" publicip
run "publicip: everything down gives a clear error" 1 "Could not determine your public IP" $FAKE "$CLI" publicip
run "headers" 0 "FAKE-CURL --head" $FAKE "$CLI" headers 'https://example.com?x=1'
run "headers rejects bad URL" 2 "valid http" "$CLI" headers 'ftp://example.com'
run "httptime" 0 "FAKE-CURL .*time_namelookup" $FAKE "$CLI" httptime https://example.com
run "speed" 0 "FAKE-CURL .*speed\\.cloudflare\\.com" $FAKE "$CLI" speed
run "ssl: valid cert" 0 "notAfter=Jan  1 00:00:00 2099.*\\[OK\\] Certificate is valid" $FAKE "$CLI" ssl example.test
run "ssl: expired cert" 0 "EXPIRED" $FAKE env FAKE_NOTAFTER="Jan  1 00:00:00 2020 GMT" "$CLI" ssl example.test
SOON="$(date -u -d '+10 days' '+%b %e %H:%M:%S %Y GMT')"
run "ssl: expiring soon" 0 "expires in (9|10) day" $FAKE env FAKE_NOTAFTER="$SOON" "$CLI" ssl example.test

echo "== HaveIBeenPwned (stubbed curl)"
KEY=0123456789abcdef0123456789abcdef
LOG="$TMP/curl.log"
run "breach-email: no key" 1 "No API key" env -u HIBP_API_KEY "$CLI" breach-email a@example.com
run "breach-email: malformed key" 1 "valid API key" $FAKE env HIBP_API_KEY=abc "$CLI" breach-email a@example.com
run "breach-email: clean (404)" 0 "No breaches found" $FAKE env HIBP_API_KEY=$KEY FAKE_STATUS=404 "$CLI" breach-email a@example.com
run "breach-email: breaches (200)" 0 "Adobe .2013-10-04. - 152445165 accounts.*Passwords.*appears in 1 known breach" $FAKE env HIBP_API_KEY=$KEY FAKE_BODY='[{"Name":"Adobe","Title":"Adobe","BreachDate":"2013-10-04","PwnCount":152445165,"DataClasses":["Email addresses","Passwords"]}]' "$CLI" breach-email a@example.com
run "breach-email: 401" 1 "unauthorized" $FAKE env HIBP_API_KEY=$KEY FAKE_STATUS=401 "$CLI" breach-email a@example.com
run "breach-domain: 403" 1 "403 Forbidden" $FAKE env HIBP_API_KEY=$KEY FAKE_STATUS=403 "$CLI" breach-domain example.com
run "breach-domain: 429" 1 "Rate limited" $FAKE env HIBP_API_KEY=$KEY FAKE_STATUS=429 "$CLI" breach-domain example.com
run "breach-domain: aliases (200)" 0 "alice: Adobe, LinkedIn" $FAKE env HIBP_API_KEY=$KEY FAKE_BODY='{"alice":["Adobe","LinkedIn"]}' "$CLI" breach-domain example.com
run "breach-domain: empty object is clean" 0 "No breached aliases" $FAKE env HIBP_API_KEY=$KEY FAKE_BODY='{}' "$CLI" breach-domain example.com
run "breach-email: rejects injection-style address" 2 "valid email" env HIBP_API_KEY=$KEY "$CLI" breach-email 'x;y@example.com'
run "CLI refuses a secret on the command line" 2 "Don't pass secrets" "$CLI" breach-email a@example.com $KEY
: > "$LOG"
$FAKE env HIBP_API_KEY=$KEY FAKE_LOG="$LOG" FAKE_STATUS=404 "$CLI" breach-email 'a+b@example.com' > /dev/null 2>&1
if grep '^ARGV' "$LOG" | grep -q "$KEY"; then bad "API key must not appear on curl's command line"; else ok "API key never appears on curl's command line"; fi
if grep -q "hibp-api-key: $KEY" "$LOG"; then ok "API key delivered via curl --config on stdin"; else bad "API key delivered via stdin" "$(cat "$LOG")"; fi
if grep -q "breachedaccount/a%2Bb%40example.com" "$LOG"; then ok "email is percent-encoded in the request path"; else bad "email percent-encoding" "$(cat "$LOG")"; fi

echo "== this machine"
run "iface lists loopback" 0 "lo +UP.*127\\.0\\.0\\.1/8" "$CLI" iface
run "traffic on loopback" 0 "Download \\(RX\\):.*Upload   \\(TX\\):" "$CLI" traffic lo 1
run "traffic rejects bad interface name" 2 "Invalid interface" "$CLI" traffic 'lo;x' 1
run "traffic unknown interface" 1 "Could not read byte counters" "$CLI" traffic nosuchif0 1
run "traffic rejects zero interval" 2 "whole number of seconds" "$CLI" traffic lo 0
run "arp prints a table" 0 "IP address +MAC address" "$CLI" arp
run "summary runs end to end" 0 "Network summary.*Interfaces.*Connectivity" $FAKE "$CLI" summary

echo "== ssh"
run "ssh passthrough" 0 "FAKE-SSH: user@host -p 22" $FAKE "$CLI" ssh user@host -p 22
run "ssh needs arguments" 2 "Usage" "$CLI" ssh

echo "== cancellation (Ctrl+C)"
start=$(date +%s)
"$CLI" waitfor 127.0.0.1 45999 60 > /dev/null 2>&1 & pid=$!
sleep 1; kill -INT "$pid"; wait "$pid"; rc=$?
elapsed=$(( $(date +%s) - start ))
if [[ $rc == 130 && $elapsed -lt 5 ]]; then ok "SIGINT stops waitfor promptly (rc 130, ${elapsed}s)"; else bad "SIGINT stops waitfor (rc=$rc, ${elapsed}s)"; fi
start=$(date +%s)
$FAKE "$CLI" traceroute 192.0.2.1 > /dev/null 2>&1 & pid=$!
sleep 1; kill -INT "$pid"; wait "$pid"; rc=$?
elapsed=$(( $(date +%s) - start ))
if [[ $rc == 130 && $elapsed -lt 5 ]]; then ok "SIGINT stops a running helper process (rc 130, ${elapsed}s)"; else bad "SIGINT stops traceroute (rc=$rc, ${elapsed}s)"; fi
sleep 0.3
if pgrep -f "sleep 30" > /dev/null; then bad "helper process left running after cancel"; pkill -f "sleep 30"; else ok "no orphaned helper process after cancel"; fi

echo "== no injection side effects"
if ls /tmp/PWN_NT 2>/dev/null; then bad "injection marker created"; rm -f /tmp/PWN_NT; else ok "no injection marker created"; fi

printf '\n%d passed, %d failed\n' "$pass" "$fail"
[[ $fail -eq 0 ]]
