#!/usr/bin/env python3
"""Local fake services used by tests/functional.sh (loopback only)."""
import socket
import struct
import sys
import threading
import time

HOST = "127.0.0.1"


def serve_tcp(port, handler):
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((HOST, port))
    srv.listen(16)

    def loop():
        while True:
            conn, _ = srv.accept()
            threading.Thread(target=run, args=(conn,), daemon=True).start()

    def run(conn):
        try:
            conn.settimeout(5)
            handler(conn)
        except Exception:
            pass
        finally:
            conn.close()

    threading.Thread(target=loop, daemon=True).start()


def ssh_banner(conn):
    conn.sendall(b"SSH-2.0-TestServer_1.0\r\n")
    time.sleep(0.5)


def http_like(conn):
    data = conn.recv(1024)
    if data.startswith(b"HEAD"):
        conn.sendall(b"HTTP/1.0 200 OK\r\nServer: testsrv/9.9\r\n\r\n")
    time.sleep(0.3)


def evil_banner(conn):
    conn.sendall(b"\x1b[31mEVIL\x1b[0m\x07\r\n")
    time.sleep(0.5)


def whois_root(conn):
    conn.recv(256)
    conn.sendall(b"% fake registry root\nrefer:        127.0.0.1:43044\n")


def whois_leaf(conn):
    conn.recv(256)
    conn.sendall(b"Domain Name: EXAMPLE.TEST\nRegistrar: Fake Registrar Inc.\n")


# ------------------------------------------------------------------- DNS ----
def enc_name(name):
    out = b""
    for label in name.rstrip(".").split("."):
        out += bytes([len(label)]) + label.encode()
    return out + b"\x00"


def parse_query(data):
    qid = struct.unpack("!H", data[:2])[0]
    pos, labels = 12, []
    while data[pos]:
        n = data[pos]
        labels.append(data[pos + 1:pos + 1 + n].decode())
        pos += 1 + n
    qtype = struct.unpack("!H", data[pos + 1:pos + 3])[0]
    return qid, ".".join(labels), qtype, data[12:pos + 5]


def build_answers(name, qtype):
    ans = []
    ptr = b"\xc0\x0c"

    def rr(t, rdata):
        return ptr + struct.pack("!HHIH", t, 1, 60, len(rdata)) + rdata

    if qtype == 1:
        ans.append(rr(1, bytes([203, 0, 113, 9])))
    elif qtype == 28:
        ans.append(rr(28, socket.inet_pton(socket.AF_INET6, "2001:db8::9")))
    elif qtype == 15:
        ans.append(rr(15, struct.pack("!H", 10) + enc_name("mail.example.com")))
    elif qtype == 2:
        ans.append(rr(2, enc_name("ns1.example.com")))
    elif qtype == 16:
        txt = b"v=spf1 -all"
        ans.append(rr(16, bytes([len(txt)]) + txt))
    elif qtype == 12:
        ans.append(rr(12, enc_name("host.example.com")))
    return ans


def respond(data, over_tcp):
    qid, name, qtype, question = parse_query(data)
    rcode, flags_extra, answers = 0, 0, []
    if name == "nxdomain.test":
        rcode = 3
    elif name == "big.test" and not over_tcp:
        flags_extra = 0x0200          # TC: force the client to retry over TCP
    else:
        answers = build_answers(name, qtype)
    flags = 0x8180 | flags_extra | rcode
    header = struct.pack("!HHHHHH", qid, flags, 1, len(answers), 0, 0)
    return header + question + b"".join(answers)


def dns_udp(port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((HOST, port))

    def loop():
        while True:
            data, addr = sock.recvfrom(512)
            try:
                sock.sendto(respond(data, False), addr)
            except Exception:
                pass

    threading.Thread(target=loop, daemon=True).start()


def dns_tcp(conn):
    n = struct.unpack("!H", conn.recv(2))[0]
    data = b""
    while len(data) < n:
        data += conn.recv(n - len(data))
    resp = respond(data, True)
    conn.sendall(struct.pack("!H", len(resp)) + resp)


if __name__ == "__main__":
    serve_tcp(45001, ssh_banner)
    serve_tcp(45002, http_like)
    serve_tcp(45003, evil_banner)
    serve_tcp(43043, whois_root)
    serve_tcp(43044, whois_leaf)
    dns_udp(5300)
    serve_tcp(5300, dns_tcp)
    print("ready", flush=True)
    time.sleep(int(sys.argv[1]) if len(sys.argv) > 1 else 120)
