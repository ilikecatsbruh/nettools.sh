#include <QApplication>

#include <iostream>
#include <string>

#include "glasswindow.hpp"

int main(int argc, char** argv) {
    QApplication app(argc, argv);
    QApplication::setApplicationName(QStringLiteral("nettool"));
    QApplication::setApplicationVersion(QString::fromLatin1(nt::kVersion));

    std::string error;
    if (!nt::validateLimits(error)) {
        std::cerr << "Error: " << error << "\n";
        return 2;
    }

    GlassWindow window;
    window.show();
    return app.exec();
}
