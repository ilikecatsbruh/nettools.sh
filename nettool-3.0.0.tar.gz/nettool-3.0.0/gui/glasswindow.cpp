#include "glasswindow.hpp"

#include <QCloseEvent>
#include <QFont>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QLinearGradient>
#include <QListWidget>
#include <QMouseEvent>
#include <QPainter>
#include <QPainterPath>
#include <QPlainTextEdit>
#include <QProcess>
#include <QPushButton>
#include <QRadialGradient>
#include <QScrollBar>
#include <QSizeGrip>
#include <QStringList>
#include <QTextCharFormat>
#include <QTextCursor>
#include <QThread>
#include <QTimer>
#include <QVBoxLayout>
#include <QWindow>

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <string>
#include <vector>

// ------------------------------------------------------------- GlassPanel ----
GlassPanel::GlassPanel(QWidget* parent, qreal radius, int alpha)
    : QFrame(parent), radius_(radius), alpha_(alpha) {
    setFrameShape(QFrame::NoFrame);
}

void GlassPanel::paintEvent(QPaintEvent*) {
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);
    const QRectF r = QRectF(rect()).adjusted(0.5, 0.5, -0.5, -0.5);
    QPainterPath path;
    path.addRoundedRect(r, radius_, radius_);

    QLinearGradient fill(r.topLeft(), r.bottomLeft());
    fill.setColorAt(0.0, QColor(255, 255, 255, alpha_ + 18));
    fill.setColorAt(1.0, QColor(255, 255, 255, std::max(0, alpha_ - 12)));
    p.fillPath(path, fill);

    p.save();   // specular highlight along the top edge
    p.setClipPath(path);
    QLinearGradient shine(r.topLeft(), QPointF(r.left(), r.top() + r.height() * 0.35));
    shine.setColorAt(0.0, QColor(255, 255, 255, 46));
    shine.setColorAt(1.0, QColor(255, 255, 255, 0));
    p.fillRect(r, shine);
    p.restore();

    QLinearGradient rim(r.topLeft(), r.bottomRight());
    rim.setColorAt(0.0, QColor(255, 255, 255, 120));
    rim.setColorAt(0.5, QColor(255, 255, 255, 26));
    rim.setColorAt(1.0, QColor(255, 255, 255, 70));
    p.setPen(QPen(QBrush(rim), 1.2));
    p.setBrush(Qt::NoBrush);
    p.drawPath(path);
}

// ---------------------------------------------------------------- QtSink ----
// Receives engine output on the worker thread and forwards it to the GUI thread.
class GlassWindow::QtSink : public nt::Sink {
public:
    explicit QtSink(GlassWindow* window) : window_(window) {}
    void write(nt::Level level, const std::string& text) override {
        const QString qtext = QString::fromUtf8(text.c_str(), static_cast<int>(text.size()));
        GlassWindow* w = window_;
        QMetaObject::invokeMethod(w, [w, level, qtext]() { w->appendOutput(level, qtext); }, Qt::QueuedConnection);
    }

private:
    GlassWindow* window_;
};

// ------------------------------------------------------------ GlassWindow ----
GlassWindow::GlassWindow(QWidget* parent) : QWidget(parent, Qt::Window | Qt::FramelessWindowHint) {
    setAttribute(Qt::WA_TranslucentBackground);
    setWindowTitle(QStringLiteral("Nettool"));
    resize(1060, 700);
    setMinimumSize(860, 540);

    if (const char* v = std::getenv("NETTOOL_GLASS_OPACITY")) {
        bool ok = false;
        const int n = QString::fromLatin1(v).toInt(&ok);
        if (ok) glassOpacity_ = std::clamp(n, 25, 98);
    }

    buildUi();
    populateTools();

    animTimer_ = new QTimer(this);
    connect(animTimer_, &QTimer::timeout, this, [this]() {
        phase_ += 0.012;
        update();
    });
    if (!std::getenv("NETTOOL_NO_ANIM")) animTimer_->start(40);
}

GlassWindow::~GlassWindow() {
    if (worker_) {
        cancel_.cancel();
        worker_->wait();
        delete worker_;
        worker_ = nullptr;
    }
}

void GlassWindow::buildUi() {
    setStyleSheet(QStringLiteral(R"QSS(
        QWidget { color: rgba(255,255,255,235); font-size: 13px; }
        QLabel#brand { font-size: 17px; font-weight: 700; }
        QLabel#title { font-size: 24px; font-weight: 700; }
        QLabel#desc { color: rgba(255,255,255,170); }
        QLabel#status { color: rgba(255,255,255,150); }
        QListWidget { background: transparent; border: none; outline: none; }
        QListWidget::item { padding: 8px 12px; margin: 1px 4px; border-radius: 12px; }
        QListWidget::item:hover { background: rgba(255,255,255,26); }
        QListWidget::item:selected { background: rgba(255,255,255,58); color: white; }
        QLineEdit { background: rgba(255,255,255,28); border: 1px solid rgba(255,255,255,70);
                    border-radius: 11px; padding: 8px 12px; selection-background-color: rgba(120,170,255,150); }
        QLineEdit:focus { border: 1px solid rgba(160,205,255,210); background: rgba(255,255,255,40); }
        QPushButton#run { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 rgba(150,196,255,220), stop:1 rgba(72,122,236,210));
                          border: 1px solid rgba(255,255,255,130); border-radius: 12px; padding: 9px 24px;
                          font-weight: 600; color: white; }
        QPushButton#run:hover { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 rgba(175,214,255,235), stop:1 rgba(92,142,250,225)); }
        QPushButton#run:disabled { background: rgba(255,255,255,24); color: rgba(255,255,255,90); border: 1px solid rgba(255,255,255,40); }
        QPushButton#cancel { background: rgba(255,255,255,30); border: 1px solid rgba(255,255,255,70);
                             border-radius: 12px; padding: 9px 20px; }
        QPushButton#cancel:hover { background: rgba(255,255,255,48); }
        QPushButton#cancel:disabled { color: rgba(255,255,255,80); border: 1px solid rgba(255,255,255,36); }
        QPlainTextEdit { background: rgba(8,12,28,110); border: 1px solid rgba(255,255,255,50); border-radius: 16px;
                         padding: 12px; font-family: "JetBrains Mono", "Fira Code", "DejaVu Sans Mono", monospace;
                         font-size: 12px; selection-background-color: rgba(120,170,255,150); }
        QScrollBar:vertical { background: transparent; width: 10px; margin: 6px 2px; }
        QScrollBar::handle:vertical { background: rgba(255,255,255,70); border-radius: 4px; min-height: 30px; }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
    )QSS"));

    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(30, 26, 30, 26);
    root->setSpacing(16);

    // Title bar: window buttons, brand, version.
    auto* bar = new QHBoxLayout;
    bar->setSpacing(8);
    auto* closeBtn = new QPushButton;
    closeBtn->setFixedSize(14, 14);
    closeBtn->setToolTip(QStringLiteral("Close"));
    closeBtn->setStyleSheet(QStringLiteral("QPushButton{background:#ff5f57;border:none;border-radius:7px;}"
                                           "QPushButton:hover{background:#ff8a84;}"));
    auto* minBtn = new QPushButton;
    minBtn->setFixedSize(14, 14);
    minBtn->setToolTip(QStringLiteral("Minimize"));
    minBtn->setStyleSheet(QStringLiteral("QPushButton{background:#febc2e;border:none;border-radius:7px;}"
                                         "QPushButton:hover{background:#ffd062;}"));
    connect(closeBtn, &QPushButton::clicked, this, [this]() { close(); });
    connect(minBtn, &QPushButton::clicked, this, [this]() { showMinimized(); });
    auto* brand = new QLabel(QStringLiteral("NETTOOL"));
    brand->setObjectName(QStringLiteral("brand"));
    auto* version = new QLabel(QStringLiteral("v") + QString::fromLatin1(nt::kVersion));
    version->setObjectName(QStringLiteral("status"));
    bar->addWidget(closeBtn);
    bar->addWidget(minBtn);
    bar->addSpacing(12);
    bar->addWidget(brand);
    bar->addWidget(version);
    bar->addStretch();
    root->addLayout(bar);

    auto* body = new QHBoxLayout;
    body->setSpacing(16);

    // Sidebar
    auto* side = new GlassPanel(this, 24.0, 30);
    side->setFixedWidth(250);
    auto* sideLayout = new QVBoxLayout(side);
    sideLayout->setContentsMargins(10, 12, 10, 12);
    toolList_ = new QListWidget;
    toolList_->setFrameShape(QFrame::NoFrame);
    toolList_->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    sideLayout->addWidget(toolList_);
    body->addWidget(side);

    // Content
    auto* content = new GlassPanel(this, 26.0, 30);
    auto* contentLayout = new QVBoxLayout(content);
    contentLayout->setContentsMargins(22, 20, 22, 20);
    contentLayout->setSpacing(12);
    titleLabel_ = new QLabel;
    titleLabel_->setObjectName(QStringLiteral("title"));
    descLabel_ = new QLabel;
    descLabel_->setObjectName(QStringLiteral("desc"));
    descLabel_->setWordWrap(true);
    contentLayout->addWidget(titleLabel_);
    contentLayout->addWidget(descLabel_);

    auto* formHost = new QWidget;
    form_ = new QFormLayout(formHost);
    form_->setContentsMargins(0, 6, 0, 6);
    form_->setHorizontalSpacing(14);
    form_->setVerticalSpacing(10);
    form_->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
    contentLayout->addWidget(formHost);

    auto* buttons = new QHBoxLayout;
    runBtn_ = new QPushButton(QStringLiteral("Run"));
    runBtn_->setObjectName(QStringLiteral("run"));
    cancelBtn_ = new QPushButton(QStringLiteral("Cancel"));
    cancelBtn_->setObjectName(QStringLiteral("cancel"));
    cancelBtn_->setEnabled(false);
    statusLabel_ = new QLabel;
    statusLabel_->setObjectName(QStringLiteral("status"));
    buttons->addWidget(runBtn_);
    buttons->addWidget(cancelBtn_);
    buttons->addSpacing(8);
    buttons->addWidget(statusLabel_, 1);
    contentLayout->addLayout(buttons);

    output_ = new QPlainTextEdit;
    output_->setReadOnly(true);
    output_->setMaximumBlockCount(5000);
    output_->setFrameShape(QFrame::NoFrame);
    contentLayout->addWidget(output_, 1);
    body->addWidget(content, 1);
    root->addLayout(body, 1);

    grip_ = new QSizeGrip(this);

    connect(toolList_, &QListWidget::currentItemChanged, this,
            [this](QListWidgetItem* current, QListWidgetItem*) { selectTool(current); });
    connect(runBtn_, &QPushButton::clicked, this, [this]() { runClicked(); });
    connect(cancelBtn_, &QPushButton::clicked, this, [this]() { cancelClicked(); });
}

void GlassWindow::populateTools() {
    std::vector<std::string> categories;
    for (const auto& t : nt::tools()) {
        if (std::find(categories.begin(), categories.end(), t.category) == categories.end()) categories.push_back(t.category);
    }
    QListWidgetItem* first = nullptr;
    for (const auto& cat : categories) {
        auto* header = new QListWidgetItem(QString::fromStdString(cat).toUpper(), toolList_);
        header->setFlags(Qt::NoItemFlags);
        QFont f;
        f.setBold(true);
        f.setPixelSize(10);
        f.setLetterSpacing(QFont::AbsoluteSpacing, 1.4);
        header->setFont(f);
        header->setForeground(QBrush(QColor(255, 255, 255, 120)));
        for (const auto& t : nt::tools()) {
            if (t.category != cat) continue;
            auto* item = new QListWidgetItem(QString::fromStdString(t.title), toolList_);
            item->setData(Qt::UserRole, QString::fromStdString(t.id));
            if (!first) first = item;
        }
    }
    if (first) toolList_->setCurrentItem(first);
}

void GlassWindow::selectTool(QListWidgetItem* item) {
    if (!item) return;
    const QString id = item->data(Qt::UserRole).toString();
    if (id.isEmpty()) return;
    const nt::Tool* tool = nt::findTool(id.toStdString());
    if (!tool) return;
    current_ = tool;
    titleLabel_->setText(QString::fromStdString(tool->title));
    descLabel_->setText(QString::fromStdString(tool->description));

    while (form_->rowCount() > 0) form_->removeRow(0);
    fields_.clear();
    QLineEdit* firstEdit = nullptr;
    for (const auto& p : tool->params) {
        auto* edit = new QLineEdit;
        edit->setPlaceholderText(QString::fromStdString(p.placeholder));
        if (!p.def.empty()) edit->setText(QString::fromStdString(p.def));
        if (p.secret) edit->setEchoMode(QLineEdit::Password);
        connect(edit, &QLineEdit::returnPressed, this, [this]() { runClicked(); });
        QString label = QString::fromStdString(p.label);
        if (p.required) label += QStringLiteral(" *");
        form_->addRow(label, edit);
        fields_.insert(QString::fromStdString(p.key), edit);
        if (!firstEdit) firstEdit = edit;
    }
    runBtn_->setText(tool->interactive ? QStringLiteral("Open in terminal") : QStringLiteral("Run"));
    statusLabel_->clear();
    if (firstEdit) firstEdit->setFocus();
}

void GlassWindow::runClicked() {
    if (!current_ || worker_) return;
    nt::Args args;
    for (const auto& p : current_->params) {
        QLineEdit* edit = fields_.value(QString::fromStdString(p.key), nullptr);
        std::string value = edit ? edit->text().trimmed().toStdString() : std::string();
        if (value.empty() && !p.def.empty()) value = p.def;
        if (p.required && value.empty()) {
            statusLabel_->setText(QStringLiteral("Please fill in: ") + QString::fromStdString(p.label));
            return;
        }
        args[p.key] = value;
    }
    if (current_->interactive) {
        launchInteractive(args);
        return;
    }

    output_->clear();
    std::string limitError;
    if (!nt::validateLimits(limitError)) {
        appendOutput(nt::Level::Bad, QString::fromStdString("Error: " + limitError + "\n"));
        return;
    }
    cancel_.flag.store(false);
    sink_ = std::make_unique<QtSink>(this);
    const nt::Tool* tool = current_;
    QtSink* sink = sink_.get();
    worker_ = QThread::create([this, tool, args, sink]() {
        const int rc = tool->run(args, *sink, cancel_);
        QMetaObject::invokeMethod(this, [this, rc]() { finished(rc); }, Qt::QueuedConnection);
    });
    setRunning(true);
    worker_->start();
}

void GlassWindow::cancelClicked() {
    cancel_.cancel();
    cancelBtn_->setEnabled(false);
    statusLabel_->setText(QStringLiteral("Cancelling..."));
}

void GlassWindow::launchInteractive(const nt::Args& args) {
    output_->clear();
    std::vector<std::string> argv;
    std::string error;
    if (!nt::buildSshArgv(args, argv, error)) {
        appendOutput(nt::Level::Bad, QString::fromStdString("Error: " + error + "\n"));
        return;
    }
    const std::vector<std::string> wrapped = nt::terminalWrap(argv);
    if (wrapped.empty()) {
        std::string command;
        for (size_t i = 0; i < argv.size(); ++i) command += (i ? " " : "") + argv[i];
        appendOutput(nt::Level::Warn, QStringLiteral("No terminal emulator found. Run this yourself:\n"));
        appendOutput(nt::Level::Plain, QString::fromStdString("  " + command + "\n"));
        return;
    }
    QStringList list;
    for (size_t i = 1; i < wrapped.size(); ++i) list << QString::fromStdString(wrapped[i]);
    if (QProcess::startDetached(QString::fromStdString(wrapped[0]), list)) {
        appendOutput(nt::Level::Good, QString::fromStdString("Opened in " + wrapped[0] + ".\n"));
        statusLabel_->setText(QStringLiteral("Opened"));
    } else {
        appendOutput(nt::Level::Bad, QString::fromStdString("Error: could not start " + wrapped[0] + ".\n"));
    }
}

void GlassWindow::finished(int exitCode) {
    if (worker_) {
        worker_->wait();
        delete worker_;
        worker_ = nullptr;
    }
    setRunning(false);
    if (exitCode == 0) statusLabel_->setText(QStringLiteral("Done"));
    else if (exitCode == 130) statusLabel_->setText(QStringLiteral("Cancelled"));
    else statusLabel_->setText(QStringLiteral("Finished with errors (exit code %1)").arg(exitCode));
}

void GlassWindow::setRunning(bool running) {
    runBtn_->setEnabled(!running);
    cancelBtn_->setEnabled(running);
    toolList_->setEnabled(!running);
    if (running) statusLabel_->setText(QStringLiteral("Running..."));
}

void GlassWindow::appendOutput(nt::Level level, const QString& text) {
    QColor color(235, 242, 255);
    bool bold = false;
    switch (level) {
        case nt::Level::Heading: color = QColor(140, 200, 255); bold = true; break;
        case nt::Level::Good: color = QColor(130, 230, 170); break;
        case nt::Level::Warn: color = QColor(255, 214, 120); break;
        case nt::Level::Bad: color = QColor(255, 128, 128); break;
        case nt::Level::Dim: color = QColor(160, 176, 205); break;
        default: break;
    }
    QTextCharFormat fmt;
    fmt.setForeground(color);
    if (bold) fmt.setFontWeight(QFont::Bold);
    QTextCursor cursor(output_->document());
    cursor.movePosition(QTextCursor::End);
    cursor.insertText(text, fmt);
    output_->verticalScrollBar()->setValue(output_->verticalScrollBar()->maximum());
}

// ------------------------------------------------------------- painting ----
void GlassWindow::paintEvent(QPaintEvent*) {
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);
    const QRectF body = QRectF(rect()).adjusted(12, 12, -12, -12);
    QPainterPath shape;
    shape.addRoundedRect(body, 30, 30);

    // Soft drop shadow, drawn only outside the glass so the pane stays clear.
    p.save();
    QPainterPath outside;
    outside.addRect(QRectF(rect()));
    p.setClipPath(outside.subtracted(shape));
    p.setPen(Qt::NoPen);
    for (int i = 0; i < 12; ++i) {
        p.setBrush(QColor(0, 0, 0, 9));
        p.drawRoundedRect(body.adjusted(-i, -i + 4, i, i + 4), 30 + i, 30 + i);
    }
    p.restore();

    p.save();
    p.setClipPath(shape);
    const int baseAlpha = glassOpacity_ * 255 / 100;
    QLinearGradient base(body.topLeft(), body.bottomRight());
    base.setColorAt(0.0, QColor(34, 46, 92, baseAlpha));
    base.setColorAt(1.0, QColor(14, 18, 44, baseAlpha));
    p.fillRect(body, base);

    // Slow-moving colour blooms: the "liquid" behind the glass.
    const double radius = std::max(body.width(), body.height()) * 0.6;
    auto bloom = [&](double fx, double fy, QColor c) {
        const QPointF centre(body.left() + body.width() * fx, body.top() + body.height() * fy);
        QRadialGradient g(centre, radius);
        QColor outer = c;
        c.setAlpha(std::min(255, 60 + glassOpacity_));
        outer.setAlpha(0);
        g.setColorAt(0.0, c);
        g.setColorAt(1.0, outer);
        p.fillRect(body, QBrush(g));
    };
    bloom(0.20 + 0.10 * std::sin(phase_), 0.25 + 0.12 * std::cos(phase_ * 0.8), QColor(80, 140, 255));
    bloom(0.80 + 0.08 * std::cos(phase_ * 1.1), 0.30 + 0.10 * std::sin(phase_ * 0.7), QColor(190, 96, 255));
    bloom(0.50 + 0.12 * std::sin(phase_ * 0.6), 0.90 + 0.06 * std::cos(phase_), QColor(40, 210, 190));

    QLinearGradient shine(body.topLeft(), QPointF(body.left(), body.top() + body.height() * 0.4));
    shine.setColorAt(0.0, QColor(255, 255, 255, 58));
    shine.setColorAt(1.0, QColor(255, 255, 255, 0));
    p.fillRect(body, shine);
    p.restore();

    QLinearGradient rim(body.topLeft(), body.bottomRight());
    rim.setColorAt(0.0, QColor(255, 255, 255, 190));
    rim.setColorAt(0.45, QColor(255, 255, 255, 40));
    rim.setColorAt(1.0, QColor(255, 255, 255, 120));
    p.setPen(QPen(QBrush(rim), 1.5));
    p.setBrush(Qt::NoBrush);
    p.drawPath(shape);
}

void GlassWindow::mousePressEvent(QMouseEvent* event) {
    // Dragging the title area moves the window (works on X11 and Wayland).
    if (event->button() == Qt::LeftButton && event->position().y() < 70 && windowHandle()) {
        windowHandle()->startSystemMove();
        event->accept();
        return;
    }
    QWidget::mousePressEvent(event);
}

void GlassWindow::resizeEvent(QResizeEvent* event) {
    QWidget::resizeEvent(event);
    if (grip_) {
        grip_->move(width() - grip_->sizeHint().width() - 20, height() - grip_->sizeHint().height() - 20);
        grip_->raise();
    }
}

void GlassWindow::closeEvent(QCloseEvent* event) {
    if (worker_) {
        cancel_.cancel();
        worker_->wait(5000);
    }
    QWidget::closeEvent(event);
}
