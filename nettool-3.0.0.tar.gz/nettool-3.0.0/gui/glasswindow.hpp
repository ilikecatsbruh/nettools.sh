#pragma once

#include <QFrame>
#include <QMap>
#include <QString>
#include <QWidget>

#include <memory>

#include "tools.hpp"

class QLabel;
class QLineEdit;
class QListWidget;
class QListWidgetItem;
class QPlainTextEdit;
class QPushButton;
class QFormLayout;
class QSizeGrip;
class QThread;
class QTimer;

// A translucent rounded panel with a specular highlight and a bright rim.
class GlassPanel : public QFrame {
public:
    explicit GlassPanel(QWidget* parent = nullptr, qreal radius = 22.0, int alpha = 34);

protected:
    void paintEvent(QPaintEvent* event) override;

private:
    qreal radius_;
    int alpha_;
};

// Frameless, translucent main window drawing an animated "liquid" backdrop.
class GlassWindow : public QWidget {
public:
    explicit GlassWindow(QWidget* parent = nullptr);
    ~GlassWindow() override;

    // Called on the GUI thread (queued from the worker thread).
    void appendOutput(nt::Level level, const QString& text);

protected:
    void paintEvent(QPaintEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;
    void closeEvent(QCloseEvent* event) override;

private:
    void buildUi();
    void populateTools();
    void selectTool(QListWidgetItem* item);
    void runClicked();
    void cancelClicked();
    void launchInteractive(const nt::Args& args);
    void finished(int exitCode);
    void setRunning(bool running);

    class QtSink;

    QListWidget* toolList_ = nullptr;
    QLabel* titleLabel_ = nullptr;
    QLabel* descLabel_ = nullptr;
    QLabel* statusLabel_ = nullptr;
    QFormLayout* form_ = nullptr;
    QPlainTextEdit* output_ = nullptr;
    QPushButton* runBtn_ = nullptr;
    QPushButton* cancelBtn_ = nullptr;
    QSizeGrip* grip_ = nullptr;
    QTimer* animTimer_ = nullptr;

    QMap<QString, QLineEdit*> fields_;
    const nt::Tool* current_ = nullptr;
    QThread* worker_ = nullptr;
    std::unique_ptr<QtSink> sink_;
    nt::Cancel cancel_;
    double phase_ = 0.0;
    int glassOpacity_ = 66;   // percent; NETTOOL_GLASS_OPACITY overrides
};
