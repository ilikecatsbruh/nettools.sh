#pragma once

#include "core.hpp"

namespace nt {

struct Param {
    std::string key, label, placeholder;
    bool required = false;
    bool secret = false;      // masked in the GUI; never placed on a command line
    std::string def;
};

struct Tool {
    std::string id, category, title, description;
    std::vector<Param> params;
    bool interactive = false;  // needs a real terminal (ssh)
    std::function<int(const Args&, Sink&, const Cancel&)> run;
};

const std::vector<Tool>& tools();
const Tool* findTool(const std::string& id);

// ssh helpers (the GUI opens the command in a terminal emulator).
bool buildSshArgv(const Args& args, std::vector<std::string>& argv, std::string& err);
std::vector<std::string> terminalWrap(const std::vector<std::string>& argv);   // empty if no terminal found

int runDoctor(Sink& sink);
int runSelfTests(Sink& sink);

}  // namespace nt
