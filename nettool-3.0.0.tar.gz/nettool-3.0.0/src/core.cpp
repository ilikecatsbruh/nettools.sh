#include "core.hpp"

#include <algorithm>
#include <arpa/inet.h>
#include <cctype>
#include <cerrno>
#include <chrono>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <fstream>
#include <ifaddrs.h>
#include <mutex>
#include <net/if.h>
#include <netdb.h>
#include <netinet/in.h>
#include <poll.h>
#include <sstream>
#include <spawn.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <thread>
#include <unistd.h>

extern char** environ;

namespace nt {

// ------------------------------------------------------------------ text ----
std::string trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && std::isspace(static_cast<unsigned char>(s[a]))) ++a;
    while (b > a && std::isspace(static_cast<unsigned char>(s[b - 1]))) --b;
    return s.substr(a, b - a);
}

std::vector<std::string> split(const std::string& s, char sep) {
    std::vector<std::string> out;
    size_t start = 0;
    for (;;) {
        size_t pos = s.find(sep, start);
        if (pos == std::string::npos) { out.push_back(s.substr(start)); break; }
        out.push_back(s.substr(start, pos - start));
        start = pos + 1;
    }
    return out;
}

std::string sanitize(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (unsigned char ch : s) {
        if (ch == '\n' || ch == '\t') out.push_back(static_cast<char>(ch));
        else if (ch < 0x20 || ch == 0x7f) { if (ch != '\r') out.push_back('.'); }
        else out.push_back(static_cast<char>(ch));
    }
    return out;
}

std::string urlEncode(const std::string& s) {
    static const char* hex = "0123456789ABCDEF";
    std::string out;
    for (unsigned char ch : s) {
        if (std::isalnum(ch) || ch == '.' || ch == '~' || ch == '_' || ch == '-') out.push_back(static_cast<char>(ch));
        else { out.push_back('%'); out.push_back(hex[ch >> 4]); out.push_back(hex[ch & 15]); }
    }
    return out;
}

std::string formatRate(uint64_t b) {
    char buf[48];
    if (b >= 1048576) std::snprintf(buf, sizeof buf, "%llu.%02llu MB/s", (unsigned long long)(b / 1048576), (unsigned long long)((b % 1048576) * 100 / 1048576));
    else if (b >= 1024) std::snprintf(buf, sizeof buf, "%llu.%02llu KB/s", (unsigned long long)(b / 1024), (unsigned long long)((b % 1024) * 100 / 1024));
    else std::snprintf(buf, sizeof buf, "%llu B/s", (unsigned long long)b);
    return buf;
}

void LineBuffer::feed(const std::string& chunk, const std::function<void(const std::string&)>& emit) {
    buf_ += chunk;
    size_t pos;
    while ((pos = buf_.find('\n')) != std::string::npos) {
        std::string line = buf_.substr(0, pos);
        buf_.erase(0, pos + 1);
        if (!line.empty() && line.back() == '\r') line.pop_back();
        emit(line);
    }
    if (buf_.size() > 65536) { emit(buf_); buf_.clear(); }   // never grow without bound
}

void LineBuffer::flush(const std::function<void(const std::string&)>& emit) {
    if (!buf_.empty()) { emit(buf_); buf_.clear(); }
}

// ------------------------------------------------------------ validation ----
static bool allDigits(const std::string& s) {
    return !s.empty() && std::all_of(s.begin(), s.end(), [](unsigned char c) { return std::isdigit(c) != 0; });
}

bool isIPv4(const std::string& s) {
    auto parts = split(s, '.');
    if (parts.size() != 4) return false;
    for (const auto& p : parts) {
        if (!allDigits(p) || p.size() > 3 || std::stoi(p) > 255) return false;
    }
    return true;
}

bool isIPv6Literal(const std::string& s) {
    if (s.empty() || s.size() > 45) return false;
    in6_addr a;
    return inet_pton(AF_INET6, s.c_str(), &a) == 1;
}

bool isValidHost(const std::string& hostIn) {
    if (hostIn.empty() || hostIn.size() > 253 || hostIn[0] == '-') return false;
    if (hostIn.find(':') != std::string::npos) return isIPv6Literal(hostIn);
    for (unsigned char ch : hostIn) {
        if (!std::isalnum(ch) && ch != '.' && ch != '-') return false;
    }
    if (hostIn[0] == '.' || hostIn.find("..") != std::string::npos) return false;
    std::string host = hostIn;
    if (host.back() == '.') host.pop_back();
    if (host.empty()) return false;
    if (std::all_of(host.begin(), host.end(), [](unsigned char c) { return std::isdigit(c) || c == '.'; }))
        return isIPv4(host);   // looks numeric: it must be a well-formed dotted quad
    for (const auto& label : split(host, '.')) {
        if (label.empty() || label.size() > 63) return false;
        if (label.front() == '-' || label.back() == '-') return false;
    }
    return true;
}

bool isValidPort(const std::string& s, int* out) {
    if (!allDigits(s) || s.size() > 5) return false;
    int v = std::stoi(s);
    if (v < 1 || v > 65535) return false;
    if (out) *out = v;
    return true;
}

bool isPositiveInt(const std::string& s, long maxValue, long* out) {
    if (!allDigits(s) || s.size() > 9) return false;
    long v = std::stol(s);
    if (v < 1 || v > maxValue) return false;
    if (out) *out = v;
    return true;
}

bool isValidPrefix(const std::string& s) {
    auto parts = split(s, '.');
    if (parts.size() != 3) return false;
    for (const auto& p : parts) {
        if (!allDigits(p) || p.size() > 3 || std::stoi(p) > 255) return false;
    }
    return true;
}

bool isValidEmail(const std::string& s) {
    auto at = s.find('@');
    if (at == std::string::npos || at != s.rfind('@') || at == 0 || at + 1 >= s.size()) return false;
    std::string local = s.substr(0, at), domain = s.substr(at + 1);
    for (unsigned char ch : local) {
        if (!std::isalnum(ch) && std::strchr("._%+-", ch) == nullptr) return false;
    }
    return domain.find(':') == std::string::npos && isValidHost(domain);
}

bool isValidUrl(const std::string& s) {
    size_t i = 0;
    if (s.rfind("https://", 0) == 0) i = 8;
    else if (s.rfind("http://", 0) == 0) i = 7;
    else return false;
    size_t hostStart = i;
    while (i < s.size() && (std::isalnum(static_cast<unsigned char>(s[i])) || s[i] == '.' || s[i] == '-')) ++i;
    if (i == hostStart) return false;
    if (i < s.size() && s[i] == ':') {
        size_t p = ++i;
        while (i < s.size() && std::isdigit(static_cast<unsigned char>(s[i]))) ++i;
        if (i == p) return false;
    }
    if (i == s.size()) return true;
    if (s[i] != '/' && s[i] != '?' && s[i] != '#') return false;
    for (; i < s.size(); ++i) {
        if (std::isspace(static_cast<unsigned char>(s[i])) || static_cast<unsigned char>(s[i]) < 0x20) return false;
    }
    return true;
}

bool isValidIface(const std::string& s) {
    if (s.empty() || s.size() > 32) return false;
    if (!std::isalnum(static_cast<unsigned char>(s[0])) && s[0] != '_') return false;
    for (unsigned char ch : s) {
        if (!std::isalnum(ch) && ch != '.' && ch != '_' && ch != '-') return false;
    }
    return true;
}

// ------------------------------------------------------------------ CIDR ----
static std::string ipText(uint32_t v) {
    char b[20];
    std::snprintf(b, sizeof b, "%u.%u.%u.%u", (v >> 24) & 255u, (v >> 16) & 255u, (v >> 8) & 255u, v & 255u);
    return b;
}

bool calcCidr(const std::string& input, CidrInfo& o, std::string& err) {
    auto slash = input.find('/');
    if (slash == std::string::npos) { err = "Use IPv4 CIDR notation, e.g. 192.168.1.0/24."; return false; }
    std::string ip = input.substr(0, slash), bitsText = input.substr(slash + 1);
    if (!isIPv4(ip) || !allDigits(bitsText) || bitsText.size() > 2 || std::stoi(bitsText) > 32) {
        err = "Invalid address or prefix length (must be 0-32).";
        return false;
    }
    int bits = std::stoi(bitsText);
    uint32_t addr = 0;
    for (const auto& part : split(ip, '.')) addr = (addr << 8) | static_cast<uint32_t>(std::stoi(part));
    uint32_t mask = bits == 0 ? 0u : (0xFFFFFFFFu << (32 - bits));
    uint32_t net = addr & mask, bcast = net | ~mask;
    o.bits = bits;
    o.address = ip + "/" + std::to_string(bits);
    o.netmask = ipText(mask);
    o.wildcard = ipText(~mask);
    o.network = ipText(net);
    o.broadcast = ipText(bcast);
    if (bits >= 31) {
        o.first = ipText(net); o.last = ipText(bcast); o.hosts = 1ull << (32 - bits);
    } else {
        o.first = ipText(net + 1); o.last = ipText(bcast - 1); o.hosts = (1ull << (32 - bits)) - 2;
    }
    return true;
}

// ------------------------------------------------------------------ JSON ----
const Json* Json::get(const std::string& key) const {
    if (type != Type::Object) return nullptr;
    for (const auto& kv : obj) if (kv.first == key) return &kv.second;
    return nullptr;
}

std::string Json::asString(const std::string& fallback) const {
    switch (type) {
        case Type::String: return str;
        case Type::Number: {
            char b[48];
            if (number == static_cast<double>(static_cast<long long>(number))) std::snprintf(b, sizeof b, "%lld", static_cast<long long>(number));
            else std::snprintf(b, sizeof b, "%g", number);
            return b;
        }
        case Type::Bool: return boolean ? "true" : "false";
        default: return fallback;
    }
}

namespace {
struct JsonParser {
    const std::string& t;
    size_t i = 0;
    explicit JsonParser(const std::string& text) : t(text) {}

    void ws() { while (i < t.size() && std::isspace(static_cast<unsigned char>(t[i]))) ++i; }
    bool lit(const char* w) {
        size_t n = std::strlen(w);
        if (t.compare(i, n, w) == 0) { i += n; return true; }
        return false;
    }
    static void utf8(std::string& o, unsigned cp) {
        if (cp < 0x80) o.push_back(static_cast<char>(cp));
        else if (cp < 0x800) { o.push_back(static_cast<char>(0xC0 | (cp >> 6))); o.push_back(static_cast<char>(0x80 | (cp & 0x3F))); }
        else if (cp < 0x10000) { o.push_back(static_cast<char>(0xE0 | (cp >> 12))); o.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F))); o.push_back(static_cast<char>(0x80 | (cp & 0x3F))); }
        else { o.push_back(static_cast<char>(0xF0 | (cp >> 18))); o.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F))); o.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F))); o.push_back(static_cast<char>(0x80 | (cp & 0x3F))); }
    }
    bool hex4(unsigned& v) {
        if (i + 4 > t.size()) return false;
        v = 0;
        for (int k = 0; k < 4; ++k) {
            char c = t[i++];
            v <<= 4;
            if (c >= '0' && c <= '9') v |= static_cast<unsigned>(c - '0');
            else if (c >= 'a' && c <= 'f') v |= static_cast<unsigned>(c - 'a' + 10);
            else if (c >= 'A' && c <= 'F') v |= static_cast<unsigned>(c - 'A' + 10);
            else return false;
        }
        return true;
    }
    bool string(std::string& out) {
        if (i >= t.size() || t[i] != '"') return false;
        ++i;
        while (i < t.size()) {
            char c = t[i++];
            if (c == '"') return true;
            if (static_cast<unsigned char>(c) < 0x20) return false;
            if (c != '\\') { out.push_back(c); continue; }
            if (i >= t.size()) return false;
            char e = t[i++];
            switch (e) {
                case '"': out.push_back('"'); break;
                case '\\': out.push_back('\\'); break;
                case '/': out.push_back('/'); break;
                case 'b': out.push_back('\b'); break;
                case 'f': out.push_back('\f'); break;
                case 'n': out.push_back('\n'); break;
                case 'r': out.push_back('\r'); break;
                case 't': out.push_back('\t'); break;
                case 'u': {
                    unsigned cp;
                    if (!hex4(cp)) return false;
                    if (cp >= 0xD800 && cp < 0xDC00 && i + 1 < t.size() && t[i] == '\\' && t[i + 1] == 'u') {
                        i += 2;
                        unsigned lo;
                        if (!hex4(lo) || lo < 0xDC00 || lo > 0xDFFF) return false;
                        cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                    }
                    utf8(out, cp);
                    break;
                }
                default: return false;
            }
        }
        return false;
    }
    bool value(Json& out, int depth) {
        if (depth > 64) return false;
        ws();
        if (i >= t.size()) return false;
        char c = t[i];
        if (c == '{') {
            ++i; out.type = Json::Type::Object; ws();
            if (i < t.size() && t[i] == '}') { ++i; return true; }
            for (;;) {
                ws();
                std::string key;
                if (!string(key)) return false;
                ws();
                if (i >= t.size() || t[i++] != ':') return false;
                Json v;
                if (!value(v, depth + 1)) return false;
                out.obj.emplace_back(std::move(key), std::move(v));
                ws();
                if (i >= t.size()) return false;
                if (t[i] == ',') { ++i; continue; }
                if (t[i] == '}') { ++i; return true; }
                return false;
            }
        }
        if (c == '[') {
            ++i; out.type = Json::Type::Array; ws();
            if (i < t.size() && t[i] == ']') { ++i; return true; }
            for (;;) {
                Json v;
                if (!value(v, depth + 1)) return false;
                out.arr.push_back(std::move(v));
                ws();
                if (i >= t.size()) return false;
                if (t[i] == ',') { ++i; continue; }
                if (t[i] == ']') { ++i; return true; }
                return false;
            }
        }
        if (c == '"') { out.type = Json::Type::String; return string(out.str); }
        if (lit("true")) { out.type = Json::Type::Bool; out.boolean = true; return true; }
        if (lit("false")) { out.type = Json::Type::Bool; out.boolean = false; return true; }
        if (lit("null")) { out.type = Json::Type::Null; return true; }
        if (c == '-' || std::isdigit(static_cast<unsigned char>(c))) {
            const char* start = t.c_str() + i;
            char* end = nullptr;
            double d = std::strtod(start, &end);
            if (end == start) return false;
            i += static_cast<size_t>(end - start);
            out.type = Json::Type::Number; out.number = d;
            return true;
        }
        return false;
    }
};
}  // namespace

bool Json::parse(const std::string& text, Json& out) {
    JsonParser p(text);
    out = Json();
    if (!p.value(out, 0)) return false;
    p.ws();
    return p.i == text.size();
}

// ------------------------------------------------------------- processes ----
bool commandExists(const std::string& name) {
    if (name.empty()) return false;
    auto executable = [](const std::string& path) {
        struct stat st;
        return ::stat(path.c_str(), &st) == 0 && S_ISREG(st.st_mode) && ::access(path.c_str(), X_OK) == 0;
    };
    if (name.find('/') != std::string::npos) return executable(name);
    const char* pathEnv = std::getenv("PATH");
    if (!pathEnv) return false;
    for (const auto& dir : split(pathEnv, ':')) {
        if (executable((dir.empty() ? std::string(".") : dir) + "/" + name)) return true;
    }
    return false;
}

int runProcess(const std::vector<std::string>& argv, const std::string& stdinData,
               const std::function<void(const std::string&)>& onOutput, const Cancel* cancel, int timeoutMs) {
    static std::once_flag once;
    std::call_once(once, [] { std::signal(SIGPIPE, SIG_IGN); });

    if (argv.empty() || !commandExists(argv[0])) return -1;
    int outPipe[2], inPipe[2];
    if (::pipe(outPipe) != 0) return -1;
    if (::pipe(inPipe) != 0) { ::close(outPipe[0]); ::close(outPipe[1]); return -1; }
    for (int fd : {outPipe[0], outPipe[1], inPipe[0], inPipe[1]}) ::fcntl(fd, F_SETFD, FD_CLOEXEC);

    posix_spawn_file_actions_t fa;
    posix_spawnattr_t attr;
    posix_spawn_file_actions_init(&fa);
    posix_spawnattr_init(&attr);
    posix_spawn_file_actions_adddup2(&fa, inPipe[0], 0);
    posix_spawn_file_actions_adddup2(&fa, outPipe[1], 1);
    posix_spawn_file_actions_adddup2(&fa, outPipe[1], 2);
    posix_spawnattr_setflags(&attr, POSIX_SPAWN_SETPGROUP);
    posix_spawnattr_setpgroup(&attr, 0);

    std::vector<char*> cargv;
    for (const auto& a : argv) cargv.push_back(const_cast<char*>(a.c_str()));
    cargv.push_back(nullptr);

    pid_t pid = 0;
    int rc = posix_spawnp(&pid, cargv[0], &fa, &attr, cargv.data(), environ);
    posix_spawn_file_actions_destroy(&fa);
    posix_spawnattr_destroy(&attr);
    ::close(inPipe[0]);
    ::close(outPipe[1]);
    if (rc != 0) { ::close(inPipe[1]); ::close(outPipe[0]); return -1; }

    size_t sent = 0;
    while (sent < stdinData.size()) {
        ssize_t n = ::write(inPipe[1], stdinData.data() + sent, stdinData.size() - sent);
        if (n < 0) { if (errno == EINTR) continue; break; }
        sent += static_cast<size_t>(n);
    }
    ::close(inPipe[1]);

    auto start = std::chrono::steady_clock::now();
    bool cancelled = false, timedOut = false;
    pollfd pfd{outPipe[0], POLLIN, 0};
    char buf[4096];
    for (;;) {
        if (cancel && cancel->cancelled()) { cancelled = true; break; }
        if (timeoutMs > 0 && std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - start).count() >= timeoutMs) {
            timedOut = true;
            break;
        }
        int pr = ::poll(&pfd, 1, 100);
        if (pr < 0) { if (errno == EINTR) continue; break; }
        if (pr == 0) continue;
        ssize_t n = ::read(outPipe[0], buf, sizeof buf);
        if (n > 0) { if (onOutput) onOutput(std::string(buf, static_cast<size_t>(n))); }
        else if (n == 0) break;
        else if (errno != EINTR && errno != EAGAIN) break;
    }
    ::close(outPipe[0]);

    int status = 0;
    if (cancelled || timedOut) {
        ::killpg(pid, SIGTERM);
        ::kill(pid, SIGTERM);
        for (int i = 0; i < 20; ++i) {
            if (::waitpid(pid, &status, WNOHANG) == pid) return cancelled ? -2 : -3;
            std::this_thread::sleep_for(std::chrono::milliseconds(25));
        }
        ::killpg(pid, SIGKILL);
        ::kill(pid, SIGKILL);
        ::waitpid(pid, &status, 0);
        return cancelled ? -2 : -3;
    }
    while (::waitpid(pid, &status, 0) < 0 && errno == EINTR) {}
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return 1;
}

std::string captureProcess(const std::vector<std::string>& argv, const std::string& stdinData,
                           int* status, const Cancel* cancel, int timeoutMs) {
    std::string out;
    int rc = runProcess(argv, stdinData, [&out](const std::string& chunk) {
        if (out.size() < (1u << 20)) out += chunk;   // cap captured output at 1 MiB
    }, cancel, timeoutMs);
    if (status) *status = rc;
    return out;
}

// --------------------------------------------------------------- network ----
std::vector<Endpoint> resolveHost(const std::string& host, int port, int socktype, std::string& err) {
    addrinfo hints{};
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = socktype;
    addrinfo* res = nullptr;
    std::string portText = std::to_string(port);
    int rc = ::getaddrinfo(host.c_str(), portText.c_str(), &hints, &res);
    if (rc != 0) { err = ::gai_strerror(rc); return {}; }
    std::vector<Endpoint> out;
    for (addrinfo* ai = res; ai; ai = ai->ai_next) {
        if (ai->ai_addrlen > sizeof(sockaddr_storage)) continue;
        Endpoint e;
        std::memcpy(&e.addr, ai->ai_addr, ai->ai_addrlen);
        e.len = static_cast<socklen_t>(ai->ai_addrlen);
        e.family = ai->ai_family;
        out.push_back(e);
    }
    ::freeaddrinfo(res);
    if (out.empty()) err = "no usable address";
    return out;
}

std::string endpointText(const Endpoint& ep) {
    char host[NI_MAXHOST] = "?";
    ::getnameinfo(reinterpret_cast<const sockaddr*>(&ep.addr), ep.len, host, sizeof host, nullptr, 0, NI_NUMERICHOST);
    return host;
}

int connectEndpoint(const Endpoint& ep, int timeoutMs, const Cancel* cancel, std::string* err) {
    int fd = ::socket(ep.family, SOCK_STREAM, 0);
    if (fd < 0) { if (err) *err = std::strerror(errno); return -1; }
    ::fcntl(fd, F_SETFD, FD_CLOEXEC);
    ::fcntl(fd, F_SETFL, ::fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
    if (::connect(fd, reinterpret_cast<const sockaddr*>(&ep.addr), ep.len) == 0) return fd;
    if (errno != EINPROGRESS) { if (err) *err = std::strerror(errno); ::close(fd); return -1; }

    auto start = std::chrono::steady_clock::now();
    for (;;) {
        if (cancel && cancel->cancelled()) { if (err) *err = "cancelled"; ::close(fd); return -1; }
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - start).count();
        if (elapsed >= timeoutMs) { if (err) *err = "timed out"; ::close(fd); return -1; }
        pollfd pfd{fd, POLLOUT, 0};
        int pr = ::poll(&pfd, 1, static_cast<int>(std::min<long long>(100, timeoutMs - elapsed)));
        if (pr < 0 && errno != EINTR) { if (err) *err = std::strerror(errno); ::close(fd); return -1; }
        if (pr > 0) {
            int soerr = 0;
            socklen_t sl = sizeof soerr;
            ::getsockopt(fd, SOL_SOCKET, SO_ERROR, &soerr, &sl);
            if (soerr == 0) return fd;
            if (err) *err = std::strerror(soerr);
            ::close(fd);
            return -1;
        }
    }
}

std::string readSome(int fd, int waitMs, size_t maxBytes) {
    pollfd pfd{fd, POLLIN, 0};
    if (::poll(&pfd, 1, waitMs) <= 0) return "";
    std::string out(maxBytes, '\0');
    ssize_t n = ::read(fd, &out[0], maxBytes);
    if (n <= 0) return "";
    out.resize(static_cast<size_t>(n));
    return out;
}

bool sleepCancellable(int ms, const Cancel& cancel) {
    for (int waited = 0; waited < ms; waited += 50) {
        if (cancel.cancelled()) return false;
        std::this_thread::sleep_for(std::chrono::milliseconds(std::min(50, ms - waited)));
    }
    return !cancel.cancelled();
}

// ----------------------------------------------------------- system info ----
static std::string readFirstLine(const std::string& path) {
    std::ifstream f(path);
    std::string line;
    std::getline(f, line);
    return trim(line);
}

static std::string hexToAddr(const std::string& hex) {
    char buf[INET6_ADDRSTRLEN] = "?";
    try {
        if (hex.size() == 8) {
            in_addr a;
            a.s_addr = static_cast<uint32_t>(std::stoul(hex, nullptr, 16));
            inet_ntop(AF_INET, &a, buf, sizeof buf);
        } else if (hex.size() == 32) {
            in6_addr a;
            for (int w = 0; w < 4; ++w) {
                uint32_t word = static_cast<uint32_t>(std::stoul(hex.substr(static_cast<size_t>(w) * 8, 8), nullptr, 16));
                std::memcpy(a.s6_addr + w * 4, &word, 4);
            }
            inet_ntop(AF_INET6, &a, buf, sizeof buf);
        }
    } catch (...) {}
    return buf;
}

Route defaultRoute() {
    Route r;
    std::ifstream f("/proc/net/route");
    std::string line;
    std::getline(f, line);   // header
    while (std::getline(f, line)) {
        std::istringstream ss(line);
        std::string iface, dest, gw, flags;
        if (!(ss >> iface >> dest >> gw >> flags)) continue;
        if (dest == "00000000" && gw != "00000000") {
            r.ok = true; r.iface = iface; r.gateway = hexToAddr(gw);
            return r;
        }
    }
    return r;
}

bool readProcSockets(std::vector<SockEntry>& out) {
    struct Src { const char* path; const char* proto; };
    static const Src srcs[] = {{"/proc/net/tcp", "tcp"}, {"/proc/net/tcp6", "tcp6"},
                               {"/proc/net/udp", "udp"}, {"/proc/net/udp6", "udp6"}};
    bool any = false;
    for (const auto& src : srcs) {
        std::ifstream f(src.path);
        if (!f) continue;
        any = true;
        std::string line;
        std::getline(f, line);
        while (std::getline(f, line)) {
            std::istringstream ss(line);
            std::string sl, local, remote, st;
            if (!(ss >> sl >> local >> remote >> st)) continue;
            auto colon = local.rfind(':');
            if (colon == std::string::npos) continue;
            SockEntry e;
            e.proto = src.proto;
            try { e.port = static_cast<int>(std::stoul(local.substr(colon + 1), nullptr, 16)); } catch (...) { continue; }
            std::string addr = hexToAddr(local.substr(0, colon));
            e.local = (addr.find(':') != std::string::npos ? "[" + addr + "]" : addr) + ":" + std::to_string(e.port);
            if (e.proto[0] == 't') e.state = st == "0A" ? "LISTEN" : st == "01" ? "ESTABLISHED" : "OTHER";
            else e.state = "UNCONN";
            out.push_back(e);
        }
    }
    return any;
}

std::vector<std::string> listInterfaces() {
    std::vector<std::string> names;
    ifaddrs* ifs = nullptr;
    if (::getifaddrs(&ifs) != 0) return names;
    for (ifaddrs* p = ifs; p; p = p->ifa_next) {
        std::string n = p->ifa_name ? p->ifa_name : "";
        if (!n.empty() && std::find(names.begin(), names.end(), n) == names.end()) names.push_back(n);
    }
    ::freeifaddrs(ifs);
    return names;
}

std::string defaultInterface() {
    Route r = defaultRoute();
    if (r.ok) return r.iface;
    std::vector<std::string> names = listInterfaces();
    for (const char* prefix : {"wlan", "wl", "eth", "en", "rmnet"}) {
        for (const auto& n : names) if (n.rfind(prefix, 0) == 0) return n;
    }
    for (const auto& n : names) if (n != "lo" && n != "lo0") return n;
    return "";
}

bool readIfaceCounters(const std::string& iface, uint64_t& rx, uint64_t& tx) {
    if (!isValidIface(iface)) return false;
    auto number = [](const std::string& s, uint64_t& v) {
        if (!allDigits(s) || s.size() > 20) return false;
        v = std::strtoull(s.c_str(), nullptr, 10);
        return true;
    };
    // 1) sysfs
    std::string base = "/sys/class/net/" + iface + "/statistics/";
    if (number(readFirstLine(base + "rx_bytes"), rx) && number(readFirstLine(base + "tx_bytes"), tx)) return true;
    // 2) /proc/net/dev
    std::ifstream f("/proc/net/dev");
    std::string line;
    while (std::getline(f, line)) {
        auto colon = line.find(':');
        if (colon == std::string::npos || trim(line.substr(0, colon)) != iface) continue;
        std::istringstream ss(line.substr(colon + 1));
        std::vector<std::string> cols;
        for (std::string c; ss >> c;) cols.push_back(c);
        if (cols.size() >= 9 && number(cols[0], rx) && number(cols[8], tx)) return true;
    }
    // 3) ip -s link
    if (commandExists("ip")) {
        std::string out = captureProcess({"ip", "-s", "link", "show", "dev", iface}, "", nullptr, nullptr, 3000);
        std::istringstream ss(out);
        bool haveRx = false, haveTx = false;
        for (std::string l; std::getline(ss, l);) {
            std::string t = trim(l);
            if (t.rfind("RX:", 0) == 0 || t.rfind("TX:", 0) == 0) {
                bool isRx = t[0] == 'R';
                std::string next;
                if (!std::getline(ss, next)) break;
                std::istringstream ns(next);
                std::string first;
                ns >> first;
                if (isRx && number(first, rx)) haveRx = true;
                if (!isRx && number(first, tx)) haveTx = true;
            }
        }
        return haveRx && haveTx;
    }
    return false;
}

std::string detectLocalPrefix() {
    std::string preferred = defaultInterface();
    ifaddrs* ifs = nullptr;
    if (::getifaddrs(&ifs) != 0) return "";
    std::string best, fallback;
    for (ifaddrs* p = ifs; p; p = p->ifa_next) {
        if (!p->ifa_addr || p->ifa_addr->sa_family != AF_INET || (p->ifa_flags & IFF_LOOPBACK)) continue;
        char buf[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &reinterpret_cast<sockaddr_in*>(p->ifa_addr)->sin_addr, buf, sizeof buf);
        std::string ip = buf;
        std::string prefix = ip.substr(0, ip.rfind('.'));
        if (preferred == p->ifa_name) { best = prefix; break; }
        if (fallback.empty()) fallback = prefix;
    }
    ::freeifaddrs(ifs);
    return best.empty() ? fallback : best;
}

// ---------------------------------------------------------- concurrency ----
static int envLimit(const char* name, int fallback) {
    const char* v = std::getenv(name);
    long n;
    if (v && isPositiveInt(v, 254, &n)) return static_cast<int>(n);
    return fallback;
}

int maxParallelProbe() { return envLimit("NETTOOL_MAX_PARALLEL_PROBE", 50); }
int maxParallelSweep() { return envLimit("NETTOOL_MAX_PARALLEL_SWEEP", 40); }

bool validateLimits(std::string& err) {
    for (const char* name : {"NETTOOL_MAX_PARALLEL_PROBE", "NETTOOL_MAX_PARALLEL_SWEEP"}) {
        const char* v = std::getenv(name);
        if (v && !isPositiveInt(v, 254)) {
            err = std::string(name) + " must be an integer from 1 to 254.";
            return false;
        }
    }
    return true;
}

void parallelFor(size_t n, int maxThreads, const Cancel& cancel, const std::function<void(size_t)>& fn) {
    if (n == 0) return;
    std::atomic<size_t> next{0};
    size_t workers = std::min<size_t>(n, static_cast<size_t>(std::max(1, maxThreads)));
    std::vector<std::thread> pool;
    for (size_t t = 0; t < workers; ++t) {
        pool.emplace_back([&] {
            while (!cancel.cancelled()) {
                size_t i = next.fetch_add(1);
                if (i >= n) break;
                fn(i);
            }
        });
    }
    for (auto& th : pool) th.join();
}

}  // namespace nt
