#include "tools.hpp"

#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <mutex>
#include <unistd.h>

using namespace nt;

namespace {

Cancel g_cancel;
void onSignal(int) { g_cancel.cancel(); }

class CliSink : public Sink {
public:
    CliSink() : color_(isatty(STDOUT_FILENO) && !std::getenv("NO_COLOR")) {}
    void write(Level level, const std::string& text) override {
        std::lock_guard<std::mutex> g(m_);
        const char* c = "";
        if (color_) {
            switch (level) {
                case Level::Heading: c = "\033[1;36m"; break;
                case Level::Good: c = "\033[32m"; break;
                case Level::Warn: c = "\033[33m"; break;
                case Level::Bad: c = "\033[31m"; break;
                case Level::Dim: c = "\033[2m"; break;
                default: break;
            }
        }
        std::fputs(c, stdout);
        std::fputs(text.c_str(), stdout);
        if (*c) std::fputs("\033[0m", stdout);
        std::fflush(stdout);
    }
private:
    bool color_;
    std::mutex m_;
};

void printHelp() {
    std::printf("nettool %s - network toolkit (CLI)\n\nUsage: nettool-cli <command> [arguments]\n", kVersion);
    std::string category;
    for (const auto& t : tools()) {
        if (t.category != category) { category = t.category; std::printf("\n%s:\n", category.c_str()); }
        std::string usage = t.id;
        for (const auto& p : t.params) usage += p.required ? " <" + p.key + ">" : " [" + p.key + "]";
        std::printf("  %-34s %s\n", usage.c_str(), t.description.c_str());
    }
    std::printf("\nOther:\n  %-34s %s\n  %-34s %s\n  %-34s %s\n", "doctor", "Report which helper programs are installed",
                "self-test", "Run the offline self-tests", "--list", "List command names");
    std::printf("\nEnvironment: NO_COLOR, NETTOOL_MAX_PARALLEL_PROBE, NETTOOL_MAX_PARALLEL_SWEEP, HIBP_API_KEY\n");
    std::printf("Only test systems and networks you own or have explicit permission to assess.\n");
}

}  // namespace

int main(int argc, char** argv) {
    std::signal(SIGINT, onSignal);
    std::signal(SIGTERM, onSignal);
    CliSink sink;
    if (argc < 2) { printHelp(); return 0; }
    std::string cmd = argv[1];
    if (cmd == "--help" || cmd == "-h" || cmd == "help") { printHelp(); return 0; }
    if (cmd == "--version") { std::printf("nettool %s\n", kVersion); return 0; }
    if (cmd == "--list") { for (const auto& t : tools()) std::printf("%s\n", t.id.c_str()); return 0; }
    if (cmd == "self-test") return runSelfTests(sink);
    if (cmd == "doctor") return runDoctor(sink);

    std::string limitErr;
    if (!validateLimits(limitErr)) { sink.error(limitErr); return 2; }

    const Tool* tool = findTool(cmd);
    if (!tool) { sink.error("Unknown command '" + cmd + "'. Try: nettool-cli --help"); return 2; }

    // ssh: pass everything straight through, replacing this process.
    if (tool->id == "ssh") {
        if (argc < 3) { sink.error("Usage: nettool-cli ssh <ssh arguments...>"); return 2; }
        if (!commandExists("ssh")) { sink.error("'ssh' is not installed."); return 1; }
        std::vector<char*> args = {const_cast<char*>("ssh")};
        for (int i = 2; i < argc; ++i) args.push_back(argv[i]);
        args.push_back(nullptr);
        ::execvp("ssh", args.data());
        sink.error("Could not start ssh.");
        return 1;
    }

    Args args;
    int positional = argc - 2;
    if (static_cast<size_t>(positional) > tool->params.size()) {
        sink.error("Too many arguments for '" + tool->id + "'. Try: nettool-cli --help");
        return 2;
    }
    for (int i = 0; i < positional; ++i) {
        const Param& p = tool->params[static_cast<size_t>(i)];
        if (p.secret) {
            sink.error("Don't pass secrets on the command line (they show up in the process list). Use the HIBP_API_KEY environment variable.");
            return 2;
        }
        args[p.key] = argv[2 + i];
    }
    for (const auto& p : tool->params) {
        if (!args.count(p.key) && !p.def.empty()) args[p.key] = p.def;
        if (p.required && args[p.key].empty()) {
            if (!isatty(STDIN_FILENO)) { sink.error("Missing required argument <" + p.key + ">."); return 2; }
            std::printf("%s: ", p.label.c_str());
            std::fflush(stdout);
            std::string line;
            if (!std::getline(std::cin, line)) return 1;
            args[p.key] = line;
        }
    }
    int rc = tool->run(args, sink, g_cancel);
    return g_cancel.cancelled() ? 130 : rc;
}
