#include "core.hpp"

#include <arpa/inet.h>
#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <poll.h>
#include <random>
#include <unistd.h>

namespace nt {

std::vector<uint8_t> buildDnsQuery(const std::string& nameIn, uint16_t qtype, uint16_t id, std::string& err) {
    std::string name = nameIn;
    if (!name.empty() && name.back() == '.') name.pop_back();
    if (name.empty() || name.size() > 253) { err = "invalid DNS name length"; return {}; }
    std::vector<uint8_t> q = {static_cast<uint8_t>(id >> 8), static_cast<uint8_t>(id & 0xFF),
                              0x01, 0x00,    // flags: recursion desired
                              0x00, 0x01,    // one question
                              0, 0, 0, 0, 0, 0};
    for (const auto& label : split(name, '.')) {
        if (label.empty() || label.size() > 63) { err = "invalid DNS label length"; return {}; }
        q.push_back(static_cast<uint8_t>(label.size()));
        q.insert(q.end(), label.begin(), label.end());
    }
    q.push_back(0);
    q.push_back(static_cast<uint8_t>(qtype >> 8));
    q.push_back(static_cast<uint8_t>(qtype & 0xFF));
    q.push_back(0x00);
    q.push_back(0x01);   // class IN
    return q;
}

namespace {

// Reads a (possibly compressed) name starting at pos. On success pos is moved
// past the name as it appears at the original location.
bool readName(const uint8_t* d, size_t len, size_t& pos, std::string& out) {
    out.clear();
    size_t p = pos, after = 0;
    bool jumped = false;
    int hops = 0;
    for (;;) {
        if (p >= len) return false;
        uint8_t l = d[p];
        if (l == 0) {
            ++p;
            if (!jumped) after = p;
            break;
        }
        if ((l & 0xC0) == 0xC0) {
            if (p + 1 >= len) return false;
            size_t ptr = (static_cast<size_t>(l & 0x3F) << 8) | d[p + 1];
            if (!jumped) { after = p + 2; jumped = true; }
            if (++hops > 20 || ptr >= len) return false;
            p = ptr;
            continue;
        }
        if (l & 0xC0) return false;   // reserved label type
        if (p + 1 + l > len) return false;
        if (!out.empty()) out.push_back('.');
        out.append(reinterpret_cast<const char*>(d + p + 1), l);
        if (out.size() > 255) return false;
        p += 1 + static_cast<size_t>(l);
    }
    if (out.empty()) out = ".";
    pos = after;
    return true;
}

uint16_t be16(const uint8_t* p) { return static_cast<uint16_t>((p[0] << 8) | p[1]); }

}  // namespace

bool parseDnsResponse(const uint8_t* d, size_t len, uint16_t expectId, DnsResult& out, bool& truncated) {
    truncated = false;
    if (len < 12) return false;
    if (be16(d) != expectId) return false;
    uint16_t flags = be16(d + 2);
    if (!(flags & 0x8000)) return false;
    truncated = (flags & 0x0200) != 0;
    out.rcode = flags & 0x0F;
    size_t qd = be16(d + 4), an = be16(d + 6);
    size_t pos = 12;
    std::string name;
    for (size_t i = 0; i < qd; ++i) {
        if (!readName(d, len, pos, name) || pos + 4 > len) return false;
        pos += 4;
    }
    if (an > 100) an = 100;
    for (size_t i = 0; i < an; ++i) {
        if (!readName(d, len, pos, name) || pos + 10 > len) return false;
        uint16_t type = be16(d + pos);
        uint16_t rdlen = be16(d + pos + 8);
        pos += 10;
        if (pos + rdlen > len) return false;
        size_t rd = pos, end = pos + rdlen;
        DnsRecord rec;
        char buf[INET6_ADDRSTRLEN];
        switch (type) {
            case T_A:
                if (rdlen != 4) return false;
                inet_ntop(AF_INET, d + rd, buf, sizeof buf);
                rec = {"A", buf};
                break;
            case T_AAAA:
                if (rdlen != 16) return false;
                inet_ntop(AF_INET6, d + rd, buf, sizeof buf);
                rec = {"AAAA", buf};
                break;
            case T_NS: case T_CNAME: case T_PTR: {
                std::string target;
                size_t p = rd;
                if (!readName(d, len, p, target)) return false;
                rec = {type == T_NS ? "NS" : type == T_CNAME ? "CNAME" : "PTR", sanitize(target)};
                break;
            }
            case T_MX: {
                if (rdlen < 3) return false;
                std::string target;
                size_t p = rd + 2;
                if (!readName(d, len, p, target)) return false;
                rec = {"MX", std::to_string(be16(d + rd)) + " " + sanitize(target)};
                break;
            }
            case T_TXT: {
                std::string text;
                size_t p = rd;
                while (p < end) {
                    size_t sl = d[p++];
                    if (p + sl > end) return false;
                    text.append(reinterpret_cast<const char*>(d + p), sl);
                    p += sl;
                }
                rec = {"TXT", "\"" + sanitize(text) + "\""};
                break;
            }
            default:
                pos = end;
                continue;
        }
        out.records.push_back(rec);
        pos = end;
    }
    out.ok = (out.rcode == 0);
    return true;
}

namespace {

bool readExact(int fd, uint8_t* buf, size_t n, std::chrono::steady_clock::time_point deadline, const Cancel* cancel) {
    size_t got = 0;
    while (got < n) {
        if (cancel && cancel->cancelled()) return false;
        auto left = std::chrono::duration_cast<std::chrono::milliseconds>(deadline - std::chrono::steady_clock::now()).count();
        if (left <= 0) return false;
        pollfd pfd{fd, POLLIN, 0};
        int pr = ::poll(&pfd, 1, static_cast<int>(std::min<long long>(100, left)));
        if (pr < 0 && errno != EINTR) return false;
        if (pr <= 0) continue;
        ssize_t r = ::read(fd, buf + got, n - got);
        if (r <= 0) return false;
        got += static_cast<size_t>(r);
    }
    return true;
}

bool dnsOverTcp(const std::string& server, int port, const std::vector<uint8_t>& query, uint16_t id,
                int timeoutMs, const Cancel* cancel, DnsResult& res) {
    std::string err;
    auto eps = resolveHost(server, port, SOCK_STREAM, err);
    if (eps.empty()) return false;
    int fd = connectEndpoint(eps[0], timeoutMs, cancel, &err);
    if (fd < 0) return false;
    auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);
    std::vector<uint8_t> framed = {static_cast<uint8_t>(query.size() >> 8), static_cast<uint8_t>(query.size() & 0xFF)};
    framed.insert(framed.end(), query.begin(), query.end());
    bool ok = ::write(fd, framed.data(), framed.size()) == static_cast<ssize_t>(framed.size());
    uint8_t lenBuf[2];
    ok = ok && readExact(fd, lenBuf, 2, deadline, cancel);
    size_t mlen = ok ? be16(lenBuf) : 0;
    std::vector<uint8_t> msg(mlen);
    ok = ok && mlen > 0 && readExact(fd, msg.data(), mlen, deadline, cancel);
    ::close(fd);
    bool tc = false;
    return ok && parseDnsResponse(msg.data(), msg.size(), id, res, tc);
}

}  // namespace

namespace {

// "host" or "host:port" (a single colon; IPv6 literals contain several).
bool splitServer(const std::string& spec, std::string& host, int& port) {
    host = spec;
    port = 53;
    auto colon = spec.rfind(':');
    if (colon != std::string::npos && spec.find(':') == colon) {
        host = spec.substr(0, colon);
        if (!isValidPort(spec.substr(colon + 1), &port)) return false;
    }
    return isValidHost(host);
}

}  // namespace

DnsResult dnsQuery(const std::string& server, const std::string& name, uint16_t qtype,
                   int timeoutMs, const Cancel* cancel) {
    DnsResult res;
    std::string err;
    std::random_device rdev;
    uint16_t id = static_cast<uint16_t>(rdev() & 0xFFFF);
    auto query = buildDnsQuery(name, qtype, id, err);
    if (query.empty()) { res.error = err; return res; }
    std::string serverHost;
    int serverPort = 53;
    if (!splitServer(server, serverHost, serverPort)) { res.error = "invalid DNS server '" + server + "'"; return res; }
    auto eps = resolveHost(serverHost, serverPort, SOCK_DGRAM, err);
    if (eps.empty()) { res.error = "cannot resolve DNS server " + serverHost + ": " + err; return res; }

    for (int attempt = 0; attempt < 2; ++attempt) {
        int fd = ::socket(eps[0].family, SOCK_DGRAM, 0);
        if (fd < 0) { res.error = std::strerror(errno); return res; }
        if (::sendto(fd, query.data(), query.size(), 0, reinterpret_cast<const sockaddr*>(&eps[0].addr), eps[0].len) < 0) {
            res.error = std::strerror(errno);
            ::close(fd);
            return res;
        }
        auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);
        for (;;) {
            if (cancel && cancel->cancelled()) { ::close(fd); res.error = "cancelled"; return res; }
            auto left = std::chrono::duration_cast<std::chrono::milliseconds>(deadline - std::chrono::steady_clock::now()).count();
            if (left <= 0) break;
            pollfd pfd{fd, POLLIN, 0};
            int pr = ::poll(&pfd, 1, static_cast<int>(std::min<long long>(100, left)));
            if (pr <= 0) continue;
            uint8_t buf[4096];
            ssize_t n = ::recvfrom(fd, buf, sizeof buf, 0, nullptr, nullptr);
            if (n <= 0) continue;
            DnsResult parsed;
            bool tc = false;
            if (!parseDnsResponse(buf, static_cast<size_t>(n), id, parsed, tc)) continue;   // wrong id or junk: keep waiting
            ::close(fd);
            if (tc) {
                DnsResult viaTcp;
                if (dnsOverTcp(serverHost, serverPort, query, id, timeoutMs, cancel, viaTcp)) return viaTcp;
                parsed.error = "response truncated and TCP retry failed";
            }
            return parsed;
        }
        ::close(fd);
    }
    res.error = "timed out";
    return res;
}

std::vector<std::string> systemResolvers() {
    std::vector<std::string> out;
    if (const char* over = std::getenv("NETTOOL_DNS_SERVERS")) {
        for (const auto& item : split(over, ',')) {
            std::string host;
            int port;
            std::string spec = trim(item);
            if (splitServer(spec, host, port)) out.push_back(spec);
        }
        if (!out.empty()) return out;
    }
    std::vector<std::string> files = {"/etc/resolv.conf"};
    if (const char* prefix = std::getenv("PREFIX")) files.push_back(std::string(prefix) + "/etc/resolv.conf");
    for (const auto& path : files) {
        std::ifstream f(path);
        for (std::string line; std::getline(f, line);) {
            auto fields = split(trim(line), ' ');
            if (fields.size() >= 2 && fields[0] == "nameserver" && (isIPv4(fields[1]) || isIPv6Literal(fields[1]))) out.push_back(fields[1]);
        }
        if (!out.empty()) break;
    }
    if (out.empty()) out = {"1.1.1.1", "8.8.8.8"};
    return out;
}

}  // namespace nt
