#pragma once

#include <QColor>
#include <QIcon>
#include <QPixmap>

// Line icons drawn with QPainter (no image files, no SVG module needed).
enum class IconKind {
    Home, Pulse, Nodes, Server, Shield, Info, Gauge, Gear,
    Play, Stop, Trash, Minimize, Maximize, Restore, Close,
    Monitor, Bolt, Globe, Dot, Chevron, Tool
};

// size is in device-independent pixels; dpr is the screen's device pixel ratio.
QPixmap iconPixmap(IconKind kind, const QColor& color, int size, qreal dpr);
QIcon makeIcon(IconKind kind, const QColor& normal, const QColor& selected, const QColor& disabled, int size, qreal dpr);
