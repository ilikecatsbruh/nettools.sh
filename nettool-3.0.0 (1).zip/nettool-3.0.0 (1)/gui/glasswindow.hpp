#pragma once

#include <QMap>
#include <QString>
#include <QWidget>

#include <functional>
#include <map>
#include <memory>
#include <string>

#include "icons.hpp"
#include "tools.hpp"

class QCheckBox;
class QComboBox;
class QEvent;
class QFrame;
class QHBoxLayout;
class QLabel;
class QLineEdit;
class QListWidget;
class QListWidgetItem;
class QPlainTextEdit;
class QPushButton;
class QSlider;
class QStackedWidget;
class QThread;
class QTimer;
class QVBoxLayout;

// Custom title bar: drag to move, double-click to maximize.
class TitleBar : public QWidget {
public:
    explicit TitleBar(QWidget* parent = nullptr);
    std::function<void()> onToggleMaximize;

protected:
    void mousePressEvent(QMouseEvent* event) override;
    void mouseDoubleClickEvent(QMouseEvent* event) override;
};

// Frameless dark-glass window: title bar, navigation, tool page, info panel.
class GlassWindow : public QWidget {
public:
    explicit GlassWindow(QWidget* parent = nullptr);
    ~GlassWindow() override;

    // Called on the GUI thread (queued from the worker thread).
    void appendOutput(nt::Level level, const QString& text);

protected:
    void paintEvent(QPaintEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;
    void closeEvent(QCloseEvent* event) override;
    void changeEvent(QEvent* event) override;

private:
    struct NavMeta {
        QString label;
        QString subtitle;
        IconKind icon;
    };

    // construction
    void buildUi();
    QWidget* buildTitleBar();
    QWidget* buildSidebar();
    QWidget* buildToolPage();
    QWidget* buildSettingsPage();
    QWidget* buildInfoPanel();
    QFrame* makeCard(const QString& title, IconKind icon, QVBoxLayout** body);
    QLabel* addInfoRow(QVBoxLayout* body, const QString& key);
    void populateNav();
    void loadSettings();
    void saveSettings();

    // behaviour
    void selectEntry(QListWidgetItem* item);
    void showTool(const nt::Tool* tool);
    void openTool(const std::string& id, const nt::Args& args, bool autorun);
    void runClicked();
    void stopClicked();
    void clearClicked();
    void launchInteractive(const nt::Args& args);
    void finished(int exitCode);
    void setRunning(bool running);
    void refreshInfo();
    void applyChrome();
    void updateInfoPanelVisibility();
    bool edgesAt(const QPointF& pos, Qt::Edges& edges) const;

    class QtSink;

    // chrome
    QWidget* chrome_ = nullptr;
    QPushButton* maxBtn_ = nullptr;
    QLabel* titleText_ = nullptr;

    // navigation and pages
    QListWidget* navList_ = nullptr;
    QStackedWidget* stack_ = nullptr;
    QWidget* toolPage_ = nullptr;
    QWidget* settingsPage_ = nullptr;

    // tool page
    QLabel* badge_ = nullptr;
    QLabel* pageTitle_ = nullptr;
    QLabel* pageSubtitle_ = nullptr;
    QHBoxLayout* fieldRow_ = nullptr;
    QPlainTextEdit* output_ = nullptr;
    QPushButton* startBtn_ = nullptr;
    QPushButton* stopBtn_ = nullptr;
    QPushButton* clearBtn_ = nullptr;
    QLabel* statusLabel_ = nullptr;

    // info panel
    QWidget* infoPanel_ = nullptr;
    QComboBox* ifaceCombo_ = nullptr;
    QLabel* ipValue_ = nullptr;
    QLabel* maskValue_ = nullptr;
    QLabel* gatewayValue_ = nullptr;
    QLabel* dnsValue_ = nullptr;
    QLabel* hostValue_ = nullptr;
    QLabel* osValue_ = nullptr;
    QLabel* kernelValue_ = nullptr;
    QLabel* uptimeValue_ = nullptr;
    QPushButton* quickScan_ = nullptr;
    QPushButton* quickTrace_ = nullptr;
    QPushButton* quickDns_ = nullptr;
    QTimer* infoTimer_ = nullptr;
    QString ifaceListKey_;
    QString gatewayText_;

    // settings page
    QSlider* opacitySlider_ = nullptr;
    QLabel* opacityValue_ = nullptr;
    QCheckBox* animateCheck_ = nullptr;
    QCheckBox* infoCheck_ = nullptr;

    // state
    QMap<QString, QLineEdit*> fields_;
    std::map<std::string, NavMeta> navMeta_;
    const nt::Tool* current_ = nullptr;
    QThread* worker_ = nullptr;
    std::unique_ptr<QtSink> sink_;
    nt::Cancel cancel_;
    QTimer* animTimer_ = nullptr;
    double phase_ = 0.0;
    int opacity_ = 93;       // percent; NETTOOL_GLASS_OPACITY overrides
    bool animate_ = true;    // NETTOOL_NO_ANIM overrides
    bool showInfo_ = true;
};
