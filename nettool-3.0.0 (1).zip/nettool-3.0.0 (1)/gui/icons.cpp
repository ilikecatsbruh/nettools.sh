#include "icons.hpp"

#include <QPainter>
#include <QPainterPath>
#include <QPen>
#include <QPointF>
#include <QRectF>

#include <cmath>

namespace {

void line(QPainter& p, double x1, double y1, double x2, double y2) { p.drawLine(QPointF(x1, y1), QPointF(x2, y2)); }
void circle(QPainter& p, double x, double y, double r) { p.drawEllipse(QPointF(x, y), r, r); }

void drawKind(QPainter& p, IconKind kind, const QColor& color) {
    switch (kind) {
        case IconKind::Home: {
            QPainterPath path;
            path.moveTo(3, 11); path.lineTo(12, 3); path.lineTo(21, 11);
            path.moveTo(5.5, 9.5); path.lineTo(5.5, 20); path.lineTo(18.5, 20); path.lineTo(18.5, 9.5);
            path.moveTo(10, 20); path.lineTo(10, 14); path.lineTo(14, 14); path.lineTo(14, 20);
            p.drawPath(path);
            break;
        }
        case IconKind::Pulse: {
            QPainterPath path;
            path.moveTo(2, 12); path.lineTo(7, 12); path.lineTo(10, 4.5); path.lineTo(14, 19.5);
            path.lineTo(17, 12); path.lineTo(22, 12);
            p.drawPath(path);
            break;
        }
        case IconKind::Nodes:
            circle(p, 12, 12, 2.6);
            circle(p, 5, 5, 2); circle(p, 19, 5, 2); circle(p, 5, 19, 2); circle(p, 19, 19, 2);
            line(p, 6.5, 6.5, 10.1, 10.1); line(p, 17.5, 6.5, 13.9, 10.1);
            line(p, 6.5, 17.5, 10.1, 13.9); line(p, 17.5, 17.5, 13.9, 13.9);
            break;
        case IconKind::Server:
            p.drawRoundedRect(QRectF(3, 4, 18, 6.5), 2, 2);
            p.drawRoundedRect(QRectF(3, 13.5, 18, 6.5), 2, 2);
            p.setBrush(color);
            circle(p, 7, 7.25, 0.9);
            circle(p, 7, 16.75, 0.9);
            break;
        case IconKind::Shield: {
            QPainterPath path;
            path.moveTo(12, 3); path.lineTo(20, 6); path.lineTo(20, 12);
            path.cubicTo(20, 16.5, 16.5, 19.8, 12, 21);
            path.cubicTo(7.5, 19.8, 4, 16.5, 4, 12);
            path.lineTo(4, 6); path.closeSubpath();
            p.drawPath(path);
            QPainterPath tick;
            tick.moveTo(8.8, 12); tick.lineTo(11, 14.3); tick.lineTo(15.4, 9.6);
            p.drawPath(tick);
            break;
        }
        case IconKind::Info:
            circle(p, 12, 12, 9);
            line(p, 12, 11, 12, 16.5);
            p.setBrush(color);
            circle(p, 12, 7.8, 1);
            break;
        case IconKind::Gauge: {
            QPainterPath arc;
            const QRectF rect(3, 4, 18, 18);
            arc.arcMoveTo(rect, 200);
            arc.arcTo(rect, 200, -220);
            p.drawPath(arc);
            line(p, 12, 13, 16.5, 8.5);
            p.setBrush(color);
            circle(p, 12, 13, 1.3);
            break;
        }
        case IconKind::Gear: {
            circle(p, 12, 12, 6.2);
            circle(p, 12, 12, 2.4);
            for (int i = 0; i < 8; ++i) {
                const double a = i * M_PI / 4.0;
                line(p, 12 + 6.2 * std::cos(a), 12 + 6.2 * std::sin(a), 12 + 9.4 * std::cos(a), 12 + 9.4 * std::sin(a));
            }
            break;
        }
        case IconKind::Play: {
            QPainterPath path;
            path.moveTo(7.5, 4.5); path.lineTo(19, 12); path.lineTo(7.5, 19.5); path.closeSubpath();
            p.setBrush(color);
            p.drawPath(path);
            break;
        }
        case IconKind::Stop:
            p.setBrush(color);
            p.drawRoundedRect(QRectF(6, 6, 12, 12), 2, 2);
            break;
        case IconKind::Trash: {
            line(p, 4, 7, 20, 7);
            QPainterPath path;
            path.moveTo(9, 7); path.lineTo(9, 4.5); path.lineTo(15, 4.5); path.lineTo(15, 7);
            path.moveTo(6, 7); path.lineTo(7, 20); path.lineTo(17, 20); path.lineTo(18, 7);
            p.drawPath(path);
            line(p, 10, 11, 10, 16);
            line(p, 14, 11, 14, 16);
            break;
        }
        case IconKind::Minimize:
            line(p, 5, 12, 19, 12);
            break;
        case IconKind::Maximize:
            p.drawRoundedRect(QRectF(5.5, 5.5, 13, 13), 1.8, 1.8);
            break;
        case IconKind::Restore: {
            p.drawRoundedRect(QRectF(4.5, 8.5, 11, 11), 1.8, 1.8);
            QPainterPath path;
            path.moveTo(8.5, 8.5); path.lineTo(8.5, 4.5); path.lineTo(19.5, 4.5); path.lineTo(19.5, 15.5); path.lineTo(15.5, 15.5);
            p.drawPath(path);
            break;
        }
        case IconKind::Close:
            line(p, 6, 6, 18, 18);
            line(p, 18, 6, 6, 18);
            break;
        case IconKind::Monitor:
            p.drawRoundedRect(QRectF(3, 4.5, 18, 12), 2, 2);
            line(p, 12, 16.5, 12, 20);
            line(p, 8, 20, 16, 20);
            break;
        case IconKind::Bolt: {
            QPainterPath path;
            path.moveTo(13, 2.5); path.lineTo(5, 13.5); path.lineTo(11.5, 13.5); path.lineTo(10.5, 21.5);
            path.lineTo(19, 10); path.lineTo(12.5, 10); path.closeSubpath();
            p.drawPath(path);
            break;
        }
        case IconKind::Globe:
            circle(p, 12, 12, 9);
            p.drawEllipse(QPointF(12, 12), 4.2, 9);
            line(p, 3, 12, 21, 12);
            break;
        case IconKind::Dot:
            p.setBrush(color);
            circle(p, 12, 12, 2.4);
            break;
        case IconKind::Chevron: {
            QPainterPath path;
            path.moveTo(7, 10); path.lineTo(12, 15); path.lineTo(17, 10);
            p.drawPath(path);
            break;
        }
        case IconKind::Tool: {   // generic "sliders" glyph for the less common tools
            line(p, 4, 7, 20, 7); line(p, 4, 17, 20, 17);
            p.setBrush(color);
            circle(p, 9, 7, 2.2);
            circle(p, 15, 17, 2.2);
            break;
        }
    }
}

}  // namespace

QPixmap iconPixmap(IconKind kind, const QColor& color, int size, qreal dpr) {
    QPixmap pm(static_cast<int>(size * dpr), static_cast<int>(size * dpr));
    pm.fill(Qt::transparent);
    pm.setDevicePixelRatio(dpr);
    QPainter p(&pm);
    p.setRenderHint(QPainter::Antialiasing);
    p.scale(size / 24.0, size / 24.0);
    QPen pen(color, 1.8);
    pen.setCapStyle(Qt::RoundCap);
    pen.setJoinStyle(Qt::RoundJoin);
    p.setPen(pen);
    p.setBrush(Qt::NoBrush);
    drawKind(p, kind, color);
    return pm;
}

QIcon makeIcon(IconKind kind, const QColor& normal, const QColor& selected, const QColor& disabled, int size, qreal dpr) {
    QIcon icon;
    icon.addPixmap(iconPixmap(kind, normal, size, dpr), QIcon::Normal);
    icon.addPixmap(iconPixmap(kind, selected, size, dpr), QIcon::Selected);
    icon.addPixmap(iconPixmap(kind, disabled, size, dpr), QIcon::Disabled);
    return icon;
}
