#include "glasswindow.hpp"

#include <QCheckBox>
#include <QCloseEvent>
#include <QComboBox>
#include <QEvent>
#include <QFont>
#include <QFrame>
#include <QHBoxLayout>
#include <QIntValidator>
#include <QLabel>
#include <QLayoutItem>
#include <QLineEdit>
#include <QLinearGradient>
#include <QListWidget>
#include <QMouseEvent>
#include <QPainter>
#include <QPainterPath>
#include <QPlainTextEdit>
#include <QProcess>
#include <QPushButton>
#include <QRadialGradient>
#include <QScrollBar>
#include <QSettings>
#include <QSlider>
#include <QStackedWidget>
#include <QStringList>
#include <QTextCharFormat>
#include <QTextCursor>
#include <QThread>
#include <QTimer>
#include <QVBoxLayout>
#include <QWindow>
#include <QtGlobal>

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <string>
#include <vector>

namespace {

constexpr int kMargin = 10;   // transparent border used for the shadow and for edge-resizing

const QColor kIconNormal(206, 202, 255);
const QColor kIconSelected(255, 255, 255);
const QColor kIconDisabled(150, 148, 190, 130);
const QColor kAccentIcon(176, 166, 255);

QString fromStd(const std::string& s) { return QString::fromStdString(s); }

// A combo box with a chevron drawn on top (the QSS drop-down has no arrow image).
class ChevronCombo : public QComboBox {
public:
    explicit ChevronCombo(QWidget* parent = nullptr) : QComboBox(parent) {}

protected:
    void paintEvent(QPaintEvent* event) override {
        QComboBox::paintEvent(event);
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing);
        QPen pen(QColor(220, 218, 255), 1.8);
        pen.setCapStyle(Qt::RoundCap);
        pen.setJoinStyle(Qt::RoundJoin);
        p.setPen(pen);
        const double cx = width() - 22.0, cy = height() / 2.0;
        p.drawLine(QPointF(cx - 4, cy - 2), QPointF(cx, cy + 2));
        p.drawLine(QPointF(cx, cy + 2), QPointF(cx + 4, cy - 2));
    }
};

}  // namespace

// --------------------------------------------------------------- TitleBar ----
TitleBar::TitleBar(QWidget* parent) : QWidget(parent) { setFixedHeight(54); }

void TitleBar::mousePressEvent(QMouseEvent* event) {
    if (event->button() == Qt::LeftButton) {
        if (QWindow* handle = window()->windowHandle()) handle->startSystemMove();
        event->accept();
        return;
    }
    QWidget::mousePressEvent(event);
}

void TitleBar::mouseDoubleClickEvent(QMouseEvent* event) {
    if (event->button() == Qt::LeftButton && onToggleMaximize) {
        onToggleMaximize();
        event->accept();
        return;
    }
    QWidget::mouseDoubleClickEvent(event);
}

// ---------------------------------------------------------------- QtSink ----
// Receives engine output on the worker thread and forwards it to the GUI thread.
class GlassWindow::QtSink : public nt::Sink {
public:
    explicit QtSink(GlassWindow* window) : window_(window) {}
    void write(nt::Level level, const std::string& text) override {
        const QString qtext = QString::fromUtf8(text.c_str(), static_cast<int>(text.size()));
        GlassWindow* w = window_;
        QMetaObject::invokeMethod(w, [w, level, qtext]() { w->appendOutput(level, qtext); }, Qt::QueuedConnection);
    }

private:
    GlassWindow* window_;
};

// ------------------------------------------------------------ GlassWindow ----
GlassWindow::GlassWindow(QWidget* parent) : QWidget(parent, Qt::Window | Qt::FramelessWindowHint) {
    setAttribute(Qt::WA_TranslucentBackground);
    setMouseTracking(true);
    setWindowTitle(QStringLiteral("Nettool"));
    resize(1280, 780);
    setMinimumSize(900, 600);

    loadSettings();
    buildUi();
    populateNav();

    animTimer_ = new QTimer(this);
    connect(animTimer_, &QTimer::timeout, this, [this]() {
        if (animate_ && isVisible()) {
            phase_ += 0.01;
            update();
        }
    });
    animTimer_->start(50);

    infoTimer_ = new QTimer(this);
    connect(infoTimer_, &QTimer::timeout, this, [this]() { refreshInfo(); });
    infoTimer_->start(5000);
    refreshInfo();
    updateInfoPanelVisibility();
}

GlassWindow::~GlassWindow() {
    if (worker_) {
        cancel_.cancel();
        worker_->wait();
        delete worker_;
        worker_ = nullptr;
    }
}

void GlassWindow::loadSettings() {
    QSettings settings(QStringLiteral("nettool"), QStringLiteral("nettool"));
    opacity_ = std::clamp(settings.value(QStringLiteral("opacity"), 93).toInt(), 40, 100);
    animate_ = settings.value(QStringLiteral("animate"), true).toBool();
    showInfo_ = settings.value(QStringLiteral("infoPanel"), true).toBool();
    if (const char* v = std::getenv("NETTOOL_GLASS_OPACITY")) {
        bool ok = false;
        const int n = QString::fromLatin1(v).toInt(&ok);
        if (ok) opacity_ = std::clamp(n, 25, 100);
    }
    if (std::getenv("NETTOOL_NO_ANIM")) animate_ = false;
}

void GlassWindow::saveSettings() {
    QSettings settings(QStringLiteral("nettool"), QStringLiteral("nettool"));
    settings.setValue(QStringLiteral("opacity"), opacity_);
    settings.setValue(QStringLiteral("animate"), animate_);
    settings.setValue(QStringLiteral("infoPanel"), showInfo_);
}

// ------------------------------------------------------------ construction ----
void GlassWindow::buildUi() {
    setStyleSheet(QStringLiteral(R"QSS(
        QWidget { color: #e9e8ff; font-family: "Inter", "Noto Sans", "Cantarell", "DejaVu Sans", sans-serif; font-size: 14px; }
        QToolTip { background: #1b1850; color: #eceaff; border: 1px solid rgba(255,255,255,40); padding: 4px 6px; }
        QFrame#rule { background: rgba(255,255,255,18); border: none; }

        QLabel#titleText { font-size: 15px; font-weight: 600; }
        QLabel#appBadge { background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #8b6cff, stop:1 #4b3fd8); border-radius: 9px; }
        QPushButton#winBtn, QPushButton#winClose { background: transparent; border: none; border-radius: 8px; }
        QPushButton#winBtn:hover { background: rgba(255,255,255,26); }
        QPushButton#winClose:hover { background: rgba(232,68,92,215); }

        QFrame#sidebar { background: rgba(255,255,255,6); border: none; border-right: 1px solid rgba(255,255,255,18); }
        QFrame#infoPanel { background: rgba(255,255,255,6); border: none; border-left: 1px solid rgba(255,255,255,18); }
        QLabel#footName { font-weight: 600; font-size: 15px; }
        QLabel#footTag { color: rgba(214,212,255,140); font-size: 12px; }

        QListWidget#nav { background: transparent; border: none; outline: none; }
        QListWidget#nav::item { padding: 0px 12px; margin: 2px 14px; border-radius: 11px; color: rgba(226,224,255,215); }
        QListWidget#nav::item:hover { background: rgba(255,255,255,15); }
        QListWidget#nav::item:selected { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 rgba(98,78,224,235), stop:1 rgba(80,64,196,235)); color: white; }
        QListWidget#nav::item:disabled { background: transparent; color: rgba(214,212,255,110); }

        QLabel#pageBadge { background: rgba(124,108,255,60); border: 1px solid rgba(160,148,255,70); border-radius: 14px; }
        QLabel#pageTitle { font-size: 26px; font-weight: 700; }
        QLabel#pageSubtitle { color: rgba(214,212,255,165); }
        QLabel#fieldLabel { color: rgba(214,212,255,190); font-size: 13px; }
        QLabel#status { color: rgba(214,212,255,150); }

        QFrame#card { background: rgba(255,255,255,12); border: 1px solid rgba(255,255,255,24); border-radius: 14px; }
        QLabel#cardBadge { background: rgba(124,108,255,56); border-radius: 10px; }
        QLabel#cardTitle { font-size: 15px; font-weight: 600; }
        QLabel#infoKey { color: rgba(214,212,255,160); }
        QLabel#infoValue { color: #eceaff; }

        QLineEdit { background: rgba(255,255,255,13); border: 1px solid rgba(255,255,255,34); border-radius: 10px;
                    padding: 10px 12px; selection-background-color: rgba(124,108,255,170); }
        QLineEdit:focus { border: 1px solid rgba(139,124,255,235); background: rgba(255,255,255,20); }

        QPushButton#start { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #5a6dff, stop:1 #4658ee);
                            border: 1px solid rgba(255,255,255,46); border-radius: 10px; padding: 11px 22px;
                            font-weight: 600; color: white; }
        QPushButton#start:hover { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #6c7dff, stop:1 #5568f6); }
        QPushButton#start:disabled { background: rgba(255,255,255,14); color: rgba(255,255,255,100); border: 1px solid rgba(255,255,255,24); }
        QPushButton#ghost { background: rgba(255,255,255,12); border: 1px solid rgba(255,255,255,32); border-radius: 10px;
                            padding: 11px 22px; color: rgba(226,224,255,220); }
        QPushButton#ghost:hover { background: rgba(255,255,255,24); }
        QPushButton#ghost:disabled { color: rgba(226,224,255,90); background: rgba(255,255,255,7); border: 1px solid rgba(255,255,255,18); }
        QPushButton#quick { text-align: left; background: rgba(255,255,255,12); border: 1px solid rgba(255,255,255,30);
                            border-radius: 11px; padding: 12px 14px; color: rgba(236,234,255,235); }
        QPushButton#quick:hover { background: rgba(255,255,255,24); border: 1px solid rgba(160,148,255,120); }
        QPushButton#quick:disabled { color: rgba(226,224,255,90); }

        QComboBox { background: rgba(255,255,255,13); border: 1px solid rgba(255,255,255,34); border-radius: 10px; padding: 10px 12px; }
        QComboBox::drop-down { border: none; width: 34px; }
        QComboBox QAbstractItemView { background: #1b1850; border: 1px solid rgba(255,255,255,40); color: #eceaff;
                                      selection-background-color: rgba(98,78,224,235); outline: none; padding: 4px; }

        QPlainTextEdit { background: rgba(6,5,22,170); border: 1px solid rgba(255,255,255,20); border-radius: 12px; padding: 14px;
                         font-family: "JetBrains Mono", "Fira Code", "DejaVu Sans Mono", monospace; font-size: 13px;
                         selection-background-color: rgba(124,108,255,170); }
        QScrollBar:vertical { background: transparent; width: 10px; margin: 6px 2px; }
        QScrollBar::handle:vertical { background: rgba(255,255,255,60); border-radius: 4px; min-height: 30px; }
        QScrollBar::handle:vertical:hover { background: rgba(255,255,255,90); }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }

        QSlider::groove:horizontal { height: 6px; border-radius: 3px; background: rgba(255,255,255,40); }
        QSlider::sub-page:horizontal { background: #6d5dfc; border-radius: 3px; }
        QSlider::handle:horizontal { background: white; width: 16px; height: 16px; margin: -5px 0; border-radius: 8px; }
        QCheckBox { spacing: 10px; }
        QCheckBox::indicator { width: 18px; height: 18px; border-radius: 5px; border: 1px solid rgba(255,255,255,90); background: rgba(255,255,255,14); }
        QCheckBox::indicator:checked { background: #6d5dfc; border: 1px solid #a89cff; }
    )QSS"));

    auto* outer = new QVBoxLayout(this);
    outer->setContentsMargins(kMargin, kMargin, kMargin, kMargin);
    outer->setSpacing(0);

    chrome_ = new QWidget;
    chrome_->setCursor(Qt::ArrowCursor);   // keeps resize cursors confined to the outer margin
    outer->addWidget(chrome_);

    auto* col = new QVBoxLayout(chrome_);
    col->setContentsMargins(0, 0, 0, 0);
    col->setSpacing(0);
    col->addWidget(buildTitleBar());
    auto* rule = new QFrame;
    rule->setObjectName(QStringLiteral("rule"));
    rule->setFixedHeight(1);
    col->addWidget(rule);

    auto* body = new QHBoxLayout;
    body->setContentsMargins(0, 0, 0, 0);
    body->setSpacing(0);
    body->addWidget(buildSidebar());
    stack_ = new QStackedWidget;
    toolPage_ = buildToolPage();
    settingsPage_ = buildSettingsPage();
    stack_->addWidget(toolPage_);
    stack_->addWidget(settingsPage_);
    body->addWidget(stack_, 1);
    body->addWidget(buildInfoPanel());
    col->addLayout(body, 1);
}

QWidget* GlassWindow::buildTitleBar() {
    auto* bar = new TitleBar;
    bar->onToggleMaximize = [this]() {
        if (isMaximized()) showNormal(); else showMaximized();
    };
    auto* row = new QHBoxLayout(bar);
    row->setContentsMargins(16, 0, 10, 0);
    row->setSpacing(12);
    const qreal dpr = devicePixelRatioF();

    auto* appBadge = new QLabel;
    appBadge->setObjectName(QStringLiteral("appBadge"));
    appBadge->setFixedSize(30, 30);
    appBadge->setAlignment(Qt::AlignCenter);
    appBadge->setPixmap(iconPixmap(IconKind::Globe, QColor(255, 255, 255), 18, dpr));
    titleText_ = new QLabel(QStringLiteral("Nettool ") + QString::fromLatin1(nt::kVersion));
    titleText_->setObjectName(QStringLiteral("titleText"));
    row->addWidget(appBadge);
    row->addWidget(titleText_);
    row->addStretch();

    auto makeWinButton = [&](IconKind kind, const QString& objectName) -> QPushButton* {
        auto* b = new QPushButton;
        b->setObjectName(objectName);
        b->setIcon(makeIcon(kind, kIconNormal, kIconSelected, kIconDisabled, 16, dpr));
        b->setIconSize(QSize(16, 16));
        b->setFixedSize(40, 32);
        b->setFocusPolicy(Qt::NoFocus);
        return b;
    };
    auto* minBtn = makeWinButton(IconKind::Minimize, QStringLiteral("winBtn"));
    maxBtn_ = makeWinButton(IconKind::Maximize, QStringLiteral("winBtn"));
    auto* closeBtn = makeWinButton(IconKind::Close, QStringLiteral("winClose"));
    connect(minBtn, &QPushButton::clicked, this, [this]() { showMinimized(); });
    connect(maxBtn_, &QPushButton::clicked, this, [this]() {
        if (isMaximized()) showNormal(); else showMaximized();
    });
    connect(closeBtn, &QPushButton::clicked, this, [this]() { close(); });
    row->addWidget(minBtn);
    row->addWidget(maxBtn_);
    row->addWidget(closeBtn);
    return bar;
}

QWidget* GlassWindow::buildSidebar() {
    auto* side = new QFrame;
    side->setObjectName(QStringLiteral("sidebar"));
    side->setFixedWidth(236);
    auto* col = new QVBoxLayout(side);
    col->setContentsMargins(0, 14, 0, 14);
    col->setSpacing(0);

    navList_ = new QListWidget;
    navList_->setObjectName(QStringLiteral("nav"));
    navList_->setFrameShape(QFrame::NoFrame);
    navList_->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    navList_->setIconSize(QSize(20, 20));
    col->addWidget(navList_, 1);

    auto* footer = new QWidget;
    auto* fl = new QHBoxLayout(footer);
    fl->setContentsMargins(20, 12, 16, 4);
    fl->setSpacing(12);
    auto* mark = new QLabel;
    mark->setObjectName(QStringLiteral("appBadge"));
    mark->setFixedSize(34, 34);
    mark->setAlignment(Qt::AlignCenter);
    mark->setPixmap(iconPixmap(IconKind::Globe, QColor(255, 255, 255), 20, devicePixelRatioF()));
    auto* names = new QVBoxLayout;
    names->setSpacing(0);
    auto* name = new QLabel(QStringLiteral("Nettool"));
    name->setObjectName(QStringLiteral("footName"));
    auto* tag = new QLabel(QStringLiteral("Powerful. Fast. Simple."));
    tag->setObjectName(QStringLiteral("footTag"));
    names->addWidget(name);
    names->addWidget(tag);
    fl->addWidget(mark);
    fl->addLayout(names, 1);
    col->addWidget(footer);

    connect(navList_, &QListWidget::currentItemChanged, this,
            [this](QListWidgetItem* current, QListWidgetItem*) { selectEntry(current); });
    return side;
}

QFrame* GlassWindow::makeCard(const QString& title, IconKind icon, QVBoxLayout** body) {
    auto* card = new QFrame;
    card->setObjectName(QStringLiteral("card"));
    auto* col = new QVBoxLayout(card);
    col->setContentsMargins(16, 14, 16, 16);
    col->setSpacing(10);
    auto* head = new QHBoxLayout;
    head->setSpacing(10);
    auto* badge = new QLabel;
    badge->setObjectName(QStringLiteral("cardBadge"));
    badge->setFixedSize(34, 34);
    badge->setAlignment(Qt::AlignCenter);
    badge->setPixmap(iconPixmap(icon, kAccentIcon, 18, devicePixelRatioF()));
    auto* label = new QLabel(title);
    label->setObjectName(QStringLiteral("cardTitle"));
    head->addWidget(badge);
    head->addWidget(label, 1);
    col->addLayout(head);
    *body = col;
    return card;
}

QLabel* GlassWindow::addInfoRow(QVBoxLayout* body, const QString& key) {
    auto* row = new QHBoxLayout;
    row->setSpacing(10);
    auto* k = new QLabel(key);
    k->setObjectName(QStringLiteral("infoKey"));
    auto* v = new QLabel(QStringLiteral("-"));
    v->setObjectName(QStringLiteral("infoValue"));
    v->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    v->setWordWrap(true);
    v->setTextInteractionFlags(Qt::TextSelectableByMouse);
    row->addWidget(k);
    row->addWidget(v, 1);
    body->addLayout(row);
    return v;
}

QWidget* GlassWindow::buildToolPage() {
    const qreal dpr = devicePixelRatioF();
    auto* page = new QWidget;
    auto* col = new QVBoxLayout(page);
    col->setContentsMargins(24, 22, 24, 22);
    col->setSpacing(16);

    auto* head = new QHBoxLayout;
    head->setSpacing(14);
    badge_ = new QLabel;
    badge_->setObjectName(QStringLiteral("pageBadge"));
    badge_->setFixedSize(52, 52);
    badge_->setAlignment(Qt::AlignCenter);
    auto* titles = new QVBoxLayout;
    titles->setSpacing(2);
    pageTitle_ = new QLabel;
    pageTitle_->setObjectName(QStringLiteral("pageTitle"));
    pageSubtitle_ = new QLabel;
    pageSubtitle_->setObjectName(QStringLiteral("pageSubtitle"));
    pageSubtitle_->setWordWrap(true);
    titles->addWidget(pageTitle_);
    titles->addWidget(pageSubtitle_);
    head->addWidget(badge_);
    head->addLayout(titles, 1);
    col->addLayout(head);

    auto* rule = new QFrame;
    rule->setObjectName(QStringLiteral("rule"));
    rule->setFixedHeight(1);
    col->addWidget(rule);

    // Form card: parameter fields, then Start / Stop / Clear.
    auto* formCard = new QFrame;
    formCard->setObjectName(QStringLiteral("card"));
    auto* formBody = new QVBoxLayout(formCard);
    formBody->setContentsMargins(18, 16, 18, 18);
    formBody->setSpacing(14);
    fieldRow_ = new QHBoxLayout;
    fieldRow_->setSpacing(14);
    formBody->addLayout(fieldRow_);

    auto* buttons = new QHBoxLayout;
    buttons->setSpacing(12);
    startBtn_ = new QPushButton(QStringLiteral("Start"));
    startBtn_->setObjectName(QStringLiteral("start"));
    startBtn_->setIcon(makeIcon(IconKind::Play, QColor(255, 255, 255), QColor(255, 255, 255), kIconDisabled, 16, dpr));
    startBtn_->setIconSize(QSize(16, 16));
    startBtn_->setMinimumWidth(150);
    stopBtn_ = new QPushButton(QStringLiteral("Stop"));
    stopBtn_->setObjectName(QStringLiteral("ghost"));
    stopBtn_->setIcon(makeIcon(IconKind::Stop, kIconNormal, kIconSelected, kIconDisabled, 16, dpr));
    stopBtn_->setIconSize(QSize(16, 16));
    stopBtn_->setMinimumWidth(150);
    stopBtn_->setEnabled(false);
    clearBtn_ = new QPushButton(QStringLiteral("Clear"));
    clearBtn_->setObjectName(QStringLiteral("ghost"));
    clearBtn_->setIcon(makeIcon(IconKind::Trash, kIconNormal, kIconSelected, kIconDisabled, 16, dpr));
    clearBtn_->setIconSize(QSize(16, 16));
    clearBtn_->setMinimumWidth(150);
    statusLabel_ = new QLabel;
    statusLabel_->setObjectName(QStringLiteral("status"));
    buttons->addWidget(startBtn_);
    buttons->addWidget(stopBtn_);
    buttons->addWidget(clearBtn_);
    buttons->addSpacing(8);
    buttons->addWidget(statusLabel_, 1);
    formBody->addLayout(buttons);
    col->addWidget(formCard);

    // Terminal.
    auto* outCard = new QFrame;
    outCard->setObjectName(QStringLiteral("card"));
    auto* outLayout = new QVBoxLayout(outCard);
    outLayout->setContentsMargins(12, 12, 12, 12);
    output_ = new QPlainTextEdit;
    output_->setReadOnly(true);
    output_->setMaximumBlockCount(5000);
    output_->setFrameShape(QFrame::NoFrame);
    outLayout->addWidget(output_);
    col->addWidget(outCard, 1);

    connect(startBtn_, &QPushButton::clicked, this, [this]() { runClicked(); });
    connect(stopBtn_, &QPushButton::clicked, this, [this]() { stopClicked(); });
    connect(clearBtn_, &QPushButton::clicked, this, [this]() { clearClicked(); });
    return page;
}

QWidget* GlassWindow::buildSettingsPage() {
    const qreal dpr = devicePixelRatioF();
    auto* page = new QWidget;
    auto* col = new QVBoxLayout(page);
    col->setContentsMargins(24, 22, 24, 22);
    col->setSpacing(16);

    auto* head = new QHBoxLayout;
    head->setSpacing(14);
    auto* badge = new QLabel;
    badge->setObjectName(QStringLiteral("pageBadge"));
    badge->setFixedSize(52, 52);
    badge->setAlignment(Qt::AlignCenter);
    badge->setPixmap(iconPixmap(IconKind::Gear, kAccentIcon, 26, dpr));
    auto* titles = new QVBoxLayout;
    titles->setSpacing(2);
    auto* title = new QLabel(QStringLiteral("Settings"));
    title->setObjectName(QStringLiteral("pageTitle"));
    auto* subtitle = new QLabel(QStringLiteral("Appearance and window behaviour."));
    subtitle->setObjectName(QStringLiteral("pageSubtitle"));
    titles->addWidget(title);
    titles->addWidget(subtitle);
    head->addWidget(badge);
    head->addLayout(titles, 1);
    col->addLayout(head);
    auto* rule = new QFrame;
    rule->setObjectName(QStringLiteral("rule"));
    rule->setFixedHeight(1);
    col->addWidget(rule);

    QVBoxLayout* body = nullptr;
    col->addWidget(makeCard(QStringLiteral("Appearance"), IconKind::Monitor, &body));
    auto* opacityRow = new QHBoxLayout;
    opacityRow->setSpacing(12);
    auto* opacityLabel = new QLabel(QStringLiteral("Window opacity"));
    opacityLabel->setMinimumWidth(150);
    opacitySlider_ = new QSlider(Qt::Horizontal);
    opacitySlider_->setRange(40, 100);
    opacitySlider_->setValue(opacity_);
    opacityValue_ = new QLabel(QString::number(opacity_) + QStringLiteral("%"));
    opacityValue_->setMinimumWidth(48);
    opacityValue_->setAlignment(Qt::AlignRight | Qt::AlignVCenter);
    opacityRow->addWidget(opacityLabel);
    opacityRow->addWidget(opacitySlider_, 1);
    opacityRow->addWidget(opacityValue_);
    body->addLayout(opacityRow);
    animateCheck_ = new QCheckBox(QStringLiteral("Animated background glow"));
    animateCheck_->setChecked(animate_);
    infoCheck_ = new QCheckBox(QStringLiteral("Show the information panel (wide windows only)"));
    infoCheck_->setChecked(showInfo_);
    body->addWidget(animateCheck_);
    body->addWidget(infoCheck_);

    connect(opacitySlider_, &QSlider::valueChanged, this, [this](int value) {
        opacity_ = value;
        opacityValue_->setText(QString::number(value) + QStringLiteral("%"));
        saveSettings();
        update();
    });
    connect(animateCheck_, &QCheckBox::toggled, this, [this](bool on) { animate_ = on; saveSettings(); update(); });
    connect(infoCheck_, &QCheckBox::toggled, this, [this](bool on) {
        showInfo_ = on;
        saveSettings();
        updateInfoPanelVisibility();
    });

    QVBoxLayout* about = nullptr;
    col->addWidget(makeCard(QStringLiteral("About"), IconKind::Info, &about));
    auto* line1 = new QLabel(QStringLiteral("Nettool ") + QString::fromLatin1(nt::kVersion) + QStringLiteral(" - ") +
                             QString::number(static_cast<int>(nt::tools().size())) + QStringLiteral(" tools, Qt ") +
                             QString::fromLatin1(qVersion()));
    auto* line2 = new QLabel(QStringLiteral("Blur behind the window comes from your compositor (for example the KDE Blur effect). "
                                            "Raise the opacity if you do not use one."));
    line2->setObjectName(QStringLiteral("pageSubtitle"));
    line2->setWordWrap(true);
    about->addWidget(line1);
    about->addWidget(line2);
    col->addStretch();
    return page;
}

QWidget* GlassWindow::buildInfoPanel() {
    const qreal dpr = devicePixelRatioF();
    auto* panel = new QFrame;
    panel->setObjectName(QStringLiteral("infoPanel"));
    panel->setFixedWidth(312);
    infoPanel_ = panel;
    auto* col = new QVBoxLayout(panel);
    col->setContentsMargins(16, 16, 16, 16);
    col->setSpacing(14);

    QVBoxLayout* body = nullptr;
    col->addWidget(makeCard(QStringLiteral("Network Interface"), IconKind::Nodes, &body));
    ifaceCombo_ = new ChevronCombo;
    body->addWidget(ifaceCombo_);
    ipValue_ = addInfoRow(body, QStringLiteral("IP Address"));
    maskValue_ = addInfoRow(body, QStringLiteral("Subnet Mask"));
    gatewayValue_ = addInfoRow(body, QStringLiteral("Gateway"));
    dnsValue_ = addInfoRow(body, QStringLiteral("DNS Servers"));

    col->addWidget(makeCard(QStringLiteral("System Info"), IconKind::Monitor, &body));
    hostValue_ = addInfoRow(body, QStringLiteral("Hostname"));
    osValue_ = addInfoRow(body, QStringLiteral("OS"));
    kernelValue_ = addInfoRow(body, QStringLiteral("Kernel"));
    uptimeValue_ = addInfoRow(body, QStringLiteral("Uptime"));

    col->addWidget(makeCard(QStringLiteral("Quick Actions"), IconKind::Bolt, &body));
    auto makeQuick = [&](const QString& text, IconKind kind) -> QPushButton* {
        auto* b = new QPushButton(text);
        b->setObjectName(QStringLiteral("quick"));
        b->setIcon(makeIcon(kind, kIconNormal, kIconSelected, kIconDisabled, 18, dpr));
        b->setIconSize(QSize(18, 18));
        body->addWidget(b);
        return b;
    };
    quickTrace_ = makeQuick(QStringLiteral("Traceroute 8.8.8.8"), IconKind::Nodes);
    quickDns_ = makeQuick(QStringLiteral("DNS Lookup example.com"), IconKind::Server);
    quickScan_ = makeQuick(QStringLiteral("Port Scan"), IconKind::Shield);
    col->addStretch();

    connect(ifaceCombo_, &QComboBox::currentIndexChanged, this, [this](int) { refreshInfo(); });
    connect(quickTrace_, &QPushButton::clicked, this, [this]() { openTool("traceroute", {{"host", "8.8.8.8"}}, true); });
    connect(quickDns_, &QPushButton::clicked, this, [this]() { openTool("records", {{"domain", "example.com"}}, true); });
    connect(quickScan_, &QPushButton::clicked, this, [this]() {
        // Scans your own gateway (router), not a third party.
        if (gatewayText_.isEmpty()) openTool("ports", {}, false);
        else openTool("ports", {{"host", gatewayText_.toStdString()}}, true);
    });
    return panel;
}

void GlassWindow::populateNav() {
    const qreal dpr = devicePixelRatioF();
    struct Primary { const char* id; const char* label; IconKind icon; const char* subtitle; };
    static const Primary primary[] = {
        {"summary", "Home", IconKind::Home, "Overview of your connection."},
        {"netping", "Ping", IconKind::Pulse, "Test network connectivity and measure latency."},
        {"traceroute", "Traceroute", IconKind::Nodes, "Trace the path your packets take to a host."},
        {"records", "DNS Lookup", IconKind::Server, "Look up A, AAAA, CNAME, MX, NS and TXT records."},
        {"ports", "Port Scan", IconKind::Shield, "Scan TCP ports on a host you are allowed to test."},
        {"iface", "Network Info", IconKind::Info, "Local network interfaces and their addresses."},
        {"speed", "Bandwidth Test", IconKind::Gauge, "Measure download speed. This uses your data plan."},
    };

    auto makeItem = [&](const QString& label, const QString& key, IconKind kind) {
        auto* item = new QListWidgetItem(makeIcon(kind, kIconNormal, kIconSelected, kIconDisabled, 20, dpr), label, navList_);
        item->setData(Qt::UserRole, key);
        item->setSizeHint(QSize(10, 44));
        return item;
    };

    std::vector<std::string> used;
    QListWidgetItem* first = nullptr;
    for (const auto& p : primary) {
        if (!nt::findTool(p.id)) continue;
        navMeta_[p.id] = NavMeta{QString::fromLatin1(p.label), QString::fromLatin1(p.subtitle), p.icon};
        used.push_back(p.id);
        QListWidgetItem* item = makeItem(QString::fromLatin1(p.label), QStringLiteral("tool:") + QString::fromLatin1(p.id), p.icon);
        if (!first) first = item;
    }

    auto* gap = new QListWidgetItem(navList_);   // breathing room before Settings
    gap->setFlags(Qt::NoItemFlags);
    gap->setSizeHint(QSize(10, 12));
    makeItem(QStringLiteral("Settings"), QStringLiteral("settings"), IconKind::Gear);

    auto* header = new QListWidgetItem(QStringLiteral("MORE TOOLS"), navList_);
    header->setFlags(Qt::NoItemFlags);
    QFont f;
    f.setBold(true);
    f.setPixelSize(10);
    f.setLetterSpacing(QFont::AbsoluteSpacing, 1.4);
    header->setFont(f);
    header->setSizeHint(QSize(10, 40));
    for (const auto& t : nt::tools()) {
        if (std::find(used.begin(), used.end(), t.id) != used.end()) continue;
        makeItem(fromStd(t.title), QStringLiteral("tool:") + fromStd(t.id), IconKind::Dot);
    }
    if (first) navList_->setCurrentItem(first);
}

// -------------------------------------------------------------- behaviour ----
void GlassWindow::selectEntry(QListWidgetItem* item) {
    if (!item) return;
    const QString key = item->data(Qt::UserRole).toString();
    if (key == QStringLiteral("settings")) {
        stack_->setCurrentWidget(settingsPage_);
        return;
    }
    if (!key.startsWith(QStringLiteral("tool:"))) return;
    const nt::Tool* tool = nt::findTool(key.mid(5).toStdString());
    if (!tool) return;
    showTool(tool);
    stack_->setCurrentWidget(toolPage_);
}

void GlassWindow::showTool(const nt::Tool* tool) {
    current_ = tool;
    const qreal dpr = devicePixelRatioF();
    QString title = fromStd(tool->title);
    QString subtitle = fromStd(tool->description);
    IconKind icon = IconKind::Tool;
    auto meta = navMeta_.find(tool->id);
    if (meta != navMeta_.end()) {
        title = meta->second.label;
        subtitle = meta->second.subtitle;
        icon = meta->second.icon;
    }
    pageTitle_->setText(title);
    pageSubtitle_->setText(subtitle);
    badge_->setPixmap(iconPixmap(icon, kAccentIcon, 26, dpr));

    while (QLayoutItem* item = fieldRow_->takeAt(0)) {
        delete item->widget();
        delete item;
    }
    fields_.clear();

    QLineEdit* firstEdit = nullptr;
    bool isFirst = true;
    for (const auto& p : tool->params) {
        auto* box = new QWidget;
        auto* v = new QVBoxLayout(box);
        v->setContentsMargins(0, 0, 0, 0);
        v->setSpacing(6);
        auto* label = new QLabel(fromStd(p.label));
        label->setObjectName(QStringLiteral("fieldLabel"));
        auto* edit = new QLineEdit;
        edit->setPlaceholderText(fromStd(p.placeholder));
        if (!p.def.empty()) edit->setText(fromStd(p.def));
        if (p.secret) edit->setEchoMode(QLineEdit::Password);
        const bool numeric = !p.def.empty() && std::all_of(p.def.begin(), p.def.end(), [](unsigned char ch) { return ch >= '0' && ch <= '9'; });
        if (numeric) {
            edit->setValidator(new QIntValidator(0, 999999999, edit));
            box->setFixedWidth(130);
        } else if (isFirst) {
            edit->setClearButtonEnabled(true);
        }
        v->addWidget(label);
        v->addWidget(edit);
        fieldRow_->addWidget(box, numeric ? 0 : (isFirst ? 4 : 2));
        connect(edit, &QLineEdit::returnPressed, this, [this]() { runClicked(); });
        fields_.insert(fromStd(p.key), edit);
        if (!firstEdit) firstEdit = edit;
        isFirst = false;
    }
    startBtn_->setText(tool->interactive ? QStringLiteral("Open in terminal") : QStringLiteral("Start"));
    statusLabel_->clear();
    if (firstEdit) firstEdit->setFocus();
}

void GlassWindow::openTool(const std::string& id, const nt::Args& args, bool autorun) {
    if (worker_) return;
    const QString key = QStringLiteral("tool:") + fromStd(id);
    for (int i = 0; i < navList_->count(); ++i) {
        QListWidgetItem* item = navList_->item(i);
        if (item->data(Qt::UserRole).toString() == key) {
            navList_->setCurrentItem(item);
            break;
        }
    }
    for (const auto& kv : args) {
        QLineEdit* edit = fields_.value(fromStd(kv.first), nullptr);
        if (edit) edit->setText(fromStd(kv.second));
    }
    if (autorun) runClicked();
}

void GlassWindow::runClicked() {
    if (!current_ || worker_) return;
    nt::Args args;
    for (const auto& p : current_->params) {
        QLineEdit* edit = fields_.value(fromStd(p.key), nullptr);
        std::string value = edit ? edit->text().trimmed().toStdString() : std::string();
        if (value.empty() && !p.def.empty()) value = p.def;
        if (p.required && value.empty()) {
            statusLabel_->setText(QStringLiteral("Please fill in: ") + fromStd(p.label));
            return;
        }
        args[p.key] = value;
    }
    if (current_->interactive) {
        launchInteractive(args);
        return;
    }

    output_->clear();
    std::string limitError;
    if (!nt::validateLimits(limitError)) {
        appendOutput(nt::Level::Bad, fromStd("Error: " + limitError + "\n"));
        return;
    }
    cancel_.flag.store(false);
    sink_ = std::make_unique<QtSink>(this);
    const nt::Tool* tool = current_;
    QtSink* sink = sink_.get();
    worker_ = QThread::create([this, tool, args, sink]() {
        const int rc = tool->run(args, *sink, cancel_);
        QMetaObject::invokeMethod(this, [this, rc]() { finished(rc); }, Qt::QueuedConnection);
    });
    setRunning(true);
    worker_->start();
}

void GlassWindow::stopClicked() {
    cancel_.cancel();
    stopBtn_->setEnabled(false);
    statusLabel_->setText(QStringLiteral("Stopping..."));
}

void GlassWindow::clearClicked() {
    output_->clear();
    statusLabel_->clear();
}

void GlassWindow::launchInteractive(const nt::Args& args) {
    output_->clear();
    std::vector<std::string> argv;
    std::string error;
    if (!nt::buildSshArgv(args, argv, error)) {
        appendOutput(nt::Level::Bad, fromStd("Error: " + error + "\n"));
        return;
    }
    const std::vector<std::string> wrapped = nt::terminalWrap(argv);
    if (wrapped.empty()) {
        std::string command;
        for (size_t i = 0; i < argv.size(); ++i) command += (i ? " " : "") + argv[i];
        appendOutput(nt::Level::Warn, QStringLiteral("No terminal emulator found. Run this yourself:\n"));
        appendOutput(nt::Level::Plain, fromStd("  " + command + "\n"));
        return;
    }
    QStringList list;
    for (size_t i = 1; i < wrapped.size(); ++i) list << fromStd(wrapped[i]);
    if (QProcess::startDetached(fromStd(wrapped[0]), list)) {
        appendOutput(nt::Level::Good, fromStd("Opened in " + wrapped[0] + ".\n"));
        statusLabel_->setText(QStringLiteral("Opened"));
    } else {
        appendOutput(nt::Level::Bad, fromStd("Error: could not start " + wrapped[0] + ".\n"));
    }
}

void GlassWindow::finished(int exitCode) {
    if (worker_) {
        worker_->wait();
        delete worker_;
        worker_ = nullptr;
    }
    setRunning(false);
    if (exitCode == 0) statusLabel_->setText(QStringLiteral("Done"));
    else if (exitCode == 130) statusLabel_->setText(QStringLiteral("Stopped"));
    else statusLabel_->setText(QStringLiteral("Finished with errors (exit code %1)").arg(exitCode));
}

void GlassWindow::setRunning(bool running) {
    startBtn_->setEnabled(!running);
    stopBtn_->setEnabled(running);
    navList_->setEnabled(!running);
    quickTrace_->setEnabled(!running);
    quickDns_->setEnabled(!running);
    quickScan_->setEnabled(!running);
    if (running) statusLabel_->setText(QStringLiteral("Running..."));
}

void GlassWindow::appendOutput(nt::Level level, const QString& text) {
    QColor color(233, 232, 255);
    bool bold = false;
    switch (level) {
        case nt::Level::Heading: color = QColor(160, 176, 255); bold = true; break;
        case nt::Level::Good: color = QColor(96, 232, 150); break;
        case nt::Level::Warn: color = QColor(255, 210, 120); break;
        case nt::Level::Bad: color = QColor(255, 128, 140); break;
        case nt::Level::Dim: color = QColor(160, 160, 200); break;
        default: break;
    }
    QTextCharFormat fmt;
    fmt.setForeground(color);
    if (bold) fmt.setFontWeight(QFont::Bold);
    QTextCursor cursor(output_->document());
    cursor.movePosition(QTextCursor::End);
    cursor.insertText(text, fmt);
    output_->verticalScrollBar()->setValue(output_->verticalScrollBar()->maximum());
}

void GlassWindow::refreshInfo() {
    std::vector<std::string> names = nt::listInterfaces();
    names.erase(std::remove(names.begin(), names.end(), std::string("lo")), names.end());
    QString key;
    for (const auto& n : names) {
        key += fromStd(n);
        key += QStringLiteral(",");
    }
    if (key != ifaceListKey_) {   // only rebuild the list when interfaces appear or disappear
        ifaceListKey_ = key;
        const QString previous = ifaceCombo_->currentText();
        ifaceCombo_->blockSignals(true);
        ifaceCombo_->clear();
        for (const auto& n : names) ifaceCombo_->addItem(fromStd(n));
        int idx = ifaceCombo_->findText(previous);
        if (idx < 0) idx = ifaceCombo_->findText(fromStd(nt::defaultInterface()));
        if (idx >= 0) ifaceCombo_->setCurrentIndex(idx);
        ifaceCombo_->blockSignals(false);
    }

    const std::string iface = ifaceCombo_->currentText().toStdString();
    nt::IfaceDetails d;
    const bool have = !iface.empty() && nt::ifaceDetails(iface, d);
    const QString dash = QStringLiteral("-");
    ipValue_->setText(have && !d.ipv4.empty() ? fromStd(d.ipv4) : dash);
    maskValue_->setText(have && !d.mask.empty() ? fromStd(d.mask) : dash);

    const nt::Route route = nt::defaultRoute();
    gatewayText_ = route.ok ? fromStd(route.gateway) : QString();
    gatewayValue_->setText(route.ok && route.iface == iface ? gatewayText_ : dash);

    std::string resolvers;
    for (const auto& r : nt::systemResolvers()) resolvers += (resolvers.empty() ? "" : ", ") + r;
    dnsValue_->setText(resolvers.empty() ? dash : fromStd(resolvers));

    hostValue_->setText(fromStd(nt::hostName()));
    osValue_->setText(fromStd(nt::osName()));
    kernelValue_->setText(fromStd(nt::kernelRelease()));
    uptimeValue_->setText(fromStd(nt::uptimeText()));
    quickScan_->setText(gatewayText_.isEmpty() ? QStringLiteral("Port Scan") : QStringLiteral("Port Scan ") + gatewayText_);
}

// --------------------------------------------------------- window chrome ----
void GlassWindow::applyChrome() {
    const int m = isMaximized() ? 0 : kMargin;
    layout()->setContentsMargins(m, m, m, m);
    maxBtn_->setIcon(makeIcon(isMaximized() ? IconKind::Restore : IconKind::Maximize, kIconNormal, kIconSelected, kIconDisabled, 16,
                              devicePixelRatioF()));
    update();
}

void GlassWindow::updateInfoPanelVisibility() {
    if (!infoPanel_) return;
    infoPanel_->setVisible(showInfo_ && width() >= 1100);
}

bool GlassWindow::edgesAt(const QPointF& pos, Qt::Edges& edges) const {
    edges = Qt::Edges();
    if (isMaximized()) return false;
    bool any = false;
    Qt::Edges found;
    if (pos.x() < kMargin) { found |= Qt::LeftEdge; any = true; }
    if (pos.x() > width() - kMargin) { found |= Qt::RightEdge; any = true; }
    if (pos.y() < kMargin) { found |= Qt::TopEdge; any = true; }
    if (pos.y() > height() - kMargin) { found |= Qt::BottomEdge; any = true; }
    edges = found;
    return any;
}

void GlassWindow::paintEvent(QPaintEvent*) {
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);
    const int m = isMaximized() ? 0 : kMargin;
    const double radius = isMaximized() ? 0.0 : 16.0;
    const QRectF body = QRectF(rect()).adjusted(m, m, -m, -m);
    QPainterPath shape;
    shape.addRoundedRect(body, radius, radius);

    if (m > 0) {   // soft drop shadow, only outside the window body
        p.save();
        QPainterPath outside;
        outside.addRect(QRectF(rect()));
        p.setClipPath(outside.subtracted(shape));
        p.setPen(Qt::NoPen);
        for (int i = 0; i < 9; ++i) {
            p.setBrush(QColor(0, 0, 0, 11));
            p.drawRoundedRect(body.adjusted(-i, -i + 3, i, i + 3), radius + i, radius + i);
        }
        p.restore();
    }

    p.save();
    p.setClipPath(shape);
    const int alpha = opacity_ * 255 / 100;
    QLinearGradient base(body.topLeft(), body.bottomRight());
    base.setColorAt(0.0, QColor(26, 23, 68, alpha));
    base.setColorAt(1.0, QColor(13, 12, 36, alpha));
    p.fillRect(body, base);

    // A faint, slow glow behind the panels (the "liquid" part; Settings can turn it off).
    const double bloomRadius = std::max(body.width(), body.height()) * 0.55;
    auto bloom = [&](double fx, double fy, QColor c) {
        const QPointF centre(body.left() + body.width() * fx, body.top() + body.height() * fy);
        QRadialGradient g(centre, bloomRadius);
        QColor outer = c;
        c.setAlpha(std::min(70, alpha / 4));
        outer.setAlpha(0);
        g.setColorAt(0.0, c);
        g.setColorAt(1.0, outer);
        p.fillRect(body, QBrush(g));
    };
    bloom(0.12 + 0.05 * std::sin(phase_), 0.18 + 0.05 * std::cos(phase_ * 0.8), QColor(120, 92, 255));
    bloom(0.90 + 0.04 * std::cos(phase_ * 1.1), 0.85 + 0.04 * std::sin(phase_ * 0.7), QColor(170, 70, 255));
    p.restore();

    p.setPen(QPen(QColor(255, 255, 255, 36), 1.0));
    p.setBrush(Qt::NoBrush);
    p.drawPath(shape);
}

void GlassWindow::mousePressEvent(QMouseEvent* event) {
    Qt::Edges edges;
    if (event->button() == Qt::LeftButton && edgesAt(event->position(), edges) && windowHandle()) {
        windowHandle()->startSystemResize(edges);
        event->accept();
        return;
    }
    QWidget::mousePressEvent(event);
}

void GlassWindow::mouseMoveEvent(QMouseEvent* event) {
    Qt::Edges edges;
    if (edgesAt(event->position(), edges)) {
        const double x = event->position().x(), y = event->position().y();
        const bool left = x < kMargin, right = x > width() - kMargin, top = y < kMargin, bottom = y > height() - kMargin;
        if ((left && top) || (right && bottom)) setCursor(Qt::SizeFDiagCursor);
        else if ((right && top) || (left && bottom)) setCursor(Qt::SizeBDiagCursor);
        else if (left || right) setCursor(Qt::SizeHorCursor);
        else setCursor(Qt::SizeVerCursor);
    } else {
        unsetCursor();
    }
    QWidget::mouseMoveEvent(event);
}

void GlassWindow::resizeEvent(QResizeEvent* event) {
    QWidget::resizeEvent(event);
    updateInfoPanelVisibility();
}

void GlassWindow::closeEvent(QCloseEvent* event) {
    if (worker_) {
        cancel_.cancel();
        worker_->wait(5000);
    }
    QWidget::closeEvent(event);
}

void GlassWindow::changeEvent(QEvent* event) {
    QWidget::changeEvent(event);
    if (event->type() == QEvent::WindowStateChange) applyChrome();
}
