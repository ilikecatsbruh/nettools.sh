// nettool core engine: Qt-free, POSIX, C++17.
// Everything the CLI and the GUI do lives behind this API.
#pragma once

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <utility>
#include <vector>

#include <sys/socket.h>

namespace nt {

constexpr const char* kVersion = "3.0.0";

// ---------------------------------------------------------------- output ----
enum class Level { Plain, Heading, Good, Warn, Bad, Dim };

class Sink {
public:
    virtual ~Sink() = default;
    virtual void write(Level level, const std::string& text) = 0;
    void line(Level level, const std::string& text) { write(level, text + "\n"); }
    void line(const std::string& text) { line(Level::Plain, text); }
    void error(const std::string& text) { line(Level::Bad, "Error: " + text); }
};

struct Cancel {
    std::atomic<bool> flag{false};
    bool cancelled() const { return flag.load(); }
    void cancel() { flag.store(true); }
};

using Args = std::map<std::string, std::string>;

// ------------------------------------------------------------------ text ----
std::string trim(const std::string& s);
std::vector<std::string> split(const std::string& s, char sep);
std::string sanitize(const std::string& s);   // strip terminal control bytes
std::string urlEncode(const std::string& s);
std::string formatRate(uint64_t bytesPerSecond);

class LineBuffer {   // turns arbitrary output chunks into whole lines
public:
    void feed(const std::string& chunk, const std::function<void(const std::string&)>& emit);
    void flush(const std::function<void(const std::string&)>& emit);
private:
    std::string buf_;
};

// ------------------------------------------------------------ validation ----
bool isIPv4(const std::string& s);
bool isIPv6Literal(const std::string& s);
bool isValidHost(const std::string& s);                 // hostname, IPv4 or IPv6
bool isValidPort(const std::string& s, int* out = nullptr);
bool isPositiveInt(const std::string& s, long maxValue, long* out = nullptr);
bool isValidPrefix(const std::string& s);               // a.b.c
bool isValidEmail(const std::string& s);
bool isValidUrl(const std::string& s);                  // http(s) only
bool isValidIface(const std::string& s);

// ------------------------------------------------------------------ CIDR ----
struct CidrInfo {
    std::string address, netmask, wildcard, network, broadcast, first, last;
    uint64_t hosts = 0;
    int bits = 0;
};
bool calcCidr(const std::string& input, CidrInfo& out, std::string& err);

// ------------------------------------------------------------------ JSON ----
struct Json {
    enum class Type { Null, Bool, Number, String, Array, Object };
    Type type = Type::Null;
    bool boolean = false;
    double number = 0;
    std::string str;
    std::vector<Json> arr;
    std::vector<std::pair<std::string, Json>> obj;

    const Json* get(const std::string& key) const;       // objects only
    std::string asString(const std::string& fallback = "") const;
    static bool parse(const std::string& text, Json& out);
};

// ------------------------------------------------------------- processes ----
bool commandExists(const std::string& name);
// Runs argv directly (never through a shell). stdout+stderr are streamed to
// onOutput. Returns the exit status, or: -1 could not start, -2 cancelled,
// -3 timed out.
int runProcess(const std::vector<std::string>& argv, const std::string& stdinData,
               const std::function<void(const std::string&)>& onOutput,
               const Cancel* cancel = nullptr, int timeoutMs = 0);
std::string captureProcess(const std::vector<std::string>& argv, const std::string& stdinData = "",
                           int* status = nullptr, const Cancel* cancel = nullptr, int timeoutMs = 0);

// --------------------------------------------------------------- network ----
struct Endpoint {
    sockaddr_storage addr{};
    socklen_t len = 0;
    int family = 0;
};
std::vector<Endpoint> resolveHost(const std::string& host, int port, int socktype, std::string& err);
std::string endpointText(const Endpoint& ep);
// Non-blocking connect with timeout. Returns a connected fd, or -1.
int connectEndpoint(const Endpoint& ep, int timeoutMs, const Cancel* cancel, std::string* err);
// Waits until fd is readable; returns bytes read (0 = nothing/EOF within the wait).
std::string readSome(int fd, int waitMs, size_t maxBytes);
bool sleepCancellable(int ms, const Cancel& cancel);

// ------------------------------------------------------------------- DNS ----
enum DnsType : uint16_t { T_A = 1, T_NS = 2, T_CNAME = 5, T_PTR = 12, T_MX = 15, T_TXT = 16, T_AAAA = 28 };
struct DnsRecord { std::string type, text; };
struct DnsResult {
    bool ok = false;
    int rcode = 0;
    std::string error;
    std::vector<DnsRecord> records;
};
std::vector<uint8_t> buildDnsQuery(const std::string& name, uint16_t qtype, uint16_t id, std::string& err);
// Parses a response; sets truncated when TC is set. Never reads out of bounds.
bool parseDnsResponse(const uint8_t* data, size_t len, uint16_t expectId, DnsResult& out, bool& truncated);
DnsResult dnsQuery(const std::string& server, const std::string& name, uint16_t qtype,
                   int timeoutMs, const Cancel* cancel);
std::vector<std::string> systemResolvers();

// ----------------------------------------------------------- system info ----
struct Route { bool ok = false; std::string iface, gateway; };
Route defaultRoute();
struct SockEntry { std::string proto, local, state; int port = 0; };
bool readProcSockets(std::vector<SockEntry>& out);
std::vector<std::string> listInterfaces();
std::string defaultInterface();
bool readIfaceCounters(const std::string& iface, uint64_t& rx, uint64_t& tx);
std::string detectLocalPrefix();      // "192.168.1" or ""

// ------------------------------------------------- host / OS / interface ----
struct IfaceDetails { std::string name, ipv4, mask, mac; bool up = false; };
bool ifaceDetails(const std::string& name, IfaceDetails& out);
std::string hostName();
std::string osName();
std::string kernelRelease();
std::string formatUptime(uint64_t seconds);   // "3d 4h", "2h 34m", "5m"
std::string uptimeText();                     // "n/a" where /proc/uptime is unavailable

// ---------------------------------------------------------- concurrency ----
int maxParallelProbe();               // NETTOOL_MAX_PARALLEL_PROBE (default 50)
int maxParallelSweep();               // NETTOOL_MAX_PARALLEL_SWEEP (default 40)
bool validateLimits(std::string& err);
void parallelFor(size_t n, int maxThreads, const Cancel& cancel,
                 const std::function<void(size_t)>& fn);

}  // namespace nt
