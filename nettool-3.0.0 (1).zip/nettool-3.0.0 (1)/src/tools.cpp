#include "tools.hpp"

#include <algorithm>
#include <arpa/inet.h>
#include <chrono>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <ifaddrs.h>
#include <mutex>
#include <net/if.h>
#include <netinet/in.h>
#include <poll.h>
#include <set>
#include <sstream>
#include <sys/stat.h>
#include <unistd.h>
#if defined(__linux__)
#include <linux/if_packet.h>
#endif

namespace nt {
namespace {

// ---------------------------------------------------------------- helpers ----
std::string arg(const Args& a, const std::string& key, const std::string& def = "") {
    auto it = a.find(key);
    if (it == a.end()) return def;
    std::string v = trim(it->second);
    return v.empty() ? def : v;
}

class LockedSink {   // tools that use worker threads funnel output through this
public:
    explicit LockedSink(Sink& s) : s_(s) {}
    void line(Level l, const std::string& t) { std::lock_guard<std::mutex> g(m_); s_.line(l, t); }
private:
    Sink& s_;
    std::mutex m_;
};

std::string platformInstallHint(const std::string& cmd) {
    struct Pkg { const char* cmd; const char *arch, *debian, *termux, *brew; };
    static const Pkg table[] = {
        {"ping", "iputils", "iputils-ping", "iputils", ""},
        {"tracepath", "iputils", "iputils-tracepath", "iputils", ""},
        {"traceroute", "traceroute", "traceroute", "traceroute", "traceroute"},
        {"curl", "curl", "curl", "curl", "curl"},
        {"openssl", "openssl", "openssl", "openssl-tool", "openssl"},
        {"ss", "iproute2", "iproute2", "iproute2", ""},
        {"ip", "iproute2", "iproute2", "iproute2", ""},
        {"netstat", "net-tools", "net-tools", "net-tools", ""},
        {"ssh", "openssh", "openssh-client", "openssh", ""},
    };
    const char* prefix = std::getenv("PREFIX");
    bool termux = (prefix && std::string(prefix).find("com.termux") != std::string::npos) || std::getenv("TERMUX_VERSION");
    for (const auto& p : table) {
        if (cmd != p.cmd) continue;
        if (termux) return std::string("Install with: pkg install ") + p.termux;
        if (commandExists("pacman")) return std::string("Install with: sudo pacman -S ") + p.arch;
        if (commandExists("apt-get")) return std::string("Install with: sudo apt install ") + p.debian;
        if (commandExists("brew") && p.brew[0]) return std::string("Install with: brew install ") + p.brew;
    }
    return "Install the package that provides '" + cmd + "'.";
}

void missingTool(Sink& s, const std::string& cmd) {
    s.error("'" + cmd + "' is required but not installed.");
    s.line(Level::Dim, platformInstallHint(cmd));
}

int streamCommand(const std::vector<std::string>& argv, Sink& s, const Cancel& c, int timeoutMs = 0,
                  const std::string& stdinData = "") {
    LineBuffer lb;
    auto emit = [&](const std::string& l) { s.line(sanitize(l)); };
    int rc = runProcess(argv, stdinData, [&](const std::string& chunk) { lb.feed(chunk, emit); }, &c, timeoutMs);
    lb.flush(emit);
    if (rc == -1) { missingTool(s, argv[0]); return 1; }
    if (rc == -2) { s.line(Level::Warn, "Cancelled."); return 130; }
    if (rc == -3) { s.line(Level::Warn, "Timed out."); return 1; }
    return rc;
}

std::string joinStrings(const std::vector<std::string>& v, const std::string& sep) {
    std::string out;
    for (size_t i = 0; i < v.size(); ++i) { if (i) out += sep; out += v[i]; }
    return out;
}

std::vector<std::string> pingWait() {
#ifdef __APPLE__
    return {"-t", "1"};   // BSD ping: -W is milliseconds, so use the overall timeout
#else
    return {"-W", "1"};
#endif
}

bool pingOnce(const std::string& host, const Cancel& c) {
    std::vector<std::string> argv = {"ping", "-c", "1"};
    for (const auto& w : pingWait()) argv.push_back(w);
    argv.push_back(host);
    return runProcess(argv, "", nullptr, &c, 4000) == 0;
}

bool parseRtt(const std::string& line, double& out) {
    size_t pos = line.find("time=");
    if (pos == std::string::npos) pos = line.find("time<");
    if (pos == std::string::npos) return false;
    const char* start = line.c_str() + pos + 5;
    char* end = nullptr;
    double v = std::strtod(start, &end);
    if (end == start) return false;
    out = v;
    return true;
}

bool plainIp(const std::string& s) {
    if (s.empty() || s.size() > 45) return false;
    return std::all_of(s.begin(), s.end(), [](unsigned char ch) { return std::isxdigit(ch) || ch == ':' || ch == '.'; });
}

std::string errnoText(int e) { return std::strerror(e); }

// ------------------------------------------------------------------ tools ----
int toolCidr(const Args& a, Sink& s, const Cancel&) {
    CidrInfo i;
    std::string err;
    if (!calcCidr(arg(a, "cidr"), i, err)) { s.error(err); return 2; }
    s.line("Address:    " + i.address);
    s.line("Netmask:    " + i.netmask);
    s.line("Wildcard:   " + i.wildcard);
    s.line("Network:    " + i.network);
    s.line("Broadcast:  " + i.broadcast);
    s.line("Host range: " + i.first + " - " + i.last);
    s.line("Usable:     " + std::to_string(i.hosts) + " host(s)");
    return 0;
}

int toolNetping(const Args& a, Sink& s, const Cancel& c) {
    std::string host = arg(a, "host");
    long count = 0, threads = 0, size = 0;
    if (!isValidHost(host)) { s.error("Invalid host or IP address."); return 2; }
    if (!isPositiveInt(arg(a, "count", "4"), 1000, &count) || !isPositiveInt(arg(a, "threads", "1"), 64, &threads) ||
        !isPositiveInt(arg(a, "size", "56"), 65507, &size)) {
        s.error("Limits: count 1-1000, threads 1-64, payload size 1-65507 bytes.");
        return 2;
    }
    if (!commandExists("ping")) { missingTool(s, "ping"); return 1; }
    s.line("Pinging " + host + " (" + std::to_string(threads) + " thread(s), " + std::to_string(count) + " ping(s) per thread, " +
           std::to_string(size) + "-byte payload)");

    LockedSink out(s);
    std::vector<std::vector<double>> rtts(static_cast<size_t>(threads));
    parallelFor(static_cast<size_t>(threads), maxParallelProbe(), c, [&](size_t t) {
        LineBuffer lb;
        std::string tag = "[Thread " + std::to_string(t + 1) + "] ";
        auto emit = [&](const std::string& line) {
            double v;
            const bool reply = parseRtt(line, v);
            out.line(reply ? Level::Good : Level::Plain, tag + sanitize(line));
            if (reply) rtts[t].push_back(v);
        };
        runProcess({"ping", "-c", std::to_string(count), "-s", std::to_string(size), host}, "",
                   [&](const std::string& chunk) { lb.feed(chunk, emit); }, &c, 0);
        lb.flush(emit);
    });
    if (c.cancelled()) { s.line(Level::Warn, "Cancelled."); return 130; }

    s.line(Level::Heading, "\nRTT / Jitter Summary");
    int rc = 1;
    for (size_t t = 0; t < rtts.size(); ++t) {
        const auto& v = rtts[t];
        if (v.empty()) { s.line(Level::Bad, "[Thread " + std::to_string(t + 1) + "] No RTT samples captured (unreachable or filtered)."); continue; }
        double sum = 0, mn = v[0], mx = v[0], jit = 0;
        for (size_t i = 0; i < v.size(); ++i) {
            sum += v[i]; mn = std::min(mn, v[i]); mx = std::max(mx, v[i]);
            if (i > 0) jit += std::abs(v[i] - v[i - 1]);
        }
        if (v.size() > 1) jit /= static_cast<double>(v.size() - 1);
        char buf[200];
        std::snprintf(buf, sizeof buf, "[Thread %zu] samples=%zu min/avg/max=%.2f/%.2f/%.2f ms jitter=%.2f ms",
                      t + 1, v.size(), mn, sum / static_cast<double>(v.size()), mx, jit);
        s.line(Level::Good, buf);
        rc = 0;
    }
    return rc;
}

bool buildSshArgvImpl(const Args& a, std::vector<std::string>& argv, std::string& err) {
    std::string host = arg(a, "host"), user = arg(a, "user"), key = arg(a, "key"), portText = arg(a, "port", "22");
    int port = 22;
    if (!isValidHost(host)) { err = "Invalid host."; return false; }
    if (!user.empty()) {
        bool ok = std::isalpha(static_cast<unsigned char>(user[0])) || user[0] == '_';
        for (unsigned char ch : user) ok = ok && (std::isalnum(ch) || ch == '_' || ch == '.' || ch == '-');
        if (!ok) { err = "Invalid SSH username."; return false; }
    }
    if (!isValidPort(portText, &port)) { err = "Port must be between 1 and 65535."; return false; }
    if (!key.empty() && (key[0] == '-' || key.find('\n') != std::string::npos)) { err = "Invalid key path."; return false; }
    argv = {"ssh"};
    if (port != 22) { argv.push_back("-p"); argv.push_back(std::to_string(port)); }
    if (!key.empty()) { argv.push_back("-i"); argv.push_back(key); }
    argv.push_back(user.empty() ? host : user + "@" + host);
    return true;
}

int toolSsh(const Args& a, Sink& s, const Cancel&) {   // fallback when no terminal can be opened
    std::vector<std::string> argv;
    std::string err;
    if (!buildSshArgvImpl(a, argv, err)) { s.error(err); return 2; }
    s.line("Run this in a terminal:");
    s.line("  " + joinStrings(argv, " "));
    return 0;
}

// -- WHOIS (native, follows referrals) ---------------------------------------
bool whoisQuery(const std::string& serverSpec, const std::string& query, std::string& response, std::string& err, const Cancel& c) {
    std::string host = serverSpec;
    int port = 43;
    auto colon = serverSpec.rfind(':');
    if (colon != std::string::npos && serverSpec.find(':') == colon) {
        host = serverSpec.substr(0, colon);
        if (!isValidPort(serverSpec.substr(colon + 1), &port)) { err = "bad whois port"; return false; }
    }
    if (!isValidHost(host)) { err = "bad whois server name"; return false; }
    auto eps = resolveHost(host, port, SOCK_STREAM, err);
    if (eps.empty()) return false;
    int fd = -1;
    for (const auto& ep : eps) { fd = connectEndpoint(ep, 8000, &c, &err); if (fd >= 0) break; }
    if (fd < 0) return false;
    std::string q = query + "\r\n";
    if (::write(fd, q.data(), q.size()) < 0) { err = errnoText(errno); ::close(fd); return false; }
    response.clear();
    auto start = std::chrono::steady_clock::now();
    while (response.size() < (256u << 10) && !c.cancelled()) {
        if (std::chrono::steady_clock::now() - start > std::chrono::seconds(12)) break;
        pollfd pfd{fd, POLLIN, 0};
        int pr = ::poll(&pfd, 1, 200);
        if (pr <= 0) continue;
        char buf[4096];
        ssize_t n = ::read(fd, buf, sizeof buf);
        if (n <= 0) break;
        response.append(buf, static_cast<size_t>(n));
    }
    ::close(fd);
    return true;
}

std::string findReferral(const std::string& response) {
    static const char* keys[] = {"refer:", "whois:", "referralserver:", "registrar whois server:"};
    std::istringstream ss(response);
    for (std::string line; std::getline(ss, line);) {
        std::string lower = line;
        std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char ch) { return std::tolower(ch); });
        lower = trim(lower);
        for (const char* key : keys) {
            size_t klen = std::strlen(key);
            if (lower.compare(0, klen, key) != 0) continue;
            std::string value = trim(trim(line).substr(klen));
            for (const char* scheme : {"whois://", "rwhois://"}) {
                if (value.rfind(scheme, 0) == 0) value = value.substr(std::strlen(scheme));
            }
            while (!value.empty() && value.back() == '/') value.pop_back();
            if (!value.empty()) return value;
        }
    }
    return "";
}

int toolWhois(const Args& a, Sink& s, const Cancel& c) {
    std::string query = arg(a, "query");
    if (!isValidHost(query)) { s.error("Enter a domain, IP address, or ASN (letters, digits, dots, hyphens, colons)."); return 2; }
    const char* root = std::getenv("NETTOOL_WHOIS_ROOT");
    std::string server = root ? root : "whois.iana.org", response, err, path = server;
    for (int hop = 0; hop < 4; ++hop) {
        if (!whoisQuery(server, query, response, err, c)) { s.error("WHOIS query to " + server + " failed: " + err); return 1; }
        std::string next = findReferral(response);
        auto lower = [](std::string x) { std::transform(x.begin(), x.end(), x.begin(), [](unsigned char ch) { return std::tolower(ch); }); return x; };
        if (next.empty() || lower(next) == lower(server) || hop == 3) break;
        path += " -> " + next;
        server = next;
    }
    s.line(Level::Dim, "Referral path: " + path);
    s.line(sanitize(response));
    return c.cancelled() ? 130 : 0;
}

// -- Public IP ----------------------------------------------------------------
int toolPublicIp(const Args&, Sink& s, const Cancel& c) {
    if (!commandExists("curl")) { missingTool(s, "curl"); return 1; }
    static const char* providers[] = {"https://ipinfo.io/json", "https://ipwho.is/", "https://ipapi.co/json/"};
    auto field = [](const Json& j, const char* k) -> std::string {
        const Json* v = j.get(k);
        return v ? v->asString() : "";
    };
    for (const char* url : providers) {
        if (c.cancelled()) return 130;
        int st = 0;
        std::string body = captureProcess({"curl", "--silent", "--location", "--max-time", "8", "--header",
                                           std::string("User-Agent: nettool/") + kVersion, "--header", "Accept: application/json", url},
                                          "", &st, &c, 12000);
        Json j;
        if (st != 0 || !Json::parse(body, j) || j.type != Json::Type::Object) continue;
        const Json* err = j.get("error");
        const Json* success = j.get("success");
        if ((err && err->type == Json::Type::Bool && err->boolean) || (success && success->type == Json::Type::Bool && !success->boolean)) continue;
        std::string ip = field(j, "ip");
        if (!plainIp(ip)) continue;
        std::string country = field(j, "country_name");
        if (country.empty()) country = field(j, "country");
        std::string org = field(j, "org"), asn = field(j, "asn");
        if (const Json* conn = j.get("connection")) {
            if (org.empty()) org = field(*conn, "org");
            if (asn.empty()) asn = field(*conn, "asn");
        }
        auto or_na = [](const std::string& v) { return v.empty() ? std::string("n/a") : sanitize(v); };
        s.line("IP:      " + ip);
        s.line("City:    " + or_na(field(j, "city")));
        s.line("Region:  " + or_na(field(j, "region")));
        s.line("Country: " + or_na(country));
        s.line("Org:     " + or_na(org));
        if (!asn.empty()) s.line("ASN:     " + sanitize(asn));
        std::string hostPart = std::string(url).substr(8);
        s.line(Level::Dim, "Source:  " + hostPart.substr(0, hostPart.find('/')));
        return 0;
    }
    int st = 0;
    std::string ip = trim(captureProcess({"curl", "--silent", "--max-time", "8", "https://api.ipify.org"}, "", &st, &c, 12000));
    if (st == 0 && plainIp(ip)) {
        s.line("IP:      " + ip);
        s.line(Level::Dim, "(location services unavailable; showing the address only)");
        return 0;
    }
    s.error("Could not determine your public IP (no internet, DNS blocked, or the lookup services rate-limited you).");
    return 1;
}

// -- TLS certificate -----------------------------------------------------------
int toolSsl(const Args& a, Sink& s, const Cancel& c) {
    std::string host = arg(a, "host"), portText = arg(a, "port", "443");
    int port = 443;
    if (!isValidHost(host)) { s.error("Invalid domain or IP address."); return 2; }
    if (!isValidPort(portText, &port)) { s.error("Port must be between 1 and 65535."); return 2; }
    if (!commandExists("openssl")) { missingTool(s, "openssl"); return 1; }
    bool isIp = isIPv4(host) || host.find(':') != std::string::npos;
    std::string endpoint = (host.find(':') != std::string::npos ? "[" + host + "]" : host) + ":" + std::to_string(port);
    std::vector<std::string> argv = {"openssl", "s_client", "-connect", endpoint};
    if (!isIp) { argv.push_back("-servername"); argv.push_back(host); }
    s.line(Level::Heading, "--- TLS Certificate: " + host + ":" + std::to_string(port) + " ---");
    int st = 0;
    std::string raw = captureProcess(argv, "", &st, &c, 10000);
    if (c.cancelled()) return 130;
    int st2 = 0;
    std::string info = captureProcess({"openssl", "x509", "-noout", "-issuer", "-subject", "-dates"}, raw, &st2, &c, 5000);
    if (st2 != 0 || info.find("notAfter=") == std::string::npos) {
        s.error("Could not retrieve a TLS certificate. The port may be closed, filtered, or not using TLS.");
        return 1;
    }
    s.line(sanitize(trim(info)));
    auto pos = info.find("notAfter=");
    std::string na = trim(info.substr(pos + 9, info.find('\n', pos) - pos - 9));
    struct tm tmv{};
    if (strptime(na.c_str(), "%b %d %H:%M:%S %Y", &tmv)) {
        time_t expiry = timegm(&tmv), now = std::time(nullptr);
        if (expiry < now) s.line(Level::Bad, "[!] Certificate has EXPIRED.");
        else {
            long days = static_cast<long>((expiry - now) / 86400);
            if (days < 30) s.line(Level::Warn, "[!] Certificate expires in " + std::to_string(days) + " day(s).");
            else s.line(Level::Good, "[OK] Certificate is valid for another " + std::to_string(days) + " day(s).");
        }
    }
    return 0;
}

int toolHeaders(const Args& a, Sink& s, const Cancel& c) {
    std::string url = arg(a, "url");
    if (!isValidUrl(url)) { s.error("That doesn't look like a valid http:// or https:// URL."); return 2; }
    if (!commandExists("curl")) { missingTool(s, "curl"); return 1; }
    return streamCommand({"curl", "--head", "--silent", "--show-error", "--location", "--max-time", "15", url}, s, c);
}

int toolHttpTime(const Args& a, Sink& s, const Cancel& c) {
    std::string url = arg(a, "url");
    if (!isValidUrl(url)) { s.error("That doesn't look like a valid http:// or https:// URL."); return 2; }
    if (!commandExists("curl")) { missingTool(s, "curl"); return 1; }
    s.line(Level::Dim, "Timings are cumulative seconds from the start of the request.");
    return streamCommand({"curl", "--silent", "--show-error", "--location", "--max-time", "20", "--output", "/dev/null", "--write-out",
                          "HTTP status:   %{http_code}\nRemote IP:     %{remote_ip}\nRedirects:     %{num_redirects}\n"
                          "DNS lookup:    %{time_namelookup}s\nTCP connect:   %{time_connect}s\nTLS handshake: %{time_appconnect}s\n"
                          "First byte:    %{time_starttransfer}s\nTotal:         %{time_total}s\n",
                          url}, s, c);
}

int toolSpeed(const Args&, Sink& s, const Cancel& c) {
    if (!commandExists("curl")) { missingTool(s, "curl"); return 1; }
    s.line(Level::Warn, "Downloading a 25 MB test file from Cloudflare; this uses your data plan.");
    return streamCommand({"curl", "--fail", "--location", "--silent", "--show-error", "--max-time", "90", "--output", "/dev/null",
                          "--write-out", "Downloaded: %{size_download} bytes\nTotal time: %{time_total}s\nAverage speed: %{speed_download} B/s\n",
                          "https://speed.cloudflare.com/__down?bytes=25000000"}, s, c);
}

// -- DNS ------------------------------------------------------------------------
int toolDns(const Args& a, Sink& s, const Cancel& c) {
    std::string domain = arg(a, "domain");
    if (!isValidHost(domain) || isIPv4(domain) || domain.find(':') != std::string::npos) { s.error("Invalid domain name."); return 2; }
    struct Provider { const char* name; const char* ip; };
    static const Provider providers[] = {{"Cloudflare", "1.1.1.1"}, {"Google", "8.8.8.8"}, {"Quad9", "9.9.9.9"}, {"OpenDNS", "208.67.222.222"}};
    std::vector<DnsResult> results(4);
    parallelFor(4, 4, c, [&](size_t i) { results[i] = dnsQuery(providers[i].ip, domain, T_A, 2500, &c); });
    if (c.cancelled()) return 130;
    s.line("A-record responses for " + domain + ":");
    std::set<std::string> distinct;
    int answered = 0;
    for (size_t i = 0; i < 4; ++i) {
        std::vector<std::string> ips;
        for (const auto& r : results[i].records) if (r.type == "A") ips.push_back(r.text);
        std::sort(ips.begin(), ips.end());
        char head[64];
        std::snprintf(head, sizeof head, "%-12s %-15s ", providers[i].name, providers[i].ip);
        if (!results[i].error.empty()) s.line(Level::Bad, head + std::string("No answer (") + results[i].error + ")");
        else if (results[i].rcode == 3) s.line(Level::Bad, head + std::string("NXDOMAIN (domain does not exist)"));
        else if (ips.empty()) s.line(Level::Warn, head + std::string("Responded, but no A records"));
        else { s.line(Level::Good, head + joinStrings(ips, " ")); distinct.insert(joinStrings(ips, " ")); ++answered; }
    }
    if (answered >= 2) {
        if (distinct.size() == 1) s.line(Level::Good, "All responding resolvers agree.");
        else s.line(Level::Warn, "Resolvers returned different answers (normal during propagation or with geo-DNS).");
    }
    return answered > 0 ? 0 : 1;
}

DnsResult queryViaSystem(const std::string& name, uint16_t type, const Cancel& c) {
    DnsResult last;
    for (const auto& server : systemResolvers()) {
        last = dnsQuery(server, name, type, 3000, &c);
        if (last.error.empty()) return last;
        if (c.cancelled()) break;
    }
    return last;
}

int toolRecords(const Args& a, Sink& s, const Cancel& c) {
    std::string domain = arg(a, "domain");
    if (!isValidHost(domain) || isIPv4(domain) || domain.find(':') != std::string::npos) { s.error("Invalid domain name."); return 2; }
    static const struct { const char* name; uint16_t type; } types[] = {{"A", T_A}, {"AAAA", T_AAAA}, {"CNAME", T_CNAME}, {"MX", T_MX}, {"NS", T_NS}, {"TXT", T_TXT}};
    for (const auto& t : types) {
        if (c.cancelled()) return 130;
        DnsResult r = queryViaSystem(domain, t.type, c);
        s.line(Level::Heading, std::string("--- ") + t.name + " ---");
        if (!r.error.empty()) { s.line(Level::Bad, "lookup failed: " + r.error); continue; }
        if (r.rcode == 3) { s.line(Level::Bad, "NXDOMAIN (domain does not exist)"); return 1; }
        bool any = false;
        for (const auto& rec : r.records) if (rec.type == t.name) { s.line(rec.text); any = true; }
        if (!any) s.line(Level::Dim, "(none)");
    }
    return 0;
}

int toolRdns(const Args& a, Sink& s, const Cancel& c) {
    std::string ip = arg(a, "ip"), name;
    if (isIPv4(ip)) {
        auto p = split(ip, '.');
        name = p[3] + "." + p[2] + "." + p[1] + "." + p[0] + ".in-addr.arpa";
    } else if (isIPv6Literal(ip)) {
        in6_addr addr;
        inet_pton(AF_INET6, ip.c_str(), &addr);
        static const char* hex = "0123456789abcdef";
        for (int i = 15; i >= 0; --i) {
            name.push_back(hex[addr.s6_addr[i] & 15]); name.push_back('.');
            name.push_back(hex[addr.s6_addr[i] >> 4]); name.push_back('.');
        }
        name += "ip6.arpa";
    } else { s.error("Enter an IPv4 or IPv6 address."); return 2; }
    DnsResult r = queryViaSystem(name, T_PTR, c);
    if (!r.error.empty()) { s.error("Lookup failed: " + r.error); return 1; }
    bool any = false;
    for (const auto& rec : r.records) if (rec.type == "PTR") { s.line(Level::Good, ip + " -> " + rec.text); any = true; }
    if (!any) s.line(Level::Warn, "No PTR record for " + ip + ".");
    return any ? 0 : 1;
}

// -- Connectivity ------------------------------------------------------------------
int toolPorts(const Args& a, Sink& s, const Cancel& c) {
    std::string host = arg(a, "host");
    int p1 = 1, p2 = 1024;
    if (!isValidHost(host)) { s.error("Invalid host or IP address."); return 2; }
    if (!isValidPort(arg(a, "start", "1"), &p1) || !isValidPort(arg(a, "end", "1024"), &p2) || p1 > p2) {
        s.error("Invalid TCP port range (1-65535; start must not exceed end).");
        return 2;
    }
    std::string err;
    auto eps = resolveHost(host, p1, SOCK_STREAM, err);   // resolved once, not once per port
    if (eps.empty()) { s.error("Cannot resolve " + host + ": " + err); return 1; }
    s.line(Level::Dim, "Only scan systems you own or have permission to test.");
    s.line("Scanning " + host + " ports " + std::to_string(p1) + "-" + std::to_string(p2) + " (up to " + std::to_string(maxParallelProbe()) + " concurrent connections)...");
    LockedSink out(s);
    std::mutex m;
    std::vector<int> open;
    parallelFor(static_cast<size_t>(p2 - p1 + 1), maxParallelProbe(), c, [&](size_t i) {
        int port = p1 + static_cast<int>(i);
        for (Endpoint ep : eps) {
            if (ep.family == AF_INET) reinterpret_cast<sockaddr_in*>(&ep.addr)->sin_port = htons(static_cast<uint16_t>(port));
            else if (ep.family == AF_INET6) reinterpret_cast<sockaddr_in6*>(&ep.addr)->sin6_port = htons(static_cast<uint16_t>(port));
            int fd = connectEndpoint(ep, 1500, &c, nullptr);
            if (fd >= 0) {
                ::close(fd);
                { std::lock_guard<std::mutex> g(m); open.push_back(port); }
                out.line(Level::Good, "[+] TCP port " + std::to_string(port) + " is open");
                break;
            }
        }
    });
    if (c.cancelled()) { s.line(Level::Warn, "Scan cancelled."); return 130; }
    std::sort(open.begin(), open.end());
    std::vector<std::string> names;
    for (int p : open) names.push_back(std::to_string(p));
    s.line(open.empty() ? "Port scan completed: no open ports found." : "Port scan completed: " + std::to_string(open.size()) + " open (" + joinStrings(names, ", ") + ").");
    return 0;
}

int toolWaitFor(const Args& a, Sink& s, const Cancel& c) {
    std::string host = arg(a, "host");
    int port = 0;
    long timeoutSecs = 0;
    if (!isValidHost(host)) { s.error("Invalid host or IP address."); return 2; }
    if (!isValidPort(arg(a, "port"), &port)) { s.error("Port must be between 1 and 65535."); return 2; }
    if (!isPositiveInt(arg(a, "timeout", "30"), 86400, &timeoutSecs)) { s.error("Timeout must be a positive number of seconds."); return 2; }
    s.line("Waiting up to " + std::to_string(timeoutSecs) + "s for " + host + ":" + std::to_string(port) + " to accept connections...");
    auto start = std::chrono::steady_clock::now();
    for (;;) {
        std::string err;
        auto eps = resolveHost(host, port, SOCK_STREAM, err);
        for (const auto& ep : eps) {
            int fd = connectEndpoint(ep, 1000, &c, nullptr);
            if (fd >= 0) {
                ::close(fd);
                auto secs = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::steady_clock::now() - start).count();
                s.line(Level::Good, "[+] " + host + ":" + std::to_string(port) + " is reachable (after " + std::to_string(secs) + "s)");
                return 0;
            }
        }
        if (c.cancelled()) { s.line(Level::Warn, "Cancelled."); return 130; }
        if (std::chrono::steady_clock::now() - start >= std::chrono::seconds(timeoutSecs)) {
            s.line(Level::Bad, "[-] Timed out after " + std::to_string(timeoutSecs) + "s waiting for " + host + ":" + std::to_string(port));
            return 1;
        }
        if (!sleepCancellable(1000, c)) { s.line(Level::Warn, "Cancelled."); return 130; }
    }
}

int toolBanner(const Args& a, Sink& s, const Cancel& c) {
    std::string host = arg(a, "host");
    int port = 0;
    if (!isValidHost(host)) { s.error("Invalid host or IP address."); return 2; }
    if (!isValidPort(arg(a, "port"), &port)) { s.error("Port must be between 1 and 65535."); return 2; }
    static std::once_flag once;
    std::call_once(once, [] { std::signal(SIGPIPE, SIG_IGN); });
    s.line(Level::Dim, "Only probe systems you own or have permission to test.");
    std::string err;
    auto eps = resolveHost(host, port, SOCK_STREAM, err);
    if (eps.empty()) { s.error("Cannot resolve " + host + ": " + err); return 1; }
    int fd = -1;
    for (const auto& ep : eps) { fd = connectEndpoint(ep, 3000, &c, &err); if (fd >= 0) break; }
    if (fd < 0) { s.line(Level::Bad, "[-] Could not connect: " + err); return 1; }
    std::string data = readSome(fd, 2000, 1024);   // SSH/SMTP/FTP greet first
    if (data.empty()) {                            // HTTP-like services wait for a request
        std::string probe = "HEAD / HTTP/1.0\r\nHost: " + host + "\r\nConnection: close\r\n\r\n";
        if (::write(fd, probe.data(), probe.size()) > 0) data = readSome(fd, 2000, 1024);
    }
    for (int i = 0; i < 3 && !data.empty() && data.size() < 2048; ++i) {
        std::string more = readSome(fd, 400, 1024);
        if (more.empty()) break;
        data += more;
    }
    ::close(fd);
    if (data.empty()) { s.line(Level::Warn, "[-] No banner received (silent protocol or filtered)."); return 1; }
    std::istringstream ss(sanitize(data));
    int shown = 0;
    for (std::string line; std::getline(ss, line) && shown < 15; ++shown) s.line(Level::Good, line);
    return 0;
}

int toolSweep(const Args& a, Sink& s, const Cancel& c) {
    std::string prefix = arg(a, "prefix");
    if (prefix.empty()) prefix = detectLocalPrefix();
    if (prefix.empty()) { s.error("Could not detect your subnet; enter a prefix such as 192.168.1."); return 1; }
    if (!isValidPrefix(prefix)) { s.error("Enter a valid 3-octet subnet prefix (e.g. 192.168.1)."); return 2; }
    if (!commandExists("ping")) { missingTool(s, "ping"); return 1; }
    s.line("Checking " + prefix + ".1-" + prefix + ".254; responding hosts only. Use only on a network you may assess.");
    LockedSink out(s);
    std::atomic<int> found{0};
    parallelFor(254, maxParallelSweep(), c, [&](size_t i) {
        std::string h = prefix + "." + std::to_string(i + 1);
        if (pingOnce(h, c)) { ++found; out.line(Level::Good, "[+] Responding host: " + h); }
    });
    if (c.cancelled()) { s.line(Level::Warn, "Cancelled."); return 130; }
    s.line("Subnet sweep completed: " + std::to_string(found.load()) + " host(s) responded. See the ARP tool for MAC addresses.");
    return 0;
}

int toolCheckHosts(const Args& a, Sink& s, const Cancel& c) {
    std::string input = arg(a, "hosts");
    std::vector<std::string> hosts;
    struct stat st;
    if (!input.empty() && ::stat(input.c_str(), &st) == 0 && S_ISREG(st.st_mode)) {
        std::ifstream f(input);
        for (std::string line; std::getline(f, line);) {
            line = trim(line.substr(0, line.find('#')));
            if (!line.empty()) hosts.push_back(line);
        }
    } else {
        for (const auto& h : split(input, ',')) { std::string t = trim(h); if (!t.empty()) hosts.push_back(t); }
    }
    if (hosts.empty()) { s.error("No hosts supplied (comma-separated list or a file path)."); return 2; }
    if (hosts.size() > 254) { s.error("Too many hosts (limit 254)."); return 2; }
    if (!commandExists("ping")) { missingTool(s, "ping"); return 1; }
    s.line("Checking " + std::to_string(hosts.size()) + " host(s) (up to " + std::to_string(maxParallelSweep()) + " at once)...");
    std::vector<int> state(hosts.size(), 0);   // 0 invalid, 1 up, 2 down
    parallelFor(hosts.size(), maxParallelSweep(), c, [&](size_t i) {
        if (!isValidHost(hosts[i])) return;
        state[i] = pingOnce(hosts[i], c) ? 1 : 2;
    });
    if (c.cancelled()) { s.line(Level::Warn, "Cancelled."); return 130; }
    for (size_t i = 0; i < hosts.size(); ++i) {
        char head[80];
        std::snprintf(head, sizeof head, "%-40.40s ", sanitize(hosts[i]).c_str());
        if (state[i] == 1) s.line(Level::Good, head + std::string("UP"));
        else if (state[i] == 2) s.line(Level::Bad, head + std::string("DOWN"));
        else s.line(Level::Warn, head + std::string("SKIPPED (invalid host)"));
    }
    return 0;
}

int toolMtu(const Args& a, Sink& s, const Cancel& c) {
    std::string host = arg(a, "host");
    if (!isValidHost(host)) { s.error("Invalid host or IP address."); return 2; }
    if (host.find(':') != std::string::npos) { s.error("This DF-bit method supports IPv4 targets only."); return 2; }
    if (!commandExists("ping")) { missingTool(s, "ping"); return 1; }
    // 'ping -h' exits non-zero, so read the text regardless of the status.
    std::string help = captureProcess({"ping", "-h"}, "", nullptr, &c, 3000);
    if (help.find("-M") == std::string::npos) { s.error("Your ping utility does not advertise DF-bit support (-M do)."); return 1; }
    s.line("Estimating IPv4 path MTU to " + host + " (up to 2 seconds per probe; capped at 1500 bytes).");
    s.line(Level::Dim, "A failed probe can also mean ICMP is filtered, so treat the result as an estimate.");
    int low = 0, high = 1472, best = -1;
    while (low <= high && !c.cancelled()) {
        int mid = (low + high) / 2;
        if (runProcess({"ping", "-4", "-M", "do", "-c", "1", "-W", "2", "-s", std::to_string(mid), host}, "", nullptr, &c, 5000) == 0) { best = mid; low = mid + 1; }
        else high = mid - 1;
    }
    if (c.cancelled()) { s.line(Level::Warn, "Cancelled."); return 130; }
    if (best < 0) { s.error("No DF-bit ping received a reply; unable to estimate the path MTU."); return 1; }
    s.line(Level::Good, "Largest successful ICMP payload: " + std::to_string(best) + " bytes; estimated IPv4 path MTU: " + std::to_string(best + 28) + " bytes.");
    return 0;
}

int toolTraceroute(const Args& a, Sink& s, const Cancel& c) {
    std::string host = arg(a, "host");
    if (!isValidHost(host)) { s.error("Invalid host or IP address."); return 2; }
    if (commandExists("tracepath")) return streamCommand({"tracepath", host}, s, c);
    if (commandExists("traceroute")) return streamCommand({"traceroute", host}, s, c);
    missingTool(s, "tracepath");
    return 1;
}

// -- This machine ---------------------------------------------------------------------
int toolIface(const Args&, Sink& s, const Cancel&) {
    ifaddrs* ifs = nullptr;
    if (::getifaddrs(&ifs) != 0) { s.error("getifaddrs failed: " + errnoText(errno)); return 1; }
    struct Info { std::string name, mac; bool up = false; std::vector<std::string> addrs; };
    std::vector<Info> infos;
    auto slot = [&](const std::string& n) -> Info& {
        for (auto& i : infos) if (i.name == n) return i;
        infos.push_back(Info{n, "", false, {}});
        return infos.back();
    };
    auto prefixLen = [](const sockaddr* mask) {
        int bits = 0;
        if (!mask) return 0;
        if (mask->sa_family == AF_INET) { uint32_t m = ntohl(reinterpret_cast<const sockaddr_in*>(mask)->sin_addr.s_addr); while (m) { bits += m & 1; m >>= 1; } }
        else if (mask->sa_family == AF_INET6) { const uint8_t* b = reinterpret_cast<const sockaddr_in6*>(mask)->sin6_addr.s6_addr; for (int i = 0; i < 16; ++i) for (int k = 0; k < 8; ++k) bits += (b[i] >> k) & 1; }
        return bits;
    };
    for (ifaddrs* p = ifs; p; p = p->ifa_next) {
        if (!p->ifa_name) continue;
        Info& info = slot(p->ifa_name);
        if (p->ifa_flags & IFF_UP) info.up = true;
        if (!p->ifa_addr) continue;
        char buf[INET6_ADDRSTRLEN];
        if (p->ifa_addr->sa_family == AF_INET) {
            inet_ntop(AF_INET, &reinterpret_cast<sockaddr_in*>(p->ifa_addr)->sin_addr, buf, sizeof buf);
            info.addrs.push_back(std::string(buf) + "/" + std::to_string(prefixLen(p->ifa_netmask)));
        } else if (p->ifa_addr->sa_family == AF_INET6) {
            inet_ntop(AF_INET6, &reinterpret_cast<sockaddr_in6*>(p->ifa_addr)->sin6_addr, buf, sizeof buf);
            info.addrs.push_back(std::string(buf) + "/" + std::to_string(prefixLen(p->ifa_netmask)));
        }
#if defined(__linux__)
        else if (p->ifa_addr->sa_family == AF_PACKET) {
            auto* ll = reinterpret_cast<sockaddr_ll*>(p->ifa_addr);
            if (ll->sll_halen == 6) {
                char m[24];
                std::snprintf(m, sizeof m, "%02x:%02x:%02x:%02x:%02x:%02x", ll->sll_addr[0], ll->sll_addr[1], ll->sll_addr[2], ll->sll_addr[3], ll->sll_addr[4], ll->sll_addr[5]);
                info.mac = m;
            }
        }
#endif
    }
    ::freeifaddrs(ifs);
    for (const auto& i : infos) {
        char head[64];
        std::snprintf(head, sizeof head, "%-14s %-5s ", i.name.c_str(), i.up ? "UP" : "DOWN");
        std::string tail = i.addrs.empty() ? "(no address)" : joinStrings(i.addrs, ", ");
        if (!i.mac.empty()) tail += "   mac " + i.mac;
        s.line(i.up ? Level::Plain : Level::Dim, head + tail);
    }
    return 0;
}

int toolSockets(const Args&, Sink& s, const Cancel& c) {
    std::vector<SockEntry> all;
    if (readProcSockets(all) && !all.empty()) {
        std::vector<SockEntry> listening;
        int established = 0;
        for (const auto& e : all) {
            if (e.state == "LISTEN" || e.state == "UNCONN") listening.push_back(e);
            else if (e.state == "ESTABLISHED") ++established;
        }
        std::sort(listening.begin(), listening.end(), [](const SockEntry& x, const SockEntry& y) { return x.proto != y.proto ? x.proto < y.proto : x.port < y.port; });
        s.line(Level::Heading, "--- Listening / bound sockets ---");
        for (const auto& e : listening) {
            char row[160];
            std::snprintf(row, sizeof row, "%-6s %-8s %s", e.proto.c_str(), e.state.c_str(), e.local.c_str());
            s.line(row);
        }
        s.line(Level::Heading, "\n--- Established TCP connections: " + std::to_string(established) + " ---");
        return 0;
    }
    if (commandExists("ss")) return streamCommand({"ss", "-tuln"}, s, c);
    if (commandExists("netstat")) return streamCommand({"netstat", "-tuln"}, s, c);
    s.error("Cannot read socket tables here (/proc/net blocked, and no 'ss' or 'netstat').");
    s.line(Level::Dim, platformInstallHint("ss"));
    return 1;
}

int toolLocalPort(const Args& a, Sink& s, const Cancel& c) {
    int port = 0;
    if (!isValidPort(arg(a, "port"), &port)) { s.error("Port must be between 1 and 65535."); return 2; }
    std::vector<SockEntry> all;
    bool busy = false, decided = false;
    if (readProcSockets(all) && !all.empty()) {
        decided = true;
        for (const auto& e : all) if (e.proto[0] == 't' && e.state == "LISTEN" && e.port == port) { busy = true; s.line(e.proto + " listener on " + e.local); }
    }
    if (!decided) {
        std::string out = captureProcess(commandExists("ss") ? std::vector<std::string>{"ss", "-ltn"} : std::vector<std::string>{"netstat", "-an"}, "", nullptr, &c, 3000);
        std::istringstream ss(out);
        for (std::string line; std::getline(ss, line);) {
            if (line.find("LISTEN") == std::string::npos) continue;
            std::istringstream ls(line);
            std::vector<std::string> cols;
            for (std::string col; ls >> col;) cols.push_back(col);
            for (const auto& col : cols) {
                auto pos = col.find_last_of(":.");
                if (pos != std::string::npos && col.substr(pos + 1) == std::to_string(port)) { busy = true; decided = true; s.line(line); break; }
            }
        }
        if (!decided && !out.empty()) decided = true;
    }
    if (!decided) {   // last resort: try to bind it ourselves
        int fd = ::socket(AF_INET, SOCK_STREAM, 0);
        sockaddr_in sa{};
        sa.sin_family = AF_INET;
        sa.sin_addr.s_addr = htonl(INADDR_ANY);
        sa.sin_port = htons(static_cast<uint16_t>(port));
        if (fd >= 0) {
            if (::bind(fd, reinterpret_cast<sockaddr*>(&sa), sizeof sa) != 0) {
                if (errno == EADDRINUSE) { busy = true; decided = true; }
                else s.line(Level::Warn, "Could not test by binding: " + errnoText(errno));
            } else decided = true;
            ::close(fd);
        }
    }
    if (!decided) { s.error("No way to inspect listening sockets here."); return 1; }
    if (busy) { s.line(Level::Bad, "[BUSY] TCP port " + std::to_string(port) + " already has a listener."); return 1; }
    s.line(Level::Good, "[FREE] TCP port " + std::to_string(port) + " has no listener.");
    return 0;
}

int toolTraffic(const Args& a, Sink& s, const Cancel& c) {
    std::string iface = arg(a, "iface");
    long interval = 0;
    if (!isPositiveInt(arg(a, "seconds", "2"), 3600, &interval)) { s.error("Interval must be a whole number of seconds from 1 to 3600."); return 2; }
    if (iface.empty()) iface = defaultInterface();
    if (iface.empty()) { s.error("No interface selected."); return 2; }
    if (!isValidIface(iface)) { s.error("Invalid interface name."); return 2; }
    s.line(Level::Dim, "Interfaces: " + joinStrings(listInterfaces(), " "));
    uint64_t rx1 = 0, tx1 = 0, rx2 = 0, tx2 = 0;
    if (!readIfaceCounters(iface, rx1, tx1)) {
        s.error("Could not read byte counters for '" + iface + "'.");
        s.line(Level::Dim, "Android 10+ blocks /proc/net/dev for apps and sometimes /sys too; try: ip -s link show " + iface);
        return 1;
    }
    s.line("Sampling " + iface + " for " + std::to_string(interval) + "s...");
    if (!sleepCancellable(static_cast<int>(interval) * 1000, c)) { s.line(Level::Warn, "Cancelled."); return 130; }
    if (!readIfaceCounters(iface, rx2, tx2) || rx2 < rx1 || tx2 < tx1) {
        s.error("Counters became unavailable or were reset during sampling; try again.");
        return 1;
    }
    s.line(Level::Good, "Download (RX): " + formatRate((rx2 - rx1) / static_cast<uint64_t>(interval)));
    s.line(Level::Good, "Upload   (TX): " + formatRate((tx2 - tx1) / static_cast<uint64_t>(interval)));
    return 0;
}

int toolArp(const Args&, Sink& s, const Cancel& c) {
    std::ifstream f("/proc/net/arp");
    if (f) {
        std::string line;
        std::getline(f, line);
        s.line(Level::Heading, "IP address       MAC address        Device");
        int n = 0;
        while (std::getline(f, line)) {
            std::istringstream ss(line);
            std::string ip, type, flags, mac, mask, dev;
            if (!(ss >> ip >> type >> flags >> mac >> mask >> dev) || flags == "0x0") continue;
            char row[160];
            std::snprintf(row, sizeof row, "%-16s %-18s %s", ip.c_str(), mac.c_str(), dev.c_str());
            s.line(sanitize(row));
            ++n;
        }
        if (n == 0) s.line(Level::Dim, "(no entries yet - run a subnet sweep first)");
        return 0;
    }
    if (commandExists("ip")) return streamCommand({"ip", "neigh", "show"}, s, c);
    if (commandExists("arp")) return streamCommand({"arp", "-an"}, s, c);
    s.error("No ARP table reader is available (/proc/net/arp, ip neigh, or arp).");
    return 1;
}

int toolSummary(const Args&, Sink& s, const Cancel& c) {
    Args none;
    s.line(Level::Heading, "== Network summary ==");
    s.line(Level::Heading, "\n-- Public IP --");
    toolPublicIp(none, s, c);
    s.line(Level::Heading, "\n-- Interfaces --");
    toolIface(none, s, c);
    s.line(Level::Heading, "\n-- Default route --");
    Route r = defaultRoute();
    s.line(r.ok ? "Gateway " + r.gateway + " via " + r.iface : "unknown (route table not readable)");
    s.line(Level::Heading, "\n-- DNS resolvers --");
    s.line(joinStrings(systemResolvers(), "  "));
    s.line(Level::Heading, "\n-- Established TCP connections --");
    std::vector<SockEntry> all;
    int est = 0;
    if (readProcSockets(all) && !all.empty()) { for (const auto& e : all) if (e.state == "ESTABLISHED") ++est; s.line(std::to_string(est)); }
    else s.line("n/a");
    s.line(Level::Heading, "\n-- Connectivity --");
    std::string err;
    auto eps = resolveHost("1.1.1.1", 443, SOCK_STREAM, err);
    int fd = eps.empty() ? -1 : connectEndpoint(eps[0], 3000, &c, &err);
    if (fd >= 0) { ::close(fd); s.line(Level::Good, "TCP to 1.1.1.1:443 OK"); }
    else s.line(Level::Bad, "TCP to 1.1.1.1:443 failed (" + err + ")");
    DnsResult d = queryViaSystem("cloudflare.com", T_A, c);
    if (d.error.empty() && d.ok && !d.records.empty()) s.line(Level::Good, "DNS resolution OK");
    else s.line(Level::Bad, "DNS resolution failed" + (d.error.empty() ? std::string() : " (" + d.error + ")"));
    return 0;
}

// -- HaveIBeenPwned -------------------------------------------------------------------------
// The API key goes to curl through stdin (--config -), never on the command line,
// so it cannot appear in the process list.
int hibpRequest(const std::string& path, const std::string& query, const Args& a, Sink& s, const Cancel& c, std::string& body) {
    std::string key = arg(a, "apikey");
    if (key.empty()) { const char* env = std::getenv("HIBP_API_KEY"); if (env) key = trim(env); }
    if (key.empty()) { s.error("No API key. Set HIBP_API_KEY or enter it in the API key field (https://haveibeenpwned.com/API/Key)."); return -1; }
    if (key.size() != 32 || !std::all_of(key.begin(), key.end(), [](unsigned char ch) { return std::isxdigit(ch) != 0; })) {
        s.error("That doesn't look like a valid API key (HIBP keys are 32 hex characters).");
        return -1;
    }
    if (!commandExists("curl")) { missingTool(s, "curl"); return -1; }
    std::string url = std::string("https://haveibeenpwned.com/api/v3/") + path + (query.empty() ? "" : "?" + query);
    std::string cfg = "silent\nshow-error\nmax-time = 15\nwrite-out = \"\\n%{http_code}\"\n"
                      "header = \"hibp-api-key: " + key + "\"\nheader = \"User-Agent: nettool/" + kVersion + "\"\nurl = \"" + url + "\"\n";
    int st = 0;
    std::string out = captureProcess({"curl", "--config", "-"}, cfg, &st, &c, 20000);
    if (st != 0) { s.error("Could not reach the HIBP API (network issue or timeout)."); return -1; }
    auto nl = out.rfind('\n');
    std::string code = nl == std::string::npos ? out : out.substr(nl + 1);
    body = nl == std::string::npos ? "" : out.substr(0, nl);
    int http = std::atoi(code.c_str());
    switch (http) {
        case 200: case 404: return http;
        case 401: s.error("HIBP rejected the API key as unauthorized."); break;
        case 403: s.error("HIBP returned 403 Forbidden (domain not verified for this key, or endpoint not in your plan)."); break;
        case 429: s.error("Rate limited by HIBP (429). Wait a minute and try again."); break;
        default: s.error("HIBP returned an unexpected HTTP status: " + code); break;
    }
    return -1;
}

int toolBreachEmail(const Args& a, Sink& s, const Cancel& c) {
    std::string email = arg(a, "email");
    if (!isValidEmail(email)) { s.error("That doesn't look like a valid email address."); return 2; }
    s.line("Checking " + email + " against the HaveIBeenPwned breach database...");
    s.line(Level::Dim, "Only check accounts you own or are explicitly authorized to check.");
    std::string body;
    int http = hibpRequest("breachedaccount/" + urlEncode(email), "truncateResponse=false", a, s, c, body);
    if (http < 0) return 1;
    if (http == 404) { s.line(Level::Good, "[OK] No breaches found for " + email + "."); return 0; }
    Json j;
    if (!Json::parse(body, j) || j.type != Json::Type::Array) { s.error("Unexpected response from HIBP."); return 1; }
    for (const auto& b : j.arr) {
        const Json* title = b.get("Title");
        const Json* name = b.get("Name");
        const Json* date = b.get("BreachDate");
        const Json* count = b.get("PwnCount");
        std::string t = title ? title->asString() : name ? name->asString() : "?";
        s.line(Level::Warn, "- " + sanitize(t) + " (" + (date ? sanitize(date->asString()) : "?") + ") - " + (count ? count->asString() : "?") + " accounts");
        if (const Json* dc = b.get("DataClasses")) {
            std::vector<std::string> classes;
            for (const auto& x : dc->arr) classes.push_back(sanitize(x.asString()));
            s.line("  Exposed: " + joinStrings(classes, ", "));
        }
    }
    s.line(Level::Bad, "[!] " + email + " appears in " + std::to_string(j.arr.size()) + " known breach(es). Rotate passwords and enable 2FA on the affected services.");
    return 0;
}

int toolBreachDomain(const Args& a, Sink& s, const Cancel& c) {
    std::string domain = arg(a, "domain");
    if (!isValidHost(domain) || domain.find(':') != std::string::npos) { s.error("Invalid domain name."); return 2; }
    s.line("Checking breached aliases on record for " + domain + "...");
    s.line(Level::Dim, "The domain must already be verified for your key: https://haveibeenpwned.com/DomainSearch");
    std::string body;
    int http = hibpRequest("breacheddomain/" + domain, "", a, s, c, body);
    if (http < 0) return 1;
    Json j;
    if (http == 404 || body.empty() || (Json::parse(body, j) && (j.type == Json::Type::Null || (j.type == Json::Type::Object && j.obj.empty())))) {
        s.line(Level::Good, "[OK] No breached aliases on record for " + domain + ".");
        return 0;
    }
    if (j.type != Json::Type::Object) { s.error("Unexpected response from HIBP."); return 1; }
    for (const auto& kv : j.obj) {
        std::vector<std::string> names;
        for (const auto& x : kv.second.arr) names.push_back(sanitize(x.asString()));
        s.line(Level::Warn, sanitize(kv.first) + ": " + joinStrings(names, ", "));
    }
    return 0;
}

}  // namespace

// --------------------------------------------------------------- public API ----
bool buildSshArgv(const Args& args, std::vector<std::string>& argv, std::string& err) { return buildSshArgvImpl(args, argv, err); }

std::vector<std::string> terminalWrap(const std::vector<std::string>& argv) {
    struct Term { const char* bin; std::vector<std::string> flag; };
    std::vector<Term> candidates;
    if (const char* t = std::getenv("TERMINAL")) if (*t) candidates.push_back({t, {"-e"}});
    candidates.push_back({"konsole", {"-e"}});
    candidates.push_back({"gnome-terminal", {"--"}});
    candidates.push_back({"xfce4-terminal", {"-x"}});
    candidates.push_back({"alacritty", {"-e"}});
    candidates.push_back({"kitty", {}});
    candidates.push_back({"foot", {}});
    candidates.push_back({"wezterm", {"start", "--"}});
    candidates.push_back({"terminator", {"-x"}});
    candidates.push_back({"x-terminal-emulator", {"-e"}});
    candidates.push_back({"xterm", {"-e"}});
    for (const auto& t : candidates) {
        if (!commandExists(t.bin)) continue;
        std::vector<std::string> out = {t.bin};
        out.insert(out.end(), t.flag.begin(), t.flag.end());
        out.insert(out.end(), argv.begin(), argv.end());
        return out;
    }
    return {};
}

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmissing-field-initializers"
const std::vector<Tool>& tools() {
    static const std::vector<Tool> registry = {
        {"netping", "Connectivity", "Parallel ping", "Ping a host from several threads and summarize RTT and jitter.",
         {{"host", "Host or IP", "example.com", true}, {"count", "Pings per thread", "4", false, false, "4"}, {"threads", "Threads", "1", false, false, "1"}, {"size", "Payload bytes", "56", false, false, "56"}}, false, toolNetping},
        {"traceroute", "Connectivity", "Traceroute", "Show the network path to a host.",
         {{"host", "Host or IP", "example.com", true}}, false, toolTraceroute},
        {"mtu", "Connectivity", "Path MTU", "Estimate the IPv4 path MTU with DF-bit pings.",
         {{"host", "IPv4 host", "example.com", true}}, false, toolMtu},
        {"ports", "Connectivity", "TCP port scan", "Scan a range of TCP ports on a host you are allowed to test.",
         {{"host", "Host or IP", "192.168.1.10", true}, {"start", "First port", "1", false, false, "1"}, {"end", "Last port", "1024", false, false, "1024"}}, false, toolPorts},
        {"waitfor", "Connectivity", "Wait for port", "Block until host:port accepts connections.",
         {{"host", "Host or IP", "localhost", true}, {"port", "Port", "8080", true}, {"timeout", "Timeout (s)", "30", false, false, "30"}}, false, toolWaitFor},
        {"banner", "Connectivity", "Banner grab", "Read the greeting a service sends on an open TCP port.",
         {{"host", "Host or IP", "192.168.1.10", true}, {"port", "Port", "22", true}}, false, toolBanner},
        {"sweep", "Connectivity", "Subnet sweep", "Ping every host on a local /24 (auto-detects yours).",
         {{"prefix", "Prefix (blank = auto)", "192.168.1", false}}, false, toolSweep},
        {"checkhosts", "Connectivity", "Batch host check", "Ping a list of hosts (comma-separated, or a file path) and report UP/DOWN.",
         {{"hosts", "Hosts or file", "a.example.com, b.example.com", true}}, false, toolCheckHosts},
        {"dns", "DNS & Web", "DNS resolver check", "Compare A records across four public resolvers.",
         {{"domain", "Domain", "example.com", true}}, false, toolDns},
        {"records", "DNS & Web", "DNS records", "A, AAAA, CNAME, MX, NS and TXT records via your system resolver.",
         {{"domain", "Domain", "example.com", true}}, false, toolRecords},
        {"rdns", "DNS & Web", "Reverse DNS", "Look up the PTR record for an IP address.",
         {{"ip", "IP address", "8.8.8.8", true}}, false, toolRdns},
        {"whois", "DNS & Web", "WHOIS", "Native WHOIS lookup that follows registry referrals.",
         {{"query", "Domain, IP or ASN", "example.com", true}}, false, toolWhois},
        {"publicip", "DNS & Web", "Public IP", "Your public address and rough location (tries several services).",
         {}, false, toolPublicIp},
        {"ssl", "DNS & Web", "TLS certificate", "Inspect a certificate and see how long it stays valid.",
         {{"host", "Host", "example.com", true}, {"port", "Port", "443", false, false, "443"}}, false, toolSsl},
        {"headers", "DNS & Web", "HTTP headers", "Show the response headers for a URL.",
         {{"url", "URL", "https://example.com", true}}, false, toolHeaders},
        {"httptime", "DNS & Web", "HTTP timing", "DNS, TCP, TLS, first-byte and total time for a URL.",
         {{"url", "URL", "https://example.com", true}}, false, toolHttpTime},
        {"speed", "DNS & Web", "Speed test", "Download a 25 MB file and report throughput (uses data).",
         {}, false, toolSpeed},
        {"summary", "This machine", "Network summary", "Public IP, interfaces, gateway, DNS and connectivity at a glance.",
         {}, false, toolSummary},
        {"iface", "This machine", "Interfaces", "Local network interfaces and addresses.",
         {}, false, toolIface},
        {"traffic", "This machine", "Traffic monitor", "Measure live download/upload throughput on an interface.",
         {{"iface", "Interface (blank = default)", "wlan0", false}, {"seconds", "Sample seconds", "2", false, false, "2"}}, false, toolTraffic},
        {"sockets", "This machine", "Open sockets", "Listening ports and established connections.",
         {}, false, toolSockets},
        {"localport", "This machine", "Local port check", "Is a TCP port on this machine already in use?",
         {{"port", "Port", "8080", true}}, false, toolLocalPort},
        {"arp", "This machine", "ARP table", "Neighbors this machine has recently talked to (run a sweep first).",
         {}, false, toolArp},
        {"cidr", "This machine", "CIDR calculator", "Offline IPv4 subnet calculator.",
         {{"cidr", "CIDR", "192.168.1.77/24", true}}, false, toolCidr},
        {"breach-email", "Security", "Breach check: email", "Check an email you own against HaveIBeenPwned.",
         {{"email", "Email you own", "you@example.com", true}, {"apikey", "HIBP API key (or set HIBP_API_KEY)", "32 hex characters", false, true}}, false, toolBreachEmail},
        {"breach-domain", "Security", "Breach check: domain", "Check a domain you have verified with HaveIBeenPwned.",
         {{"domain", "Verified domain", "example.com", true}, {"apikey", "HIBP API key (or set HIBP_API_KEY)", "32 hex characters", false, true}}, false, toolBreachDomain},
        {"ssh", "Remote", "SSH", "Open an SSH session in a terminal window.",
         {{"host", "Host", "server.example.com", true}, {"user", "User (optional)", "", false}, {"port", "Port", "22", false, false, "22"}, {"key", "Key file (optional)", "~/.ssh/id_ed25519", false}}, true, toolSsh},
    };
    return registry;
}
#pragma GCC diagnostic pop

const Tool* findTool(const std::string& id) {
    for (const auto& t : tools()) if (t.id == id) return &t;
    return nullptr;
}

int runDoctor(Sink& s) {
    s.line(Level::Heading, "--- Dependency check (external helpers) ---");
    s.line(Level::Dim, "Most tools are native; these helpers cover ICMP, TLS, HTTPS and terminals.");
    int missing = 0;
    for (const char* cmd : {"ping", "curl", "openssl", "tracepath", "traceroute", "ss", "netstat", "ip", "ssh"}) {
        bool ok = commandExists(cmd);
        char row[64];
        std::snprintf(row, sizeof row, "  %-12s %s", cmd, ok ? "available" : "not installed");
        s.line(ok ? Level::Good : Level::Warn, row);
        if (!ok) ++missing;
    }
    if (missing) s.line(Level::Dim, "Some are optional (tracepath/traceroute, ss/netstat are alternatives). Example: " + platformInstallHint("ping"));
    return 0;
}

}  // namespace nt
