#include "tools.hpp"

#include <cstring>

namespace nt {
namespace {

// A minimal A + TXT response for example.com with compressed names.
std::vector<uint8_t> sampleResponse(uint16_t id) {
    std::string err;
    std::vector<uint8_t> r = buildDnsQuery("example.com", T_A, id, err);
    r[2] = 0x81; r[3] = 0x80;   // response, recursion available, rcode 0
    r[7] = 2;                   // two answers
    auto answer = [&](uint16_t type, const std::vector<uint8_t>& rdata) {
        for (uint8_t b : {0xC0, 0x0C}) r.push_back(b);              // name: pointer to the question
        r.push_back(0); r.push_back(static_cast<uint8_t>(type));
        r.push_back(0); r.push_back(1);                             // class IN
        for (int i = 0; i < 3; ++i) r.push_back(0);
        r.push_back(60);                                            // ttl
        r.push_back(0); r.push_back(static_cast<uint8_t>(rdata.size()));
        r.insert(r.end(), rdata.begin(), rdata.end());
    };
    answer(T_A, {93, 184, 216, 34});
    std::string txt = "v=spf1 -all";
    std::vector<uint8_t> rd = {static_cast<uint8_t>(txt.size())};
    rd.insert(rd.end(), txt.begin(), txt.end());
    answer(T_TXT, rd);
    return r;
}

}  // namespace

int runSelfTests(Sink& s) {
    int passed = 0, failed = 0;
    auto check = [&](bool ok, const std::string& name) {
        if (ok) ++passed; else ++failed;
        s.line(ok ? Level::Good : Level::Bad, std::string(ok ? "PASS " : "FAIL ") + name);
    };

    // validation
    check(isValidHost("example.com"), "hostname");
    check(isValidHost("localhost"), "single-label hostname");
    check(isValidHost("example.com."), "trailing-dot hostname");
    check(isValidHost("192.168.1.1"), "IPv4");
    check(isValidHost("2001:db8::1"), "IPv6 literal");
    check(!isValidHost("1.2.3"), "reject malformed dotted quad");
    check(!isValidHost("256.1.1.1"), "reject out-of-range octet");
    check(!isValidHost("-oProxyCommand=x"), "reject option-like host");
    check(!isValidHost("a;touch /tmp/x"), "reject shell metacharacters");
    check(!isValidHost("a..b.com"), "reject empty label");
    check(!isValidHost(std::string(64, 'a') + ".com"), "reject 64-char label");
    check(!isValidHost("-bad.example.com"), "reject leading-hyphen label");
    check(isValidPort("65535") && !isValidPort("0") && !isValidPort("65536") && !isValidPort("08x"), "port range");
    check(isValidPort("0080"), "decimal port with leading zero");
    check(isPositiveInt("4", 10) && !isPositiveInt("0", 10) && !isPositiveInt("11", 10) && !isPositiveInt("-1", 10), "positive integer");
    check(isValidPrefix("192.168.1") && !isValidPrefix("192.168.1.5") && !isValidPrefix("192.168.300"), "subnet prefix");
    check(isValidEmail("user@example.com") && !isValidEmail("user@") && !isValidEmail("a;b@example.com") && !isValidEmail("a@@b.com"), "email");
    check(isValidUrl("https://example.com/path") && isValidUrl("https://example.com?x=1") && isValidUrl("http://h:8080/") &&
          !isValidUrl("ftp://example.com") && !isValidUrl("https://exa mple.com") && !isValidUrl("https://"), "URL");
    check(isValidIface("wlan0") && isValidIface("br-1.2") && !isValidIface("lo;x") && !isValidIface("-x") && !isValidIface("../x"), "interface name");

    // CIDR
    CidrInfo ci;
    std::string err;
    check(calcCidr("192.168.1.77/24", ci, err) && ci.network == "192.168.1.0" && ci.broadcast == "192.168.1.255" && ci.hosts == 254, "CIDR /24");
    check(calcCidr("192.168.1.77/26", ci, err) && ci.broadcast == "192.168.1.127" && ci.first == "192.168.1.65", "CIDR /26");
    check(calcCidr("10.0.0.5/31", ci, err) && ci.hosts == 2 && ci.first == "10.0.0.4", "CIDR /31");
    check(calcCidr("10.0.0.5/32", ci, err) && ci.hosts == 1, "CIDR /32");
    check(calcCidr("10.0.0.5/0", ci, err) && ci.netmask == "0.0.0.0" && ci.broadcast == "255.255.255.255", "CIDR /0");
    check(!calcCidr("10.0.0.5/33", ci, err) && !calcCidr("10.0.0.300/24", ci, err) && !calcCidr("10.0.0.5", ci, err), "CIDR rejects bad input");

    // JSON
    Json j;
    check(Json::parse(R"({"ip": "1.2.3.4", "n": 15169, "ok": true, "x": null, "a": [1, "two"], "u": "\u00e9\ud83d\ude00\n"})", j) &&
          j.get("ip") && j.get("ip")->str == "1.2.3.4" && j.get("n")->asString() == "15169" && j.get("a")->arr.size() == 2, "JSON parse");
    check(j.get("u") && j.get("u")->str == "\xC3\xA9\xF0\x9F\x98\x80\n", "JSON unicode escapes and surrogate pairs");
    check(!Json::parse("{\"a\":1} trailing", j) && !Json::parse("{\"a\":", j) && !Json::parse("", j), "JSON rejects malformed input");
    check(!Json::parse(std::string(200, '[') + std::string(200, ']'), j), "JSON depth limit");

    // text helpers
    check(sanitize("a\x1b[31mb\r\nc") == "a.[31mb\nc", "sanitize strips escape sequences");
    check(urlEncode("a+b@example.com") == "a%2Bb%40example.com", "URL encoding");
    check(formatRate(512) == "512 B/s" && formatRate(1536) == "1.50 KB/s" && formatRate(5242880) == "5.00 MB/s", "rate formatting");
    {
        LineBuffer lb;
        std::vector<std::string> got;
        auto emit = [&](const std::string& l) { got.push_back(l); };
        lb.feed("ab", emit); lb.feed("c\r\nde", emit); lb.feed("f\n", emit); lb.flush(emit);
        check(got.size() == 2 && got[0] == "abc" && got[1] == "def", "line buffering across chunks");
    }

    // ssh argument builder
    {
        std::vector<std::string> argv;
        std::string e;
        check(buildSshArgv({{"host", "example.com"}, {"user", "bob"}, {"port", "2222"}, {"key", "/home/bob/.ssh/id"}}, argv, e) &&
              argv == std::vector<std::string>{"ssh", "-p", "2222", "-i", "/home/bob/.ssh/id", "bob@example.com"}, "ssh argv: user, port and key");
        check(buildSshArgv({{"host", "example.com"}}, argv, e) && argv == std::vector<std::string>{"ssh", "example.com"}, "ssh argv: defaults");
        check(!buildSshArgv({{"host", "example.com"}, {"user", "a;b"}}, argv, e), "ssh rejects shell metacharacters in user");
        check(!buildSshArgv({{"host", "-oProxyCommand=x"}}, argv, e), "ssh rejects option-like host");
        check(!buildSshArgv({{"host", "example.com"}, {"key", "-oProxyCommand=x"}}, argv, e), "ssh rejects option-like key path");
        check(!buildSshArgv({{"host", "example.com"}, {"port", "99999"}}, argv, e), "ssh rejects bad port");
    }

    // uptime formatting, host info, interface details
    {
        check(formatUptime(59) == "0m" && formatUptime(150 * 60) == "2h 30m" && formatUptime(3 * 86400 + 4 * 3600 + 59) == "3d 4h", "uptime formatting");
        check(!hostName().empty() && !osName().empty() && !kernelRelease().empty(), "host, OS and kernel names are available");
#if defined(__linux__)
        IfaceDetails d;
        check(ifaceDetails("lo", d) && d.up && d.ipv4 == "127.0.0.1" && d.mask == "255.0.0.0", "loopback interface details");
#endif
    }

    // DNS wire format
    {
        auto resp = sampleResponse(0x1234);
        DnsResult r;
        bool tc = false;
        bool ok = parseDnsResponse(resp.data(), resp.size(), 0x1234, r, tc);
        check(ok && r.ok && r.records.size() == 2 && r.records[0].text == "93.184.216.34" && r.records[1].text == "\"v=spf1 -all\"", "DNS response parsing (compressed names, A + TXT)");
        DnsResult wrong;
        check(!parseDnsResponse(resp.data(), resp.size(), 0x9999, wrong, tc), "DNS rejects mismatched transaction id");

        // Robustness: every truncation and many single-byte corruptions must be handled safely.
        int handled = 0;
        for (size_t len = 0; len <= resp.size(); ++len) {
            DnsResult x; bool t = false;
            parseDnsResponse(resp.data(), len, 0x1234, x, t);
            ++handled;
        }
        for (size_t i = 0; i < resp.size(); ++i) {
            for (uint8_t v : {0x00, 0x3F, 0x7F, 0xC0, 0xFF}) {
                auto mutated = resp;
                mutated[i] = v;
                DnsResult x; bool t = false;
                parseDnsResponse(mutated.data(), mutated.size(), 0x1234, x, t);
                ++handled;
            }
        }
        check(handled > 100, "DNS parser survives truncated and corrupted packets");

        // A pointer loop must be rejected, not followed forever.
        std::vector<uint8_t> loop = resp;
        loop[12] = 0xC0; loop[13] = 0x0C;   // question name points at itself
        DnsResult x; bool t = false;
        check(!parseDnsResponse(loop.data(), loop.size(), 0x1234, x, t), "DNS compression-pointer loop rejected");
    }

    s.line(failed == 0 ? Level::Good : Level::Bad,
           failed == 0 ? "All self-tests passed (" + std::to_string(passed) + ")." : "Self-test failed: " + std::to_string(failed) + " check(s).");
    return failed == 0 ? 0 : 1;
}

}  // namespace nt
