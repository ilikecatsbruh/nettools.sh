# nettool 3.0 (C++)

A network toolkit rewritten in C++17: a Qt-free **engine**, a **command-line tool**, and a
**Qt 6 "liquid glass" window** (frameless, translucent, animated backdrop, glass panels).

Only test systems and networks you own or have explicit permission to assess.

## Build

**Arch Linux**

```bash
sudo pacman -S --needed base-devel cmake qt6-base iputils curl openssl
cmake -B build -S . && cmake --build build -j
./build/nettool-gui          # the glass window
./build/nettool-cli --help   # the command line
```

**CLI only (no CMake, no Qt)** - also works on Termux (`pkg install clang make`):

```bash
make                         # builds build/nettool-cli
make check                   # self-tests
```

Debian/Ubuntu: `sudo apt install build-essential cmake qt6-base-dev iputils-ping curl openssl`.

## What is native and what shells out

Native C++ (no external program): CIDR calculator, TCP port scan, wait-for-port, banner grab,
DNS (own wire-format client with UDP and TCP fallback: `dns`, `records`, `rdns`), WHOIS (follows
registry referrals), interfaces, sockets, traffic counters, local-port check, ARP table, summary.

Helper programs, started directly (never through a shell): `ping` (netping, sweep, checkhosts, mtu),
`curl` (publicip, headers, httptime, speed, breach checks), `openssl` (ssl), `tracepath`/`traceroute`,
and a terminal emulator for `ssh` in the GUI. Run `nettool-cli doctor` to see what is installed.

| Group | Commands |
|---|---|
| Connectivity | netping, traceroute, mtu, ports, waitfor, banner, sweep, checkhosts |
| DNS & Web | dns, records, rdns, whois, publicip, ssl, headers, httptime, speed |
| This machine | summary, iface, traffic, sockets, localport, arp, cidr |
| Security | breach-email, breach-domain (HaveIBeenPwned; needs `HIBP_API_KEY`) |
| Remote | ssh |

## GUI

Layout (modelled on a dark-indigo reference design): custom title bar, icon sidebar, a form card
with **Start / Stop / Clear**, a colour-coded terminal pane, and an information panel on the right
(interface details, hostname/OS/kernel/uptime, quick actions). The sidebar's main entries are
Home, Ping, Traceroute, DNS Lookup, Port Scan, Network Info and Bandwidth Test; every other tool
is listed under **More tools**. Settings has an opacity slider and animation / info-panel toggles
(remembered between runs).

* Quick Actions run traceroute to 8.8.8.8, a DNS lookup of example.com, and a port scan of **your
  own gateway** (your router), not of a third party.
* The window is mostly opaque by default (93%). **Blur behind the window comes from your
  compositor**, not Qt: for a frosted look lower the opacity in Settings and enable blur, e.g. the
  KDE *Blur* effect with a window rule for the class `nettool`. Hyprland blurs translucent windows
  when blur is enabled in `decoration`. I could not test the compositor side.
* `NETTOOL_GLASS_OPACITY=70 ./nettool-gui` and `NETTOOL_NO_ANIM=1` override the saved settings.
* Drag the title bar to move, double-click it to maximize, and resize from the window edges. The
  information panel hides itself on narrow windows.
* The API-key field is masked. The key is handed to `curl` over stdin, so it never appears in the
  process list. The CLI refuses a key on the command line and reads `HIBP_API_KEY` instead.
* Icons are drawn in code, so there are no image files and no extra Qt module (such as Qt SVG).

## Environment

`NO_COLOR`, `NETTOOL_MAX_PARALLEL_PROBE` (default 50), `NETTOOL_MAX_PARALLEL_SWEEP` (default 40),
`NETTOOL_DNS_SERVERS` (comma-separated, `host` or `host:port`), `HIBP_API_KEY`,
`NETTOOL_GLASS_OPACITY`, `NETTOOL_NO_ANIM`.

## Tests

```bash
make check                   # 46 self-tests (validators, CIDR, JSON, DNS parser incl. fuzzing)
make sanitize                # same under AddressSanitizer + UBSan
make && bash tests/functional.sh   # 82 functional tests against fake servers and stub programs
```

The functional suite starts loopback-only fake TCP, DNS (UDP + TCP) and two-hop WHOIS servers
(`tests/fake_servers.py`) and stubs `ping`, `curl`, `openssl` and `ssh`. It never touches the
real network.

## Not carried over from the bash version

`install`, `uninstall` and `install-deps` (package-manager helpers): use CMake's install target
and your package manager; `doctor` prints the right install command for your platform.
Linux and macOS are the targets; Windows is not supported. Some tools read `/proc` or `/sys`
(Linux/Termux) and fall back to helper programs elsewhere.
